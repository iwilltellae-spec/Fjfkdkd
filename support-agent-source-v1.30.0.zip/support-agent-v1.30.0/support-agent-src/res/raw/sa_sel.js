/* [PATCH] selection system disabled */
