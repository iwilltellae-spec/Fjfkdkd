.class public final Lru/supportagent/GpsShift;
.super Ljava/lang/Object;
.source "GpsShift.java"


# static fields
.field private static final KEY:Ljava/lang/String; = "gps_event_shift"

.field private static final PREFS:Ljava/lang/String; = "support_agent_overlay"

.field private static app:Landroid/content/Context;

.field private static offset:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 10
    const/4 v0, 0x0

    sput v0, Lru/supportagent/GpsShift;->offset:I

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static apply(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 43
    if-eqz p0, :cond_5

    sget v0, Lru/supportagent/GpsShift;->offset:I

    if-gtz v0, :cond_0

    goto :goto_2

    .line 45
    :cond_0
    :try_start_0
    const-string v0, "/gps"

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    .line 46
    if-gez v0, :cond_1

    return-object p0

    .line 47
    :cond_1
    add-int/lit8 v0, v0, 0x4

    .line 48
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    .line 49
    :goto_0
    if-ge v0, v1, :cond_2

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->isDigit(C)Z

    move-result v2

    if-nez v2, :cond_2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 50
    :cond_2
    if-lt v0, v1, :cond_3

    return-object p0

    .line 51
    :cond_3
    move v2, v0

    .line 52
    :goto_1
    if-ge v2, v1, :cond_4

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->isDigit(C)Z

    move-result v3

    if-eqz v3, :cond_4

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    .line 53
    :cond_4
    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .line 54
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    invoke-virtual {p0, v4, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget v3, Lru/supportagent/GpsShift;->offset:I

    add-int/2addr v1, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p0

    .line 55
    :catchall_0
    move-exception v0

    .line 56
    return-object p0

    .line 43
    :cond_5
    :goto_2
    return-object p0
.end method

.method public static get(Landroid/content/Context;)I
    .locals 1

    .line 27
    sget-object v0, Lru/supportagent/GpsShift;->app:Landroid/content/Context;

    if-nez v0, :cond_0

    invoke-static {p0}, Lru/supportagent/GpsShift;->init(Landroid/content/Context;)V

    .line 28
    :cond_0
    sget p0, Lru/supportagent/GpsShift;->offset:I

    return p0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 2

    .line 16
    if-nez p0, :cond_0

    return-void

    .line 18
    :cond_0
    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    sput-object p0, Lru/supportagent/GpsShift;->app:Landroid/content/Context;

    .line 19
    const-string v1, "support_agent_overlay"

    invoke-virtual {p0, v1, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v1, "gps_event_shift"

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    sput p0, Lru/supportagent/GpsShift;->offset:I

    .line 20
    if-ltz p0, :cond_1

    const/16 v1, 0xa

    if-le p0, v1, :cond_2

    :cond_1
    sput v0, Lru/supportagent/GpsShift;->offset:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    :cond_2
    goto :goto_0

    .line 21
    :catchall_0
    move-exception p0

    .line 22
    sput v0, Lru/supportagent/GpsShift;->offset:I

    .line 24
    :goto_0
    return-void
.end method

.method public static set(Landroid/content/Context;I)V
    .locals 1

    .line 32
    sget-object v0, Lru/supportagent/GpsShift;->app:Landroid/content/Context;

    if-nez v0, :cond_0

    invoke-static {p0}, Lru/supportagent/GpsShift;->init(Landroid/content/Context;)V

    .line 33
    :cond_0
    const/4 p0, 0x0

    if-gez p1, :cond_1

    move p1, p0

    goto :goto_0

    :cond_1
    const/16 v0, 0xa

    if-le p1, v0, :cond_2

    move p1, v0

    :cond_2
    :goto_0
    sput p1, Lru/supportagent/GpsShift;->offset:I

    .line 35
    :try_start_0
    sget-object p1, Lru/supportagent/GpsShift;->app:Landroid/content/Context;

    const-string v0, "support_agent_overlay"

    invoke-virtual {p1, v0, p0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 36
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "gps_event_shift"

    sget v0, Lru/supportagent/GpsShift;->offset:I

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    goto :goto_1

    .line 37
    :catchall_0
    move-exception p0

    .line 39
    :goto_1
    return-void
.end method
