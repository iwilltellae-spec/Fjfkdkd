.class public final Lru/supportagent/MainActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "MainActivity.java"


# static fields
.field public static final ACTION_REQUEST_MICROPHONE:Ljava/lang/String; = "ru.supportagent.REQUEST_MICROPHONE"

.field private static final REQUEST_MICROPHONE:I = 0x2c7


# instance fields
.field private microphonePermissionOnly:Z

.field private openedOverlaySettings:Z

.field private palette:Lru/supportagent/AgentPalette;

.field private root:Landroid/widget/LinearLayout;


# direct methods
.method public static synthetic $r8$lambda$4Woha_Lm5Lvdl4GBj26i9ks3J8s(Lru/supportagent/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/MainActivity;->ensureReady()V

    return-void
.end method

.method public static synthetic $r8$lambda$dU5SS6ehWLDXNhagy8DA6mqcmLA(Lru/supportagent/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/MainActivity;->openOverlaySettings()V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 26
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method

.method private applyWindowColors()V
    .locals 2

    .line 109
    invoke-virtual {p0}, Lru/supportagent/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    .line 110
    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 111
    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 112
    iget-object v0, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    return-void
.end method

.method private ensureReady()V
    .locals 4

    .line 88
    new-instance v0, Lru/supportagent/PaletteRepository;

    invoke-direct {v0, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object v0

    iput-object v0, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    .line 89
    invoke-direct {p0}, Lru/supportagent/MainActivity;->applyWindowColors()V

    .line 90
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 91
    new-instance v0, Lru/supportagent/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0}, Lru/supportagent/MainActivity$$ExternalSyntheticLambda1;-><init>(Lru/supportagent/MainActivity;)V

    const-string v1, "\u041d\u0423\u0416\u041d\u041e \u0420\u0410\u0417\u0420\u0415\u0428\u0415\u041d\u0418\u0415"

    const-string v2, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043f\u043e\u043a\u0430\u0437 \u043f\u043e\u0432\u0435\u0440\u0445 \u0434\u0440\u0443\u0433\u0438\u0445 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439 \u2014 \u044d\u0442\u043e \u043d\u0443\u0436\u043d\u043e \u0434\u043b\u044f \u043a\u0440\u0443\u0433\u0430 \u043f\u043e\u0432\u0435\u0440\u0445 \u0438\u0433\u0440\u044b."

    const-string v3, "\u041e\u0422\u041a\u0420\u042b\u0422\u042c \u0420\u0410\u0417\u0420\u0415\u0428\u0415\u041d\u0418\u0415"

    invoke-direct {p0, v1, v2, v3, v0}, Lru/supportagent/MainActivity;->renderSetup(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    .line 96
    iget-boolean v0, p0, Lru/supportagent/MainActivity;->openedOverlaySettings:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    .line 97
    iput-boolean v0, p0, Lru/supportagent/MainActivity;->openedOverlaySettings:Z

    .line 98
    iget-object v0, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    new-instance v1, Lru/supportagent/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lru/supportagent/MainActivity$$ExternalSyntheticLambda1;-><init>(Lru/supportagent/MainActivity;)V

    const-wide/16 v2, 0x1a4

    invoke-virtual {v0, v1, v2, v3}, Landroid/widget/LinearLayout;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void

    .line 104
    :cond_1
    invoke-direct {p0}, Lru/supportagent/MainActivity;->startOverlayAutomatically()V

    .line 105
    invoke-direct {p0}, Lru/supportagent/MainActivity;->renderReady()V

    return-void
.end method

.method static synthetic lambda$renderSetup$0(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 158
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private openOverlaySettings()V
    .locals 4

    const-string v0, "package:"

    .line 211
    :try_start_0
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 212
    invoke-virtual {p0}, Lru/supportagent/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 211
    invoke-virtual {p0, v1}, Lru/supportagent/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f"

    const/4 v1, 0x0

    .line 214
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method private renderLoading()V
    .locals 4

    .line 116
    invoke-direct {p0}, Lru/supportagent/MainActivity;->applyWindowColors()V

    .line 117
    iget-object v0, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 118
    iget-object v0, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const/4 v1, 0x1

    const-string v2, "SUPPORT AGENT"

    const/high16 v3, 0x41b00000    # 22.0f

    invoke-static {p0, v2, v3, v0, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x11

    .line 119
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 120
    iget-object v1, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private renderReady()V
    .locals 15

    .line 176
    iget-object v0, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 177
    iget-object v0, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 178
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 179
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 180
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v2, 0x41c00000    # 24.0f

    .line 181
    invoke-static {p0, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    const/high16 v4, 0x42280000    # 42.0f

    invoke-static {p0, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v5, 0x41f00000    # 30.0f

    invoke-static {p0, v5}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {v0, v3, v4, v2, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 182
    iget-object v2, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const v2, 0x7f070081

    invoke-static {p0, v1, v2}, Lru/supportagent/WelcomeHero;->create(Landroid/content/Context;II)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v1, 0x1

    .line 184
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v3, 0x11

    .line 185
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 186
    iget-object v4, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v4

    const-string v5, "SUPPORT"

    const/high16 v6, 0x41d80000    # 27.0f

    invoke-static {p0, v5, v6, v4, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 187
    iget-object v4, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v4

    const-string v5, " | "

    const/4 v7, 0x0

    invoke-static {p0, v5, v6, v4, v7}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 188
    iget-object v4, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v4

    const-string v5, "AGENT"

    invoke-static {p0, v5, v6, v4, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v9, -0x1

    const/4 v10, -0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/16 v14, 0x8

    move-object v8, p0

    .line 189
    invoke-static/range {v8 .. v14}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 190
    iget-object v2, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    const-string v4, "\u0413\u041e\u0422\u041e\u0412\u041e \u041a \u0420\u0410\u0411\u041e\u0422\u0415"

    const/high16 v5, 0x41300000    # 11.0f

    invoke-static {p0, v4, v5, v2, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v2

    .line 191
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setGravity(I)V

    const v4, 0x3dcccccd    # 0.1f

    .line 192
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/16 v14, 0x1c

    .line 193
    invoke-static/range {v8 .. v14}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 195
    iget-object v2, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v2}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v2

    .line 196
    iget-object v4, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v4

    const-string v5, "\u041a\u0440\u0443\u0433 \u0443\u0436\u0435 \u043d\u0430 \u044d\u043a\u0440\u0430\u043d\u0435"

    const/high16 v6, 0x41a00000    # 20.0f

    invoke-static {p0, v5, v6, v4, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 197
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v14, 0x9

    .line 198
    invoke-static/range {v8 .. v14}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v2, v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 199
    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v4, "\u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 Black Russia \u2014 \u043f\u043e\u043c\u043e\u0449\u043d\u0438\u043a \u0443\u0436\u0435 \u043d\u0430 \u044d\u043a\u0440\u0430\u043d\u0435."

    const/high16 v5, 0x41600000    # 14.0f

    invoke-static {p0, v4, v5, v1, v7}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 200
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v4, 0x40400000    # 3.0f

    .line 201
    invoke-static {p0, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    int-to-float v4, v4

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-virtual {v1, v4, v5}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v7, -0x1

    const/4 v8, -0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v12, 0xf

    move-object v6, p0

    .line 202
    invoke-static/range {v6 .. v12}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v2, v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 203
    iget-object v1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const/16 v4, 0x23

    invoke-static {v1, v4}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v1

    iget-object v4, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v4

    iget-object v5, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    const-string v6, "\u041e\u0422\u041f\u0420\u0410\u0412\u041a\u0410 \u0422\u041e\u041b\u042c\u041a\u041e \u0412\u0420\u0423\u0427\u041d\u0423\u042e"

    invoke-static {p0, v6, v1, v4, v5}, Lru/supportagent/Ui;->chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;

    move-result-object v1

    .line 204
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v5, -0x1

    const/4 v6, -0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v4, p0

    .line 205
    invoke-static/range {v4 .. v10}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 206
    invoke-static/range {v4 .. v10}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {v0, v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private renderSetup(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
    .locals 14

    move-object v7, p0

    .line 124
    iget-object v0, v7, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 125
    iget-object v0, v7, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    iget-object v1, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 126
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 127
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    .line 128
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 129
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v1, 0x41c00000    # 24.0f

    .line 130
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x42280000    # 42.0f

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/high16 v4, 0x41f00000    # 30.0f

    invoke-static {p0, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v8, v2, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 131
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v3, -0x1

    invoke-direct {v1, v3, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v8, v1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 132
    iget-object v1, v7, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    const v1, 0x7f070081

    invoke-static {p0, v0, v1}, Lru/supportagent/WelcomeHero;->create(Landroid/content/Context;II)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 134
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const-string v1, "SUPPORT"

    const/high16 v2, 0x41d80000    # 27.0f

    invoke-static {p0, v1, v2, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 135
    iget-object v1, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const-string v3, "AGENT"

    invoke-static {p0, v3, v2, v1, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 136
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v11, 0x11

    .line 137
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 138
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 139
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v3, " | "

    const/4 v12, 0x0

    invoke-static {p0, v3, v2, v0, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 140
    invoke-virtual {v10, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x8

    move-object v0, p0

    .line 141
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 142
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v1, "\u0411\u042b\u0421\u0422\u0420\u0410\u042f \u041d\u0410\u0421\u0422\u0420\u041e\u0419\u041a\u0410"

    const/high16 v2, 0x41300000    # 11.0f

    invoke-static {p0, v1, v2, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v10

    const v0, 0x3db851ec    # 0.09f

    .line 143
    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 144
    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v6, 0x1a

    move-object v0, p0

    .line 145
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 147
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v10

    .line 148
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    const/16 v1, 0x24

    invoke-static {v0, v1}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v0

    iget-object v1, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    iget-object v2, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    const-string v3, "01"

    invoke-static {p0, v3, v0, v1, v2}, Lru/supportagent/Ui;->chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;

    move-result-object v13

    const/4 v1, -0x2

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v6, 0xf

    move-object v0, p0

    .line 149
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 150
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const/high16 v1, 0x41980000    # 19.0f

    move-object v2, p1

    invoke-static {p0, p1, v1, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    .line 151
    invoke-virtual {v13, v9}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v6, 0xa

    move-object v0, p0

    .line 152
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 153
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const/high16 v1, 0x41600000    # 14.0f

    move-object/from16 v2, p2

    invoke-static {p0, v2, v1, v0, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    .line 154
    invoke-virtual {v13, v11}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v0, 0x40400000    # 3.0f

    .line 155
    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    int-to-float v0, v0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-virtual {v13, v0, v11}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v6, 0x13

    move-object v0, p0

    .line 156
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 157
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    move-object/from16 v1, p3

    invoke-static {p0, v1, v0, v9}, Lru/supportagent/Ui;->button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;

    move-result-object v13

    .line 158
    new-instance v0, Lru/supportagent/MainActivity$$ExternalSyntheticLambda2;

    move-object/from16 v1, p4

    invoke-direct {v0, v1}, Lru/supportagent/MainActivity$$ExternalSyntheticLambda2;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/4 v6, 0x0

    move-object v0, p0

    .line 159
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v6, 0x11

    move-object v0, p0

    .line 160
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 162
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 163
    invoke-virtual {v10, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v0, 0x41700000    # 15.0f

    .line 164
    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/high16 v2, 0x41500000    # 13.0f

    invoke-static {p0, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-static {p0, v2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v10, v1, v3, v0, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 165
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v0

    const/16 v1, 0x4b

    invoke-static {v0, v1}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v0

    const/high16 v2, 0x41a00000    # 20.0f

    invoke-static {v0, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 166
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    const-string v1, "\u0414\u0410\u041b\u042c\u0428\u0415"

    const/high16 v2, 0x41280000    # 10.5f

    invoke-static {p0, v1, v2, v0, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const v0, 0x3da3d70a    # 0.08f

    .line 167
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x5

    move-object v0, p0

    .line 168
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 169
    iget-object v0, v7, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v1, "\u041a\u0440\u0443\u0433 \u043f\u043e\u044f\u0432\u0438\u0442\u0441\u044f \u0441\u0430\u043c \u2014 \u0432\u043a\u043b\u044e\u0447\u0430\u0442\u044c \u0435\u0433\u043e \u043f\u043e\u0432\u0442\u043e\u0440\u043d\u043e \u043d\u0435 \u043d\u0443\u0436\u043d\u043e."

    const/high16 v2, 0x41480000    # 12.5f

    invoke-static {p0, v1, v2, v0, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const/high16 v1, 0x40000000    # 2.0f

    .line 170
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1, v11}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 171
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v6, 0x0

    move-object v0, p0

    .line 172
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private requestMicrophonePermission()V
    .locals 2

    const-string v0, "android.permission.RECORD_AUDIO"

    .line 62
    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_0

    const/4 v0, 0x1

    .line 64
    invoke-direct {p0, v0}, Lru/supportagent/MainActivity;->returnMicrophonePermission(Z)V

    return-void

    .line 67
    :cond_0
    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x2c7

    invoke-static {p0, v0, v1}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    return-void
.end method

.method private returnMicrophonePermission(Z)V
    .locals 2

    .line 79
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/supportagent/OverlayService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "ru.supportagent.MICROPHONE_PERMISSION_RESULT"

    .line 80
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "microphone_granted"

    .line 81
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p1

    .line 82
    invoke-static {p0, p1}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    .line 84
    invoke-virtual {p0}, Lru/supportagent/MainActivity;->finish()V

    return-void
.end method

.method private startOverlayAutomatically()V
    .locals 2

    .line 219
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/supportagent/OverlayService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "ru.supportagent.SHOW"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 220
    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->startForegroundService(Landroid/content/Context;Landroid/content/Intent;)V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    invoke-static {p0}, Lru/supportagent/GpsShift;->init(Landroid/content/Context;)V

    .line 37
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 38
    invoke-virtual {p0}, Lru/supportagent/MainActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string v0, "ru.supportagent.REQUEST_MICROPHONE"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x1

    if-eqz p1, :cond_0

    .line 39
    iput-boolean v0, p0, Lru/supportagent/MainActivity;->microphonePermissionOnly:Z

    .line 40
    invoke-direct {p0}, Lru/supportagent/MainActivity;->requestMicrophonePermission()V

    return-void

    .line 43
    :cond_0
    new-instance p1, Lru/supportagent/PaletteRepository;

    invoke-direct {p1, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/MainActivity;->palette:Lru/supportagent/AgentPalette;

    .line 44
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    .line 45
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 46
    iget-object p1, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {p0, p1}, Lru/supportagent/MainActivity;->setContentView(Landroid/view/View;)V

    .line 47
    invoke-direct {p0}, Lru/supportagent/MainActivity;->renderLoading()V

    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 0

    .line 72
    invoke-super {p0, p1, p2, p3}, Landroidx/appcompat/app/AppCompatActivity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 p2, 0x2c7

    if-eq p1, p2, :cond_0

    return-void

    .line 74
    :cond_0
    array-length p1, p3

    const/4 p2, 0x0

    if-lez p1, :cond_1

    aget p1, p3, p2

    if-nez p1, :cond_1

    const/4 p2, 0x1

    .line 75
    :cond_1
    invoke-direct {p0, p2}, Lru/supportagent/MainActivity;->returnMicrophonePermission(Z)V

    return-void
.end method

.method protected onResume()V
    .locals 4

    .line 52
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onResume()V

    .line 53
    iget-boolean v0, p0, Lru/supportagent/MainActivity;->microphonePermissionOnly:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lru/supportagent/MainActivity;->root:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_0

    new-instance v1, Lru/supportagent/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lru/supportagent/MainActivity$$ExternalSyntheticLambda0;-><init>(Lru/supportagent/MainActivity;)V

    const-wide/16 v2, 0xb4

    invoke-virtual {v0, v1, v2, v3}, Landroid/widget/LinearLayout;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method
