.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda15;->f$0:Lru/supportagent/OverlayService;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda15;->f$0:Lru/supportagent/OverlayService;

    invoke-virtual {v0, p1}, Lru/supportagent/OverlayService;->lambda$showManageTopics$49$ru-supportagent-OverlayService(Landroid/view/View;)V

    return-void
.end method
