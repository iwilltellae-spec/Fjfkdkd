.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Lru/supportagent/AnswerTemplate;

.field public final synthetic f$2:Lru/supportagent/Topic;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;->f$1:Lru/supportagent/AnswerTemplate;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;->f$2:Lru/supportagent/Topic;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;->f$1:Lru/supportagent/AnswerTemplate;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;->f$2:Lru/supportagent/Topic;

    invoke-virtual {v0, v1, v2}, Lru/supportagent/OverlayService;->lambda$showDeleteAnswerConfirmation$67$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;)V

    return-void
.end method
