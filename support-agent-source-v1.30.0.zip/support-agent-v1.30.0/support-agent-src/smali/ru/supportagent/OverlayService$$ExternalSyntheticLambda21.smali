.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Landroid/widget/EditText;

.field public final synthetic f$2:Landroid/widget/EditText;

.field public final synthetic f$3:Landroid/widget/TextView;

.field public final synthetic f$4:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$1:Landroid/widget/EditText;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$2:Landroid/widget/EditText;

    iput-object p4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$3:Landroid/widget/TextView;

    iput-object p5, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$4:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$1:Landroid/widget/EditText;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$2:Landroid/widget/EditText;

    iget-object v3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$3:Landroid/widget/TextView;

    iget-object v4, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;->f$4:Landroid/widget/TextView;

    invoke-virtual {v0, v1, v2, v3, v4}, Lru/supportagent/OverlayService;->lambda$showAnswerEditor$63$ru-supportagent-OverlayService(Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/TextView;)V

    return-void
.end method
