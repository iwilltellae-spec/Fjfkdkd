.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Lru/supportagent/OverlayService$SearchRenderer;

.field public final synthetic f$2:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$SearchRenderer;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;->f$1:Lru/supportagent/OverlayService$SearchRenderer;

    iput-object p3, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;->f$2:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;->f$1:Lru/supportagent/OverlayService$SearchRenderer;

    iget-object v2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;->f$2:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lru/supportagent/OverlayService;->lambda$scheduleSearchRender$65$ru-supportagent-OverlayService(Lru/supportagent/OverlayService$SearchRenderer;Ljava/lang/String;)V

    return-void
.end method
