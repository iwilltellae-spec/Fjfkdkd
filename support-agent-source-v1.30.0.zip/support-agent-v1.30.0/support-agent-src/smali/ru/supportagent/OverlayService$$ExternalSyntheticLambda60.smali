.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;->f$0:Lru/supportagent/OverlayService;

    iput p2, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;->f$0:Lru/supportagent/OverlayService;

    iget v1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;->f$1:I

    invoke-virtual {v0, v1}, Lru/supportagent/OverlayService;->lambda$restoreScroll$0$ru-supportagent-OverlayService(I)V

    return-void
.end method
