.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda66;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/widget/ScrollView;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/ScrollView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda66;->f$0:Landroid/widget/ScrollView;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda66;->f$0:Landroid/widget/ScrollView;

    invoke-static {v0}, Lru/supportagent/OverlayService;->lambda$selectTopicSection$40(Landroid/widget/ScrollView;)V

    return-void
.end method
