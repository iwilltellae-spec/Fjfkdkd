.class public final synthetic Lru/supportagent/OverlayService$$ExternalSyntheticLambda70;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda70;->f$0:Lru/supportagent/OverlayService;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda70;->f$0:Lru/supportagent/OverlayService;

    invoke-virtual {v0}, Lru/supportagent/OverlayService;->lambda$showManageThemes$52$ru-supportagent-OverlayService()V

    return-void
.end method
