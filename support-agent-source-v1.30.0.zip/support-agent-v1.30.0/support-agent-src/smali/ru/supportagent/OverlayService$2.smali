.class Lru/supportagent/OverlayService$2;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Landroid/speech/RecognitionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/supportagent/OverlayService;->startVoiceRecognition()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lru/supportagent/OverlayService;


# direct methods
.method constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 0

    .line 1559
    iput-object p1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onBeginningOfSpeech()V
    .locals 0

    return-void
.end method

.method public onBufferReceived([B)V
    .locals 0

    return-void
.end method

.method public onEndOfSpeech()V
    .locals 0

    return-void
.end method

.method public onError(I)V
    .locals 3

    .line 1568
    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiListening(Lru/supportagent/OverlayService;)Z

    move-result v0

    .line 1569
    iget-object v1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lru/supportagent/OverlayService;->-$$Nest$fputaiListening(Lru/supportagent/OverlayService;Z)V

    const/4 v1, 0x5

    if-eq p1, v1, :cond_0

    const/16 v1, 0x9

    if-ne p1, v1, :cond_1

    .line 1574
    :cond_0
    iget-object v1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v1}, Lru/supportagent/OverlayService;->-$$Nest$mdestroySpeechRecognizer(Lru/supportagent/OverlayService;)V

    .line 1576
    :cond_1
    iget-object v1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v1}, Lru/supportagent/OverlayService;->-$$Nest$mupdateAiControls(Lru/supportagent/OverlayService;)V

    if-eqz v0, :cond_2

    .line 1577
    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$misAiChatShowing(Lru/supportagent/OverlayService;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 1578
    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0, p1}, Lru/supportagent/OverlayService;->-$$Nest$mspeechErrorText(Lru/supportagent/OverlayService;I)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    invoke-static {v0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_2
    return-void
.end method

.method public onEvent(ILandroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onPartialResults(Landroid/os/Bundle;)V
    .locals 2

    if-nez p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const-string v0, "results_recognition"

    .line 1593
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    :goto_0
    if-eqz p1, :cond_1

    .line 1594
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 1595
    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/CharSequence;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1596
    iget-object p1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object p1

    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->length()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setSelection(I)V

    :cond_1
    return-void
.end method

.method public onReadyForSpeech(Landroid/os/Bundle;)V
    .locals 2

    .line 1561
    iget-object p1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$misAiChatShowing(Lru/supportagent/OverlayService;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    const-string v0, "\u0413\u043e\u0432\u043e\u0440\u0438\u0442\u0435\u2026"

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method

.method public onResults(Landroid/os/Bundle;)V
    .locals 2

    .line 1582
    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lru/supportagent/OverlayService;->-$$Nest$fputaiListening(Lru/supportagent/OverlayService;Z)V

    if-nez p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const-string v0, "results_recognition"

    .line 1584
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    :goto_0
    if-eqz p1, :cond_1

    .line 1585
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 1586
    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/CharSequence;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 1587
    iget-object p1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object p1

    iget-object v0, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/EditText;->length()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setSelection(I)V

    .line 1589
    :cond_1
    iget-object p1, p0, Lru/supportagent/OverlayService$2;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mupdateAiControls(Lru/supportagent/OverlayService;)V

    return-void
.end method

.method public onRmsChanged(F)V
    .locals 0

    return-void
.end method
