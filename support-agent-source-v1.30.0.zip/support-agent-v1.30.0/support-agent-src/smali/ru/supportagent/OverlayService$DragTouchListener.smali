.class final Lru/supportagent/OverlayService$DragTouchListener;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lru/supportagent/OverlayService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "DragTouchListener"
.end annotation


# instance fields
.field private downX:F

.field private downY:F

.field private moved:Z

.field private final slop:I

.field private startX:I

.field private startY:I

.field final synthetic this$0:Lru/supportagent/OverlayService;


# direct methods
.method private constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 1

    .line 289
    iput-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x40a00000    # 5.0f

    .line 293
    invoke-static {p1, v0}, Lru/supportagent/OverlayService;->-$$Nest$mod(Lru/supportagent/OverlayService;F)I

    move-result p1

    iput p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->slop:I

    return-void
.end method

.method synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$DragTouchListener-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService$DragTouchListener;-><init>(Lru/supportagent/OverlayService;)V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3

    .line 296
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p1, :cond_7

    if-eq p1, v1, :cond_4

    const/4 v2, 0x2

    if-eq p1, v2, :cond_0

    return v0

    .line 305
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    iget v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->downX:F

    sub-float/2addr p1, v0

    .line 306
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p2

    iget v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->downY:F

    sub-float/2addr p2, v0

    .line 307
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v2, p0, Lru/supportagent/OverlayService$DragTouchListener;->slop:I

    int-to-float v2, v2

    cmpl-float v0, v0, v2

    if-gtz v0, :cond_1

    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v2, p0, Lru/supportagent/OverlayService$DragTouchListener;->slop:I

    int-to-float v2, v2

    cmpl-float v0, v0, v2

    if-lez v0, :cond_2

    :cond_1
    iput-boolean v1, p0, Lru/supportagent/OverlayService$DragTouchListener;->moved:Z

    .line 308
    :cond_2
    iget-boolean v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->moved:Z

    if-eqz v0, :cond_3

    .line 309
    iget-object v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v2, p0, Lru/supportagent/OverlayService$DragTouchListener;->startX:I

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    add-int/2addr v2, p1

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 310
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    iget v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->startY:I

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    add-int/2addr v0, p2

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 311
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mclampBubble(Lru/supportagent/OverlayService;)V

    .line 312
    :try_start_0
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetwindowManager(Lru/supportagent/OverlayService;)Landroid/view/WindowManager;

    move-result-object p1

    iget-object p2, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p2}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubble(Lru/supportagent/OverlayService;)Landroid/view/View;

    move-result-object p2

    iget-object v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    invoke-interface {p1, p2, v0}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_3
    return v1

    .line 316
    :cond_4
    iget-boolean p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->moved:Z

    if-eqz p1, :cond_5

    .line 317
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$moverlayPreferences(Lru/supportagent/OverlayService;)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object p2, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p2}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p2

    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->x:I

    const-string v0, "bubble_x"

    .line 318
    invoke-interface {p1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object p2, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p2}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p2

    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    const-string v0, "bubble_y"

    invoke-interface {p1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_0

    .line 319
    :cond_5
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanel(Lru/supportagent/OverlayService;)Landroid/view/View;

    move-result-object p1

    if-nez p1, :cond_6

    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mshowHome(Lru/supportagent/OverlayService;)V

    goto :goto_0

    :cond_6
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mclosePanel(Lru/supportagent/OverlayService;)V

    :goto_0
    return v1

    .line 298
    :cond_7
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    iput p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->downX:F

    .line 299
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    iput p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->downY:F

    .line 300
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    iget p1, p1, Landroid/view/WindowManager$LayoutParams;->x:I

    iput p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->startX:I

    .line 301
    iget-object p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    iget p1, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    iput p1, p0, Lru/supportagent/OverlayService$DragTouchListener;->startY:I

    .line 302
    iput-boolean v0, p0, Lru/supportagent/OverlayService$DragTouchListener;->moved:Z

    return v1
.end method
