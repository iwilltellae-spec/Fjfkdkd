.class final Lru/supportagent/OverlayService$PanelDragTouchListener;
.super Ljava/lang/Object;
.source "OverlayService.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lru/supportagent/OverlayService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "PanelDragTouchListener"
.end annotation


# instance fields
.field private downX:F

.field private downY:F

.field private moved:Z

.field private final slop:I

.field private startX:I

.field private startY:I

.field final synthetic this$0:Lru/supportagent/OverlayService;


# direct methods
.method private constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 1

    .line 368
    iput-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x40a00000    # 5.0f

    .line 372
    invoke-static {p1, v0}, Lru/supportagent/OverlayService;->-$$Nest$mod(Lru/supportagent/OverlayService;F)I

    move-result p1

    iput p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->slop:I

    return-void
.end method

.method synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$PanelDragTouchListener-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService$PanelDragTouchListener;-><init>(Lru/supportagent/OverlayService;)V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3

    .line 375
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_6

    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mpanelIsDraggable(Lru/supportagent/OverlayService;)Z

    move-result p1

    if-nez p1, :cond_0

    goto/16 :goto_0

    .line 376
    :cond_0
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result p1

    const/4 v1, 0x1

    if-eqz p1, :cond_5

    if-eq p1, v1, :cond_4

    const/4 v2, 0x2

    if-eq p1, v2, :cond_1

    return v0

    .line 385
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    iget v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->downX:F

    sub-float/2addr p1, v0

    .line 386
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p2

    iget v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->downY:F

    sub-float/2addr p2, v0

    .line 387
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v2, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->slop:I

    int-to-float v2, v2

    cmpl-float v0, v0, v2

    if-gtz v0, :cond_2

    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v2, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->slop:I

    int-to-float v2, v2

    cmpl-float v0, v0, v2

    if-lez v0, :cond_3

    :cond_2
    iput-boolean v1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->moved:Z

    .line 388
    :cond_3
    iget-boolean v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->moved:Z

    if-eqz v0, :cond_4

    .line 389
    iget-object v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v2, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->startX:I

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    add-int/2addr v2, p1

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 390
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    iget v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->startY:I

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    add-int/2addr v0, p2

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 391
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mclampPanel(Lru/supportagent/OverlayService;)V

    .line 392
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p2

    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {p1, p2}, Lru/supportagent/OverlayService;->-$$Nest$fputpanelSessionX(Lru/supportagent/OverlayService;I)V

    .line 393
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p2

    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-static {p1, p2}, Lru/supportagent/OverlayService;->-$$Nest$fputpanelSessionY(Lru/supportagent/OverlayService;I)V

    .line 394
    :try_start_0
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetwindowManager(Lru/supportagent/OverlayService;)Landroid/view/WindowManager;

    move-result-object p1

    iget-object p2, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p2}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanel(Lru/supportagent/OverlayService;)Landroid/view/View;

    move-result-object p2

    iget-object v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {v0}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    invoke-interface {p1, p2, v0}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 395
    :catch_0
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$mrepositionModalOverPanel(Lru/supportagent/OverlayService;)V

    :cond_4
    return v1

    .line 378
    :cond_5
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    iput p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->downX:F

    .line 379
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    iput p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->downY:F

    .line 380
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    iget p1, p1, Landroid/view/WindowManager$LayoutParams;->x:I

    iput p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->startX:I

    .line 381
    iget-object p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->this$0:Lru/supportagent/OverlayService;

    invoke-static {p1}, Lru/supportagent/OverlayService;->-$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    iget p1, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    iput p1, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->startY:I

    .line 382
    iput-boolean v0, p0, Lru/supportagent/OverlayService$PanelDragTouchListener;->moved:Z

    return v1

    :cond_6
    :goto_0
    return v0
.end method
