.class public final Lru/supportagent/OverlayService;
.super Landroid/app/Service;
.source "OverlayService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lru/supportagent/OverlayService$DragTouchListener;,
        Lru/supportagent/OverlayService$PanelDragTouchListener;,
        Lru/supportagent/OverlayService$SearchRenderer;
    }
.end annotation


# static fields
.field public static final ACTION_MICROPHONE_PERMISSION_RESULT:Ljava/lang/String; = "ru.supportagent.MICROPHONE_PERMISSION_RESULT"

.field public static final ACTION_REFRESH:Ljava/lang/String; = "ru.supportagent.REFRESH"

.field public static final ACTION_SHOW:Ljava/lang/String; = "ru.supportagent.SHOW"

.field public static final ACTION_STOP:Ljava/lang/String; = "ru.supportagent.STOP"

.field private static final CHANNEL:Ljava/lang/String; = "support_agent_overlay"

.field public static final EXTRA_MICROPHONE_GRANTED:Ljava/lang/String; = "microphone_granted"

.field private static final FULL_GROUPED_LIST_LIMIT:I = 0x30

.field private static final KEY_LOCK_V13_INITIALIZED:Ljava/lang/String; = "panel_lock_v13_initialized"

.field private static final KEY_PANEL_DRAGGABLE:Ljava/lang/String; = "panel_draggable"

.field private static final MAX_AI_CONTEXT_MESSAGES:I = 0x6

.field private static final MAX_AI_PROMPT_CHARS:I = 0x384

.field private static final MAX_AI_RESPONSE_CHARS:I = 0xc8

.field private static final MAX_AI_STORED_MESSAGES:I = 0xa

.field private static final MAX_VISIBLE_SEARCH_RESULTS:I = 0x12

.field private static final NOTIFICATION_ID:I = 0x264

.field private static final OVERLAY_PREFS:Ljava/lang/String; = "support_agent_overlay"

.field private static final SEARCH_RENDER_DELAY_MS:I = 0x78

.field private static final SECTION_OVERVIEW:Ljava/lang/String; = "__sections__"

.field private static volatile running:Z


# instance fields
.field private activeScroll:Landroid/widget/ScrollView;

.field private activeScrollKey:Ljava/lang/String;

.field private final aiExecutor:Ljava/util/concurrent/ExecutorService;

.field private aiLastError:Ljava/lang/String;

.field private aiListening:Z

.field private aiMessageList:Landroid/widget/LinearLayout;

.field private aiMessageScroll:Landroid/widget/ScrollView;

.field private final aiMessages:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private aiMicButton:Landroid/widget/ImageView;

.field private aiMicPermissionPending:Z

.field private aiPanelWasFocusableBeforeMicPermission:Z

.field private aiPromptField:Landroid/widget/EditText;

.field private aiRequestGeneration:J

.field private aiRequestInFlight:Z

.field private aiSecureStorageError:Ljava/lang/String;

.field private aiSendButton:Landroid/widget/ImageView;

.field private aiSettings:Ljava/lang/Object;

.field private aiStatus:Landroid/widget/TextView;

.field private aiTypingAnimation:Ljava/lang/Runnable;

.field private aiTypingIndicator:Landroid/widget/TextView;

.field private aiTypingPhase:I

.field private bubble:Landroid/view/View;

.field private bubbleParams:Landroid/view/WindowManager$LayoutParams;

.field private modal:Landroid/view/View;

.field private modalParams:Landroid/view/WindowManager$LayoutParams;

.field private openedTopic:Lru/supportagent/Topic;

.field private palette:Lru/supportagent/AgentPalette;

.field private panel:Landroid/view/View;

.field private panelParams:Landroid/view/WindowManager$LayoutParams;

.field private quickAnchor:Landroid/view/View;

.field private quickModal:Z

.field private shiftModal:Z

.field private pinTopic:Lru/supportagent/Topic;

.field private panelSessionX:I

.field private panelSessionY:I

.field private pendingSearchRender:Ljava/lang/Runnable;

.field private repository:Lru/supportagent/TemplateRepository;

.field private final scrollPositions:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final searchHandler:Landroid/os/Handler;

.field private speechRecognizer:Landroid/speech/SpeechRecognizer;

.field private statistics:Lru/supportagent/StatisticsRepository;

.field private final topicSectionFilters:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private windowManager:Landroid/view/WindowManager;


# direct methods
.method public static synthetic $r8$lambda$Y3aUtn6HIePXkKGOEmOTr2q5J6A(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showHome()V

    return-void
.end method

.method public static synthetic $r8$lambda$gzdzSWyne2yZ41omZi7_OjORT6Y(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageTopics()V

    return-void
.end method

.method public static synthetic $r8$lambda$seZD3KyGg1zyRSPBhP-itrFTnSg(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fgetaiListening(Lru/supportagent/OverlayService;)Z
    .locals 0

    iget-boolean p0, p0, Lru/supportagent/OverlayService;->aiListening:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetaiPromptField(Lru/supportagent/OverlayService;)Landroid/widget/EditText;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetaiRequestInFlight(Lru/supportagent/OverlayService;)Z
    .locals 0

    iget-boolean p0, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetaiTypingIndicator(Lru/supportagent/OverlayService;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->aiTypingIndicator:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetaiTypingPhase(Lru/supportagent/OverlayService;)I
    .locals 0

    iget p0, p0, Lru/supportagent/OverlayService;->aiTypingPhase:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetbubble(Lru/supportagent/OverlayService;)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetbubbleParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetpanel(Lru/supportagent/OverlayService;)Landroid/view/View;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetpanelParams(Lru/supportagent/OverlayService;)Landroid/view/WindowManager$LayoutParams;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetsearchHandler(Lru/supportagent/OverlayService;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->searchHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetwindowManager(Lru/supportagent/OverlayService;)Landroid/view/WindowManager;
    .locals 0

    iget-object p0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputaiListening(Lru/supportagent/OverlayService;Z)V
    .locals 0

    iput-boolean p1, p0, Lru/supportagent/OverlayService;->aiListening:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$fputaiTypingPhase(Lru/supportagent/OverlayService;I)V
    .locals 0

    iput p1, p0, Lru/supportagent/OverlayService;->aiTypingPhase:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputpanelSessionX(Lru/supportagent/OverlayService;I)V
    .locals 0

    iput p1, p0, Lru/supportagent/OverlayService;->panelSessionX:I

    return-void
.end method

.method static bridge synthetic -$$Nest$fputpanelSessionY(Lru/supportagent/OverlayService;I)V
    .locals 0

    iput p1, p0, Lru/supportagent/OverlayService;->panelSessionY:I

    return-void
.end method

.method static bridge synthetic -$$Nest$mclampBubble(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->clampBubble()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclampPanel(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->clampPanel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mclosePanel(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->closePanel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mdestroySpeechRecognizer(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->destroySpeechRecognizer()V

    return-void
.end method

.method static bridge synthetic -$$Nest$misAiChatShowing(Lru/supportagent/OverlayService;)Z
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->isAiChatShowing()Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mod(Lru/supportagent/OverlayService;F)I
    .locals 0

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$moverlayPreferences(Lru/supportagent/OverlayService;)Landroid/content/SharedPreferences;
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->overlayPreferences()Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mpanelIsDraggable(Lru/supportagent/OverlayService;)Z
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsDraggable()Z

    move-result p0

    return p0
.end method

.method static bridge synthetic -$$Nest$mrepositionModalOverPanel(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->repositionModalOverPanel()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mscheduleSearchRender(Lru/supportagent/OverlayService;Ljava/lang/String;Lru/supportagent/OverlayService$SearchRenderer;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lru/supportagent/OverlayService;->scheduleSearchRender(Ljava/lang/String;Lru/supportagent/OverlayService$SearchRenderer;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mshowHome(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showHome()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mspeechErrorText(Lru/supportagent/OverlayService;I)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->speechErrorText(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mupdateAiControls(Lru/supportagent/OverlayService;)V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->updateAiControls()V

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    .line 62
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const-string v0, ""

    .line 98
    iput-object v0, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    .line 99
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lru/supportagent/OverlayService;->scrollPositions:Ljava/util/Map;

    .line 100
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, p0, Lru/supportagent/OverlayService;->searchHandler:Landroid/os/Handler;

    .line 103
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    iput-object v1, p0, Lru/supportagent/OverlayService;->aiExecutor:Ljava/util/concurrent/ExecutorService;

    .line 104
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lru/supportagent/OverlayService;->aiMessages:Ljava/util/List;

    .line 106
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSecureStorageError:Ljava/lang/String;

    .line 109
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiLastError:Ljava/lang/String;

    const/4 v0, -0x1

    .line 126
    iput v0, p0, Lru/supportagent/OverlayService;->panelSessionX:I

    .line 127
    iput v0, p0, Lru/supportagent/OverlayService;->panelSessionY:I

    .line 129
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lru/supportagent/OverlayService;->topicSectionFilters:Ljava/util/Map;

    return-void
.end method

.method private addBubble()V
    .locals 7

    const/high16 v0, 0x41c80000    # 25.0f

    .line 242
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const/4 v2, 0x1

    const-string v3, "?"

    invoke-static {p0, v3, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x11

    .line 243
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const-string v1, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c SUPPORT AGENT"

    .line 244
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 245
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    const/high16 v3, 0x41b00000    # 22.0f

    goto :goto_0

    :cond_0
    const/high16 v3, 0x41f00000    # 30.0f

    :goto_0
    invoke-static {v1, v2, v3, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v1, 0x40c00000    # 6.0f

    .line 246
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setElevation(F)V

    .line 247
    new-instance v2, Lru/supportagent/OverlayService$DragTouchListener;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v3}, Lru/supportagent/OverlayService$DragTouchListener;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$DragTouchListener-IA;)V

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 248
    iput-object v0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    .line 249
    invoke-direct {p0}, Lru/supportagent/OverlayService;->bubbleSize()I

    move-result v0

    const/4 v2, 0x0

    .line 250
    invoke-direct {p0, v0, v0, v2}, Lru/supportagent/OverlayService;->overlayParams(IIZ)Landroid/view/WindowManager$LayoutParams;

    move-result-object v3

    iput-object v3, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    const v4, 0x800033

    .line 251
    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 252
    invoke-direct {p0}, Lru/supportagent/OverlayService;->overlayPreferences()Landroid/content/SharedPreferences;

    move-result-object v3

    .line 255
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v4

    sub-int/2addr v4, v0

    div-int/lit8 v4, v4, 0x2

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    const/high16 v4, 0x42400000    # 48.0f

    .line 256
    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v5

    int-to-float v5, v5

    const v6, 0x3f19999a    # 0.6f

    mul-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    div-int/lit8 v0, v0, 0x2

    sub-int/2addr v5, v0

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 257
    iget-object v4, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    const-string v5, "bubble_x"

    invoke-interface {v3, v5, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 258
    iget-object v1, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    const-string v4, "bubble_y"

    invoke-interface {v3, v4, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 259
    invoke-direct {p0}, Lru/supportagent/OverlayService;->clampBubble()V

    .line 260
    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    iget-object v3, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v0, v1, v3}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u043a\u0440\u0443\u0433"

    .line 261
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_1
    return-void
.end method

.method private addSearchLimitNote(Landroid/widget/LinearLayout;II)V
    .locals 8

    .line 2146
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041d\u0430\u0439\u0434\u0435\u043d\u043e: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v0, ". \u041f\u043e\u043a\u0430\u0437\u0430\u043d\u044b \u043f\u0435\u0440\u0432\u044b\u0435 "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string p3, " \u2014 \u0443\u0442\u043e\u0447\u043d\u0438\u0442\u0435 \u0437\u0430\u043f\u0440\u043e\u0441."

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/high16 p3, 0x41280000    # 10.5f

    .line 2148
    invoke-direct {p0, p3}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p3

    iget-object v0, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const/4 v1, 0x0

    .line 2146
    invoke-static {p0, p2, p3, v0, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    const/16 p3, 0x11

    .line 2149
    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 p3, 0x3f800000    # 1.0f

    .line 2150
    invoke-direct {p0, p3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p2, v0, p3}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    move-object v1, p0

    .line 2151
    invoke-direct/range {v1 .. v7}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private addTopicGrid(Landroid/widget/LinearLayout;Ljava/util/List;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;)V"
        }
    .end annotation

    const/4 v7, 0x0

    move v8, v7

    .line 1767
    :goto_0
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    if-ge v8, v0, :cond_1

    .line 1768
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x30

    .line 1769
    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1770
    invoke-interface {p2, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/supportagent/Topic;

    .line 1771
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v1, v7, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v4, 0x40400000    # 3.0f

    .line 1772
    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-virtual {v1, v7, v7, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1773
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->topicCard(Lru/supportagent/Topic;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v9, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v0, v8, 0x1

    .line 1774
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_0

    .line 1775
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v7, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 1776
    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-virtual {v1, v2, v7, v7, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 1777
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/supportagent/Topic;

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->topicCard(Lru/supportagent/Topic;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v9, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_1

    .line 1779
    :cond_0
    new-instance v0, Landroid/widget/Space;

    invoke-direct {v0, p0}, Landroid/widget/Space;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x1

    invoke-direct {v1, v7, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_1
    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object v0, p0

    .line 1781
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {p1, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v8, v8, 0x2

    goto :goto_0

    :cond_1
    return-void
.end method

.method private aiClearIcon()Landroid/widget/ImageView;
    .locals 5

    .line 719
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v1, 0x7f07005f

    .line 720
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v1, -0x1

    .line 721
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 722
    sget-object v1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const-string v1, "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0447\u0430\u0442 AGENT AI"

    .line 723
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x40a00000    # 5.0f

    .line 724
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-virtual {v0, v2, v3, v4, v1}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 725
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    const/high16 v3, 0x40c00000    # 6.0f

    goto :goto_0

    :cond_0
    const/high16 v3, 0x41000000    # 8.0f

    :goto_0
    invoke-static {v1, v2, v3, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x1

    .line 726
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setClickable(Z)V

    return-object v0
.end method

.method private aiHeaderIcon(ILjava/lang/String;)Landroid/widget/ImageView;
    .locals 3

    .line 706
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 707
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 p1, -0x1

    .line 708
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 709
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 710
    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x40a00000    # 5.0f

    .line 711
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p1

    invoke-virtual {v0, p2, v1, v2, p1}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 712
    iget-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result p1

    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :cond_0

    const/high16 v1, 0x40c00000    # 6.0f

    goto :goto_0

    :cond_0
    const/high16 v1, 0x41000000    # 8.0f

    :goto_0
    invoke-static {p1, p2, v1, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 p1, 0x1

    .line 713
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setClickable(Z)V

    return-object v0
.end method

.method private aiIdentityIcon(ILjava/lang/String;)Landroid/widget/ImageView;
    .locals 3

    .line 732
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 733
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 p1, -0x1

    .line 734
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 735
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 736
    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x40000000    # 2.0f

    .line 737
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p1

    invoke-virtual {v0, p2, v1, v2, p1}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 738
    iget-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p1

    const/16 p2, 0x19

    invoke-static {p1, p2}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result p1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result p2

    if-eqz p2, :cond_0

    const/high16 p2, 0x40800000    # 4.0f

    goto :goto_0

    :cond_0
    const/high16 p2, 0x40a00000    # 5.0f

    :goto_0
    invoke-static {p1, p2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private aiMessageCard(Ljava/lang/Object;)Landroid/view/View;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method private aiPromptInput(Landroid/widget/EditText;)Landroid/widget/LinearLayout;
    .locals 14

    .line 759
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 760
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v1, 0x40000000    # 2.0f

    .line 761
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-virtual {v0, v2, v4, v1, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 762
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v4

    const/high16 v5, 0x41100000    # 9.0f

    if-eqz v4, :cond_0

    move v4, v5

    goto :goto_0

    :cond_0
    const/high16 v4, 0x41300000    # 11.0f

    :goto_0
    invoke-static {v1, v2, v4, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 764
    new-instance v1, Landroid/widget/ImageView;

    invoke-direct {v1, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v2, 0x7f070057

    .line 765
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 766
    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 767
    sget-object v2, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v2, 0x40800000    # 4.0f

    .line 768
    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v7

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-virtual {v1, v4, v6, v7, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    const-string v2, "AGENT AI"

    .line 769
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 770
    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    const/16 v4, 0x22

    invoke-static {v2, v4}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v4

    const/high16 v6, 0x40e00000    # 7.0f

    if-eqz v4, :cond_1

    move v5, v6

    :cond_1
    invoke-static {v2, v5, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v8, 0x1f

    const/16 v9, 0x1f

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    move-object v7, p0

    .line 771
    invoke-direct/range {v7 .. v13}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x0

    .line 773
    invoke-virtual {p1, v1}, Landroid/widget/EditText;->setBackgroundColor(I)V

    .line 774
    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    invoke-virtual {p1, v2, v4, v5, v6}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 775
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v2, v1, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private aiSetupFieldLabel(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 3

    const v0, 0x41133333    # 9.2f

    .line 1116
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const/4 v2, 0x1

    invoke-static {p0, p1, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1117
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1118
    sget-object v0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    return-object p1
.end method

.method private aiSetupInputRow(Landroid/widget/EditText;)Landroid/widget/LinearLayout;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method private answerCard(Lru/supportagent/AnswerTemplate;)Landroid/view/View;
    .locals 16

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    .line 1984
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v9

    .line 1985
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1986
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1987
    iget-object v0, v8, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    const/high16 v1, 0x41400000    # 12.0f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    const/4 v11, 0x1

    invoke-static {v7, v0, v1, v2, v11}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const/4 v12, 0x2

    .line 1988
    invoke-virtual {v0, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1989
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1990
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, 0x0

    const/4 v2, -0x2

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v1, v13, v2, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1991
    iget-object v0, v8, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->length(Ljava/lang/String;)I

    move-result v0

    .line 1992
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/120"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v15

    const/16 v1, 0x78

    if-le v0, v1, :cond_0

    .line 1993
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v15, v0}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_0
    const/4 v1, -0x2

    const/4 v2, -0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1994
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1995
    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1996
    iget-object v0, v8, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/high16 v1, 0x41200000    # 10.0f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    invoke-static {v7, v0, v1, v2, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v10

    .line 1997
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_1

    move v12, v11

    :cond_1
    invoke-virtual {v10, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1998
    invoke-direct {v7, v14}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v10, v0, v14}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 1999
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0414\u0410\u0422\u042c \u041e\u0422\u0412\u0415\u0422 \u0418\u0413\u0420\u041e\u041a\u0423"

    .line 2000
    invoke-direct {v7, v0, v11}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    .line 2001
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda61;

    invoke-direct {v0, v7, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda61;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0x1f

    const/4 v4, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2002
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v9
.end method

.method private appearanceCard()Landroid/view/View;
    .locals 14

    .line 2195
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v7

    .line 2196
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 2197
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2198
    new-instance v9, Landroid/widget/ImageView;

    invoke-direct {v9, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070064

    .line 2199
    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 2200
    iget-object v0, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    const/high16 v0, 0x40e00000    # 7.0f

    .line 2201
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v9, v1, v2, v3, v4}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 2202
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    const/high16 v0, 0x40a00000    # 5.0f

    :cond_0
    invoke-static {v1, v2, v0, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v1, 0x1f

    const/16 v2, 0x1f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v5, 0x8

    const/4 v6, 0x0

    move-object v0, p0

    .line 2203
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2204
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x1

    .line 2205
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v0, 0x413ccccd    # 11.8f

    .line 2206
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const-string v2, "\u041e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u0435"

    invoke-static {p0, v2, v0, v1, v11}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 2207
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2208
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    iget-object v1, v1, Lru/supportagent/AgentPalette;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u00b7 \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u0446\u0432\u0435\u0442"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const v1, 0x41133333    # 9.2f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const/4 v12, 0x0

    invoke-static {p0, v0, v1, v2, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    .line 2209
    invoke-virtual {v13, v11}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 2210
    sget-object v0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    move-object v0, p0

    .line 2211
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2212
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v12, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41a80000    # 21.0f

    .line 2213
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const-string v2, "\u203a"

    invoke-static {p0, v2, v0, v1, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v10

    const/16 v0, 0x11

    .line 2214
    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x10

    const/16 v2, 0x18

    const/4 v3, 0x3

    const/4 v4, 0x0

    move-object v0, p0

    .line 2215
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2216
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2217
    invoke-virtual {v7, v11}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 2218
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda45;

    invoke-direct {v0, p0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda45;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2219
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda46;

    invoke-direct {v0, p0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda46;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v7
.end method

.method private applyPanelLockVisual(Landroid/widget/ImageView;Z)V
    .locals 3

    if-eqz p2, :cond_0

    const/4 v0, -0x1

    goto :goto_0

    :cond_0
    const/16 v0, 0x53

    const/16 v1, 0x50

    const/16 v2, 0xef

    .line 781
    invoke-static {v2, v0, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    :goto_0
    if-eqz p2, :cond_1

    const v1, 0x7f070061

    goto :goto_1

    :cond_1
    const v1, 0x7f070060

    .line 782
    :goto_1
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 783
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    if-eqz p2, :cond_2

    const-string v1, "\u041f\u0430\u043d\u0435\u043b\u044c \u0440\u0430\u0437\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u0430\u043d\u0430: \u0442\u044f\u043d\u0438\u0442\u0435 \u0437\u0430 \u0432\u0435\u0440\u0445\u043d\u044e\u044e \u0447\u0430\u0441\u0442\u044c \u0434\u043e \u0437\u0430\u043c\u043a\u0430; \u043d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0437\u0430\u043a\u0440\u0435\u043f\u0438\u0442\u044c"

    goto :goto_2

    :cond_2
    const-string v1, "\u041f\u0430\u043d\u0435\u043b\u044c \u0437\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u0430: \u043d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0440\u0430\u0437\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    .line 784
    :goto_2
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 787
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    if-eqz p2, :cond_3

    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v0

    :cond_3
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result p2

    if-eqz p2, :cond_4

    const/high16 p2, 0x40e00000    # 7.0f

    goto :goto_3

    :cond_4
    const/high16 p2, 0x41200000    # 10.0f

    :goto_3
    invoke-static {v1, v0, p2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method private applyWheelPreview(Lru/supportagent/AgentPalette;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 4

    .line 2298
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v0

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    const/high16 v3, 0x40e00000    # 7.0f

    if-eqz v2, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    const/high16 v2, 0x41100000    # 9.0f

    :goto_0
    invoke-static {v0, v1, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2299
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result p2

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2300
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->colorToHex(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p4, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2301
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    invoke-virtual {p4, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2302
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result p3

    if-eqz p3, :cond_1

    const/high16 v3, 0x40a00000    # 5.0f

    :cond_1
    invoke-static {p2, v3, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {p5, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2303
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p1

    .line 2304
    invoke-static {p1}, Landroid/graphics/Color;->red(I)I

    move-result p2

    mul-int/lit16 p2, p2, 0x12b

    invoke-static {p1}, Landroid/graphics/Color;->green(I)I

    move-result p3

    mul-int/lit16 p3, p3, 0x24b

    add-int/2addr p2, p3

    invoke-static {p1}, Landroid/graphics/Color;->blue(I)I

    move-result p3

    mul-int/lit8 p3, p3, 0x72

    add-int/2addr p2, p3

    div-int/lit16 p2, p2, 0x3e8

    const/16 p3, 0xa5

    if-le p2, p3, :cond_2

    const/16 p2, 0x12

    const/16 p3, 0x20

    const/16 p4, 0xc

    .line 2305
    invoke-static {p4, p2, p3}, Landroid/graphics/Color;->rgb(III)I

    move-result p2

    goto :goto_1

    :cond_2
    const/4 p2, -0x1

    :goto_1
    invoke-virtual {p5, p2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 p2, 0x41600000    # 14.0f

    .line 2306
    invoke-static {p1, p2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {p6, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method private attachPanel(Landroid/view/View;Z)V
    .locals 6

    iget-object v4, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    move-object v5, p1

    .line 465
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    const/high16 v1, 0x41400000    # 12.0f

    if-eqz v0, :cond_0

    .line 466
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v0

    int-to-float v0, v0

    const v2, 0x3f0f5c29    # 0.56f

    mul-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v2

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    sub-int/2addr v2, v1

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    goto :goto_0

    :cond_0
    const/high16 v0, 0x43b20000    # 356.0f

    .line 467
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v2

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    sub-int/2addr v2, v1

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    .line 468
    :goto_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 469
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v1

    int-to-float v1, v1

    const v2, 0x3f570a3d    # 0.84f

    mul-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v2

    const/high16 v3, 0x41200000    # 10.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_1

    :cond_1
    const/high16 v1, 0x44020000    # 520.0f

    .line 470
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v2

    const/high16 v3, 0x42080000    # 34.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    .line 471
    :goto_1
    invoke-direct {p0, v0, v1, p2}, Lru/supportagent/OverlayService;->overlayParams(IIZ)Landroid/view/WindowManager$LayoutParams;

    move-result-object p2

    iput-object p2, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    const v2, 0x800033

    .line 472
    iput v2, p2, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/high16 p2, 0x40c00000    # 6.0f

    .line 475
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v3

    sub-int/2addr v3, v0

    div-int/lit8 v3, v3, 0x2

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 476
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v2

    sub-int/2addr v2, v1

    div-int/lit8 v2, v2, 0x2

    invoke-static {p2, v2}, Ljava/lang/Math;->max(II)I

    move-result p2

    .line 477
    iget-object v1, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v2, p0, Lru/supportagent/OverlayService;->panelSessionX:I

    if-ltz v2, :cond_2

    move v0, v2

    :cond_2
    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 478
    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v1, p0, Lru/supportagent/OverlayService;->panelSessionY:I

    if-ltz v1, :cond_3

    move p2, v1

    :cond_3
    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 479
    invoke-direct {p0}, Lru/supportagent/OverlayService;->clampPanel()V

    .line 480
    iget-object p2, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->x:I

    iput p2, p0, Lru/supportagent/OverlayService;->panelSessionX:I

    .line 481
    iget-object p2, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget p2, p2, Landroid/view/WindowManager$LayoutParams;->y:I

    iput p2, p0, Lru/supportagent/OverlayService;->panelSessionY:I

    .line 482
    iput-object v5, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    .line 484
    :try_start_0
    iget-object p2, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {p2, v5, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->removeOldPanel(Landroid/view/View;)V

    const/4 p1, 0x0

    .line 485
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->setBubbleVisible(Z)V

    .line 486
    invoke-direct {p0}, Lru/supportagent/OverlayService;->restoreScroll()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    const/4 p1, 0x0

    .line 488
    iput-object p1, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    const/4 p1, 0x1

    .line 489
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->setBubbleVisible(Z)V

    :goto_2
    return-void
.end method

.method private bubbleSize()I
    .locals 1

    .line 286
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x42380000    # 46.0f

    goto :goto_0

    :cond_0
    const/high16 v0, 0x42780000    # 62.0f

    :goto_0
    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    return v0
.end method

.method private cancelPendingSearchRender()V
    .locals 2

    .line 2528
    iget-object v0, p0, Lru/supportagent/OverlayService;->pendingSearchRender:Ljava/lang/Runnable;

    if-nez v0, :cond_0

    return-void

    .line 2529
    :cond_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->searchHandler:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    .line 2530
    iput-object v0, p0, Lru/supportagent/OverlayService;->pendingSearchRender:Ljava/lang/Runnable;

    return-void
.end method

.method private centeredIconButton(Ljava/lang/String;IZ)Landroid/widget/LinearLayout;
    .locals 12

    .line 660
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x11

    .line 661
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v2, 0x40c00000    # 6.0f

    .line 662
    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/high16 v4, 0x40400000    # 3.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v0, v3, v5, v2, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/high16 v2, 0x41200000    # 10.0f

    const/high16 v3, 0x40e00000    # 7.0f

    if-eqz p3, :cond_1

    .line 664
    iget-object v4, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v4

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v5

    if-eqz v5, :cond_0

    move v2, v3

    :cond_0
    invoke-static {v4, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    goto :goto_0

    .line 665
    :cond_1
    iget-object v4, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v4

    iget-object v5, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v5}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v5

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v6

    if-eqz v6, :cond_2

    move v2, v3

    :cond_2
    invoke-static {v4, v5, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    .line 663
    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x1

    .line 666
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 667
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 669
    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 670
    invoke-virtual {v4, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 p2, -0x1

    .line 671
    invoke-virtual {v4, p2}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 672
    sget-object v5, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v5, 0x40800000    # 4.0f

    .line 673
    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v7

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v8

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-virtual {v4, v6, v7, v8, v5}, Landroid/widget/ImageView;->setPadding(IIII)V

    if-eqz p3, :cond_3

    const/16 p3, 0x30

    goto :goto_1

    .line 674
    :cond_3
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    const/16 p3, 0x26

    :goto_1
    invoke-static {p2, p3}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result p2

    .line 675
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result p3

    if-eqz p3, :cond_4

    const/high16 v3, 0x40a00000    # 5.0f

    :cond_4
    invoke-static {p2, v3, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {v4, p2}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v6, 0x13

    const/16 v7, 0x13

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    move-object v5, p0

    .line 676
    invoke-direct/range {v5 .. v11}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p2

    invoke-virtual {v0, v4, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const p2, 0x411b3333    # 9.7f

    .line 678
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p2

    iget-object p3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result p3

    invoke-static {p0, p1, p2, p3, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 679
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 680
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 681
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 682
    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 683
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 p3, -0x2

    invoke-direct {p2, p3, p3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private centeredIconButtonBig(Ljava/lang/String;IZ)Landroid/widget/LinearLayout;
    .locals 12

    .line 660
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x11

    .line 661
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v2, 0x40c00000    # 6.0f

    .line 662
    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/high16 v4, 0x40400000    # 3.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v0, v3, v5, v2, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/high16 v2, 0x41200000    # 10.0f

    const/high16 v3, 0x40e00000    # 7.0f

    if-eqz p3, :cond_1

    .line 664
    iget-object v4, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v4

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v5

    if-eqz v5, :cond_0

    move v2, v3

    :cond_0
    invoke-static {v4, v2, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    goto :goto_0

    .line 665
    :cond_1
    iget-object v4, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v4

    iget-object v5, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v5}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v5

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v6

    if-eqz v6, :cond_2

    move v2, v3

    :cond_2
    invoke-static {v4, v5, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    .line 663
    :goto_0
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x1

    .line 666
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 667
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setFocusable(Z)V

    .line 669
    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 670
    invoke-virtual {v4, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 p2, -0x1

    .line 671
    invoke-virtual {v4, p2}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 672
    sget-object v5, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v5, 0x40200000    # 2.5f

    .line 673
    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v7

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v8

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-virtual {v4, v6, v7, v8, v5}, Landroid/widget/ImageView;->setPadding(IIII)V

    if-eqz p3, :cond_3

    const/16 p3, 0x30

    goto :goto_1

    .line 674
    :cond_3
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    const/16 p3, 0x26

    :goto_1
    invoke-static {p2, p3}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result p2

    .line 675
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result p3

    if-eqz p3, :cond_4

    const/high16 v3, 0x40a00000    # 5.0f

    :cond_4
    invoke-static {p2, v3, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {v4, p2}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v6, 0x19

    const/16 v7, 0x19

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    move-object v5, p0

    .line 676
    invoke-direct/range {v5 .. v11}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p2

    invoke-virtual {v0, v4, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const p2, 0x411b3333    # 9.7f

    .line 678
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p2

    iget-object p3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result p3

    invoke-static {p0, p1, p2, p3, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 679
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    .line 680
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 681
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 682
    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 683
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 p3, -0x2

    invoke-direct {p2, p3, p3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private chip(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 5

    .line 828
    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const/high16 v0, 0x41080000    # 8.5f

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const/4 v2, 0x1

    invoke-static {p0, p1, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 829
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v0, 0x40e00000    # 7.0f

    .line 830
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x40400000    # 3.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-virtual {p1, v1, v3, v4, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 831
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const/16 v2, 0x22

    invoke-static {v1, v2}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    const/high16 v0, 0x41600000    # 14.0f

    :goto_0
    invoke-static {v1, v0, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object p1
.end method

.method private clampBubble()V
    .locals 5

    .line 328
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    if-nez v0, :cond_0

    return-void

    .line 329
    :cond_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    iget v1, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v0, v1

    const/high16 v1, 0x40400000    # 3.0f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v0, v2

    const/4 v2, 0x0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 330
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    iget-object v4, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->height:I

    sub-int/2addr v3, v4

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    sub-int/2addr v3, v1

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 331
    iget-object v3, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    iget v4, v3, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {v4, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v3, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 332
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    iget v3, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    return-void
.end method

.method private clampPanel()V
    .locals 5

    .line 361
    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-nez v0, :cond_0

    return-void

    .line 362
    :cond_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v1, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v0, v1

    const/high16 v1, 0x40400000    # 3.0f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v0, v2

    const/4 v2, 0x0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 363
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    iget-object v4, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->height:I

    sub-int/2addr v3, v4

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    sub-int/2addr v3, v1

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 364
    iget-object v3, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v4, v3, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {v4, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v3, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 365
    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v3, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    return-void
.end method

.method private clearAiConversation()V
    .locals 4

    .line 1377
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    if-eqz v0, :cond_0

    .line 1378
    iget-wide v0, p0, Lru/supportagent/OverlayService;->aiRequestGeneration:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lru/supportagent/OverlayService;->aiRequestGeneration:J

    const/4 v0, 0x0

    .line 1379
    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    .line 1381
    :cond_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMessages:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const-string v0, ""

    .line 1382
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiLastError:Ljava/lang/String;

    .line 1383
    invoke-direct {p0}, Lru/supportagent/OverlayService;->renderAiMessages()V

    return-void
.end method

.method private clearAiViewReferences()V
    .locals 1

    .line 1394
    invoke-direct {p0}, Lru/supportagent/OverlayService;->stopAiTypingAnimation()V

    const/4 v0, 0x0

    .line 1395
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiMessageList:Landroid/widget/LinearLayout;

    .line 1396
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiMessageScroll:Landroid/widget/ScrollView;

    .line 1397
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    .line 1398
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiStatus:Landroid/widget/TextView;

    .line 1399
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSendButton:Landroid/widget/ImageView;

    .line 1400
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiMicButton:Landroid/widget/ImageView;

    return-void
.end method

.method private closeModal()V
    .locals 3

    .line 2617
    iget-object v0, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 2618
    :try_start_0
    iget-object v2, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v2, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2619
    :catch_0
    iput-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    .line 2621
    :cond_0
    iput-object v1, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x0

    iput-boolean v2, p0, Lru/supportagent/OverlayService;->quickModal:Z

    iput-boolean v2, p0, Lru/supportagent/OverlayService;->shiftModal:Z

    return-void
.end method

.method private closePanel()V
    .locals 1

    .line 512
    invoke-direct {p0}, Lru/supportagent/OverlayService;->cancelPendingSearchRender()V

    .line 513
    invoke-direct {p0}, Lru/supportagent/OverlayService;->stopVoiceRecognition()V

    .line 514
    invoke-direct {p0}, Lru/supportagent/OverlayService;->saveScroll()V

    .line 515
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 516
    invoke-direct {p0}, Lru/supportagent/OverlayService;->removePanelOnly()V

    .line 517
    invoke-direct {p0}, Lru/supportagent/OverlayService;->clearAiViewReferences()V

    const/4 v0, 0x0

    .line 518
    iput-object v0, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    const-string v0, ""

    .line 519
    iput-object v0, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    .line 520
    invoke-direct {p0}, Lru/supportagent/OverlayService;->resetPanelPlacement()V

    .line 523
    invoke-direct {p0}, Lru/supportagent/OverlayService;->repaintBubble()V

    const/4 v0, 0x1

    .line 524
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->setBubbleVisible(Z)V

    return-void
.end method

.method private colorToHex(I)Ljava/lang/String;
    .locals 3

    .line 2310
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const v2, 0xffffff

    and-int/2addr p1, v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x0

    aput-object p1, v1, v2

    const-string p1, "#%06X"

    invoke-static {v0, p1, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private compact()Z
    .locals 2

    .line 412
    invoke-virtual {p0}, Lru/supportagent/OverlayService;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;
    .locals 5

    const/high16 v0, 0x41280000    # 10.5f

    .line 643
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const/4 v2, 0x1

    invoke-static {p0, p1, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 644
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 645
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 646
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x42000000    # 32.0f

    goto :goto_0

    :cond_0
    const/high16 v0, 0x42200000    # 40.0f

    :goto_0
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/high16 v0, 0x41000000    # 8.0f

    .line 647
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v3, 0x40800000    # 4.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {p1, v1, v4, v0, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const/high16 v0, 0x40e00000    # 7.0f

    const/high16 v1, 0x41200000    # 10.0f

    if-eqz p2, :cond_2

    .line 649
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    move v0, v1

    :goto_1
    invoke-static {p2, v0, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    goto :goto_3

    .line 650
    :cond_2
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result p2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v3

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v4

    if-eqz v4, :cond_3

    goto :goto_2

    :cond_3
    move v0, v1

    :goto_2
    invoke-static {p2, v3, v0, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    .line 648
    :goto_3
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 651
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setClickable(Z)V

    return-object p1
.end method

.method private compactCard()Landroid/widget/LinearLayout;
    .locals 5

    .line 635
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 636
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x41200000    # 10.0f

    .line 637
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    const/high16 v3, 0x41000000    # 8.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 638
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    const/high16 v3, 0x41100000    # 9.0f

    goto :goto_0

    :cond_0
    const/high16 v3, 0x41500000    # 13.0f

    :goto_0
    invoke-static {v1, v2, v3, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private compactText(F)F
    .locals 1

    .line 421
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, 0x3f6b851f    # 0.92f

    mul-float/2addr p1, v0

    :cond_0
    return p1
.end method

.method private composerIconButton(ILjava/lang/String;Z)Landroid/widget/ImageView;
    .locals 3

    .line 744
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 745
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 p1, -0x1

    .line 746
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 747
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 748
    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41000000    # 8.0f

    .line 749
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p1

    invoke-virtual {v0, p2, v1, v2, p1}, Landroid/widget/ImageView;->setPadding(IIII)V

    const/high16 p1, 0x41880000    # 17.0f

    const/high16 p2, 0x41a00000    # 20.0f

    if-eqz p3, :cond_1

    .line 751
    iget-object p3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p3}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p3

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    move p1, p2

    :goto_0
    invoke-static {p3, p1, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    goto :goto_2

    .line 752
    :cond_1
    iget-object p3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p3}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result p3

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_1

    :cond_2
    move p1, p2

    :goto_1
    invoke-static {p3, v1, p1, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    .line 750
    :goto_2
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 p1, 0x1

    .line 753
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setClickable(Z)V

    return-object v0
.end method

.method private copySelectedAiText(Landroid/widget/TextView;)V
    .locals 1

    .line 1404
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->selectedAiFragment(Landroid/widget/TextView;)Ljava/lang/String;

    move-result-object p1

    .line 1405
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p1, "\u0417\u0430\u0436\u043c\u0438\u0442\u0435 \u043e\u0442\u0432\u0435\u0442, \u0432\u044b\u0434\u0435\u043b\u0438\u0442\u0435 \u043d\u0443\u0436\u043d\u044b\u0439 \u0444\u0440\u0430\u0433\u043c\u0435\u043d\u0442 \u0438 \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435."

    const/4 v0, 0x1

    .line 1406
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_0
    const-string v0, "AGENT AI"

    .line 1409
    invoke-direct {p0, v0, p1}, Lru/supportagent/OverlayService;->copyToClipboard(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "\u0412\u044b\u0434\u0435\u043b\u0435\u043d\u043d\u044b\u0439 \u0444\u0440\u0430\u0433\u043c\u0435\u043d\u0442 \u0441\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d."

    const/4 v0, 0x0

    .line 1410
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private copyToClipboard(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    const-string v0, "clipboard"

    .line 1487
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    .line 1488
    invoke-static {p1, p2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    return-void
.end method

.method private countSection(Ljava/util/List;Ljava/lang/String;)I
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/lang/String;",
            ")I"
        }
    .end annotation

    .line 1963
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AnswerTemplate;

    iget-object v2, v1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    if-nez v2, :cond_1

    const-string v1, ""

    goto :goto_1

    :cond_1
    iget-object v1, v1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    :goto_1
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return v0
.end method

.method private createChannel()V
    .locals 4

    .line 211
    new-instance v0, Landroid/app/NotificationChannel;

    const-string v1, "SUPPORT AGENT"

    const/4 v2, 0x1

    const-string v3, "support_agent_overlay"

    invoke-direct {v0, v3, v1, v2}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const-string v1, "\u041a\u0440\u0443\u0433 \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432 \u043f\u043e\u0432\u0435\u0440\u0445 \u0438\u0433\u0440\u044b"

    .line 212
    invoke-virtual {v0, v1}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    const-string v1, "notification"

    .line 213
    invoke-virtual {p0, v1}, Lru/supportagent/OverlayService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/NotificationManager;

    invoke-virtual {v1, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    return-void
.end method

.method private debouncedSearchWatcher(Lru/supportagent/OverlayService$SearchRenderer;)Landroid/text/TextWatcher;
    .locals 1

    .line 2508
    new-instance v0, Lru/supportagent/OverlayService$4;

    invoke-direct {v0, p0, p1}, Lru/supportagent/OverlayService$4;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$SearchRenderer;)V

    return-object v0
.end method

.method private deliverAiReply(Ljava/lang/String;)V
    .locals 1

    .line 1474
    invoke-static {p1}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string p1, "\u0424\u0440\u0430\u0433\u043c\u0435\u043d\u0442 \u0434\u043b\u0438\u043d\u043d\u0435\u0435 120 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432"

    const/4 v0, 0x0

    .line 1475
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 1478
    :cond_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    if-nez v0, :cond_1

    new-instance v0, Lru/supportagent/StatisticsRepository;

    invoke-direct {v0, p0}, Lru/supportagent/StatisticsRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    .line 1479
    :cond_1
    iget-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    invoke-virtual {v0}, Lru/supportagent/StatisticsRepository;->recordConfirmedAnswer()V

    const-string v0, "SUPPORT AGENT"

    .line 1480
    invoke-static {p1}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, v0, p1}, Lru/supportagent/OverlayService;->copyToClipboard(Ljava/lang/String;Ljava/lang/String;)V

    .line 1481
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 1482
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closePanel()V

    const-string p1, "\u041e\u0442\u0432\u0435\u0442 \u0441\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d. \u0412\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u0438 \u043e\u0442\u043f\u0440\u0430\u0432\u044c\u0442\u0435 \u0435\u0433\u043e \u0432 \u0438\u0433\u0440\u0435 \u0441\u0430\u043c\u0438."

    const/4 v0, 0x1

    .line 1483
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private deliverAnswer(Lru/supportagent/AnswerTemplate;)V
    .locals 2

    .line 2091
    iget-object v0, p1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string p1, "\u042d\u0442\u043e\u0442 \u043e\u0442\u0432\u0435\u0442 \u0434\u043b\u0438\u043d\u043d\u0435\u0435 120 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432"

    const/4 v0, 0x0

    .line 2092
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 2095
    :cond_0
    iget-object p1, p1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {p1}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2096
    iget-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    if-nez v0, :cond_1

    new-instance v0, Lru/supportagent/StatisticsRepository;

    invoke-direct {v0, p0}, Lru/supportagent/StatisticsRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    .line 2097
    :cond_1
    iget-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    invoke-virtual {v0}, Lru/supportagent/StatisticsRepository;->recordConfirmedAnswer()V

    const-string v0, "clipboard"

    .line 2098
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    const-string v1, "SUPPORT AGENT"

    .line 2099
    invoke-static {v1, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 2100
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 2101
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closePanel()V

    const-string p1, "\u041e\u0442\u0432\u0435\u0442 \u0441\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d. \u0412\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u0438 \u043e\u0442\u043f\u0440\u0430\u0432\u044c\u0442\u0435 \u0435\u0433\u043e \u0432 \u0438\u0433\u0440\u0435 \u0441\u0430\u043c\u0438."

    const/4 v0, 0x1

    .line 2103
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private destroySpeechRecognizer()V
    .locals 1

    .line 1645
    iget-object v0, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    if-nez v0, :cond_0

    return-void

    .line 1646
    :cond_0
    :try_start_0
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->cancel()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 1647
    :catch_0
    :try_start_1
    iget-object v0, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->destroy()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const/4 v0, 0x0

    .line 1648
    iput-object v0, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    const/4 v0, 0x0

    .line 1649
    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiListening:Z

    return-void
.end method

.method private ensureClosedLockDefault()V
    .locals 4

    .line 345
    invoke-direct {p0}, Lru/supportagent/OverlayService;->overlayPreferences()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "panel_lock_v13_initialized"

    const/4 v2, 0x0

    .line 346
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_0

    .line 347
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "panel_draggable"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v2, 0x1

    .line 348
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :cond_0
    return-void
.end method

.method private finishAiRequest(JLjava/lang/Object;Ljava/lang/String;)V
    .locals 1

    return-void
.end method

.method private focusInput(Landroid/widget/EditText;)V
    .locals 3

    if-eqz p1, :cond_1

    .line 866
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-nez v0, :cond_0

    goto :goto_0

    .line 867
    :cond_0
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda0;-><init>(Lru/supportagent/OverlayService;Landroid/widget/EditText;)V

    const-wide/16 v1, 0xb4

    invoke-virtual {p1, v0, v1, v2}, Landroid/widget/EditText;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1
    :goto_0
    return-void
.end method

.method private hideKeyboard()V
    .locals 3

    .line 877
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsFocusable()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "input_method"

    .line 878
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    .line 879
    iget-object v1, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    :cond_1
    :goto_0
    return-void
.end method

.method private iconButton(ILjava/lang/String;)Landroid/widget/ImageView;
    .locals 2

    const/4 v0, -0x1

    const/16 v1, 0x8

    .line 689
    invoke-direct {p0, p1, p2, v0, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object p1

    return-object p1
.end method

.method private iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;
    .locals 1

    .line 693
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 694
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 695
    invoke-virtual {v0, p3}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 696
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 697
    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    int-to-float p1, p4

    .line 698
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p3

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p4

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p1

    invoke-virtual {v0, p2, p3, p4, p1}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 699
    iget-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result p1

    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result p3

    if-eqz p3, :cond_0

    const/high16 p3, 0x40e00000    # 7.0f

    goto :goto_0

    :cond_0
    const/high16 p3, 0x41200000    # 10.0f

    :goto_0
    invoke-static {p1, p2, p3, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 p1, 0x1

    .line 700
    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setClickable(Z)V

    return-object v0
.end method

.method private input(Ljava/lang/String;Z)Landroid/widget/EditText;
    .locals 5

    .line 836
    new-instance v0, Landroid/view/ContextThemeWrapper;

    sget v1, Lru/supportagent/R$style;->AppTheme:I

    invoke-direct {v0, p0, v1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    new-instance v2, Landroid/widget/EditText;

    invoke-direct {v2, v0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v0, v2

    .line 837
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41480000    # 12.5f

    .line 838
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setTextSize(F)V

    .line 839
    iget-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setTextColor(I)V

    .line 840
    iget-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setHintTextColor(I)V

    if-eqz p2, :cond_0

    const/high16 p1, 0x20000

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    or-int/lit16 p1, p1, 0x4001

    .line 841
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setInputType(I)V

    xor-int/lit8 p1, p2, 0x1

    .line 843
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setSingleLine(Z)V

    if-eqz p2, :cond_1

    const/high16 p1, 0x10000000

    .line 846
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setImeOptions(I)V

    goto :goto_1

    :cond_1
    const/4 p1, 0x1

    .line 848
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setMaxLines(I)V

    .line 849
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setHorizontallyScrolling(Z)V

    const p1, 0x10000006

    .line 852
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setImeOptions(I)V

    .line 853
    new-instance p1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda69;

    invoke-direct {p1, p0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda69;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    :goto_1
    const/high16 p1, 0x41100000    # 9.0f

    .line 860
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    const/high16 v1, 0x40e00000    # 7.0f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v0, p2, v2, v3, v4}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 861
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result p2

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_2

    move p1, v1

    :cond_2
    invoke-static {p2, v2, p1, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private isAiChatShowing()Z
    .locals 2

    .line 1330
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_0

    const-string v0, "ai_chat"

    iget-object v1, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMessageList:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static isRunning()Z
    .locals 1

    .line 131
    sget-boolean v0, Lru/supportagent/OverlayService;->running:Z

    return v0
.end method

.method static synthetic lambda$selectTopicSection$40(Landroid/widget/ScrollView;)V
    .locals 1

    const/4 v0, 0x0

    .line 1889
    invoke-virtual {p0, v0, v0}, Landroid/widget/ScrollView;->scrollTo(II)V

    return-void
.end method

.method static synthetic lambda$shell$5(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 617
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private manageAnswerCard(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)Landroid/view/View;
    .locals 13

    .line 2368
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v0

    .line 2369
    iget-object v1, p2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    const/high16 v2, 0x41400000    # 12.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v3

    const/4 v4, 0x1

    invoke-static {p0, v1, v2, v3, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x2

    .line 2370
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 2371
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 2372
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2373
    iget-object v1, p2, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v1}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/high16 v2, 0x41180000    # 9.5f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const/4 v5, 0x0

    invoke-static {p0, v1, v2, v3, v5}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 2374
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 2375
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v7, -0x1

    const/4 v8, -0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    move-object v6, p0

    .line 2376
    invoke-direct/range {v6 .. v12}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u0418\u0417\u041c\u0415\u041d\u0418\u0422\u042c"

    .line 2377
    invoke-direct {p0, v1, v5}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    .line 2378
    new-instance v2, Lru/supportagent/OverlayService$$ExternalSyntheticLambda13;

    invoke-direct {v2, p0, p1, p2}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda13;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, -0x1

    const/16 v5, 0x1e

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v3, p0

    .line 2379
    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private manageTopicCard(Lru/supportagent/Topic;Z)Landroid/view/View;
    .locals 13

    .line 2314
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v0

    if-eqz p2, :cond_0

    const-string v1, "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043e\u0442\u0432\u0435\u0442\u044b"

    goto :goto_0

    .line 2315
    :cond_0
    iget-object v1, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    :goto_0
    const/high16 v2, 0x41480000    # 12.5f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v3

    const/4 v4, 0x1

    invoke-static {p0, v1, v2, v3, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 2316
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-eqz p2, :cond_1

    .line 2318
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v3, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lru/supportagent/TemplateRepository;->countForTopic(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u043a\u043d\u043e\u043f\u043e\u043a: 4 \u0432\u043d\u0438\u0437\u0443 \u043f\u0430\u043d\u0435\u043b\u0438, \u043e\u0441\u0442\u0430\u043b\u044c\u043d\u044b\u0435 \u0432 \u043c\u0435\u043d\u044e \u22ee"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    .line 2319
    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v3, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lru/supportagent/TemplateRepository;->countForTopic(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u043e\u0442\u0432\u0435\u0442\u043e\u0432 \u0432 \u0442\u0435\u043c\u0435"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_1
    const/high16 v2, 0x41180000    # 9.5f

    .line 2320
    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const/4 v5, 0x0

    .line 2317
    invoke-static {p0, v1, v2, v3, v5}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    const/4 v7, -0x1

    const/4 v8, -0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    move-object v6, p0

    .line 2321
    invoke-direct/range {v6 .. v12}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2322
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v2, "\u041e\u0422\u0412\u0415\u0422\u042b"

    .line 2323
    invoke-direct {p0, v2, v4}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    .line 2324
    new-instance v3, Lru/supportagent/OverlayService$$ExternalSyntheticLambda1;

    invoke-direct {v3, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda1;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2325
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x41f00000    # 30.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v3, v5, v4, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez p2, :cond_2

    const-string p2, "\u0422\u0415\u041c\u0410"

    .line 2327
    invoke-direct {p0, p2, v5}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p2

    .line 2328
    new-instance v2, Lru/supportagent/OverlayService$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda2;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {p2, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v4, 0x41

    const/16 v5, 0x1e

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, p0

    .line 2329
    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p1

    invoke-virtual {v1, p2, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2331
    :cond_2
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-object v0
.end method

.method private notification()Landroid/app/Notification;
    .locals 5

    .line 218
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/supportagent/MainActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v1, 0x0

    const/high16 v2, 0xc000000

    .line 219
    invoke-static {p0, v1, v0, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    .line 221
    new-instance v1, Landroid/content/Intent;

    const-class v3, Lru/supportagent/OverlayService;

    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v3, "ru.supportagent.STOP"

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const/4 v3, 0x1

    .line 222
    invoke-static {p0, v3, v1, v2}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    .line 224
    new-instance v2, Landroidx/core/app/NotificationCompat$Builder;

    const-string v4, "support_agent_overlay"

    invoke-direct {v2, p0, v4}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v4, 0x7f07006d

    .line 227
    invoke-virtual {v2, v4}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v2

    const-string v4, "SUPPORT AGENT \u0430\u043a\u0442\u0438\u0432\u0435\u043d"

    .line 228
    invoke-virtual {v2, v4}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v2

    const-string v4, "\u041a\u0440\u0443\u0433 \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432 \u0433\u043e\u0442\u043e\u0432"

    .line 229
    invoke-virtual {v2, v4}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v2

    .line 230
    invoke-virtual {v2, v0}, Landroidx/core/app/NotificationCompat$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    const v2, 0x7f07005e

    const-string v4, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    .line 233
    invoke-virtual {v0, v2, v4, v1}, Landroidx/core/app/NotificationCompat$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 234
    invoke-virtual {v0, v3}, Landroidx/core/app/NotificationCompat$Builder;->setOnlyAlertOnce(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 235
    invoke-virtual {v0, v3}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    const/4 v1, -0x2

    .line 236
    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setPriority(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 237
    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    return-object v0
.end method

.method private od(F)I
    .locals 1

    .line 417
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_0

    const v0, 0x3f5eb852    # 0.87f

    goto :goto_0

    :cond_0
    const/high16 v0, 0x3f800000    # 1.0f

    :goto_0
    mul-float/2addr p1, v0

    .line 418
    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p1

    return p1
.end method

.method private olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;
    .locals 1

    if-gez p1, :cond_0

    goto :goto_0

    :cond_0
    int-to-float p1, p1

    .line 427
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p1

    :goto_0
    if-gez p2, :cond_1

    goto :goto_1

    :cond_1
    int-to-float p2, p2

    .line 428
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    .line 429
    :goto_1
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, p1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    int-to-float p1, p3

    .line 430
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->od(F)I

    move-result p1

    int-to-float p2, p4

    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->od(F)I

    move-result p2

    int-to-float p3, p5

    invoke-direct {p0, p3}, Lru/supportagent/OverlayService;->od(F)I

    move-result p3

    int-to-float p4, p6

    invoke-direct {p0, p4}, Lru/supportagent/OverlayService;->od(F)I

    move-result p4

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    return-object v0
.end method

.method private onMicrophonePermissionResult(Z)V
    .locals 1

    .line 1531
    invoke-direct {p0}, Lru/supportagent/OverlayService;->restoreAiAfterMicrophonePermission()V

    if-nez p1, :cond_0

    const-string p1, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u0432 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u043e\u043c \u043e\u043a\u043d\u0435, \u0447\u0442\u043e\u0431\u044b \u0434\u0438\u043a\u0442\u043e\u0432\u0430\u0442\u044c \u0432\u043e\u043f\u0440\u043e\u0441."

    const/4 v0, 0x1

    .line 1533
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 1536
    :cond_0
    iget-object p1, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    if-eqz p1, :cond_2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->isAiChatShowing()Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    .line 1540
    :cond_1
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 1541
    iget-object p1, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->clearFocus()V

    .line 1542
    invoke-direct {p0}, Lru/supportagent/OverlayService;->startVoiceRecognition()V

    return-void

    :cond_2
    :goto_0
    const-string p1, "\u041c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043d. \u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 AGENT AI \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u0435\u0433\u043e \u0435\u0449\u0451 \u0440\u0430\u0437."

    const/4 v0, 0x0

    .line 1537
    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private overlayParams(IIZ)Landroid/view/WindowManager$LayoutParams;
    .locals 7

    const/16 v3, 0x7f6

    if-nez p3, :cond_0

    const/16 v0, 0x328

    goto :goto_0

    :cond_0
    const/16 v0, 0x320

    :goto_0
    move v4, v0

    .line 442
    new-instance v6, Landroid/view/WindowManager$LayoutParams;

    const/4 v5, -0x3

    move-object v0, v6

    move v1, p1

    move v2, p2

    invoke-direct/range {v0 .. v5}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    if-eqz p3, :cond_1

    const/16 p1, 0x30

    .line 446
    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->softInputMode:I

    :cond_1
    return-object v6
.end method

.method private overlayPreferences()Landroid/content/SharedPreferences;
    .locals 2

    const-string v0, "support_agent_overlay"

    const/4 v1, 0x0

    .line 340
    invoke-virtual {p0, v0, v1}, Lru/supportagent/OverlayService;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    return-object v0
.end method

.method private pageList()Landroid/widget/LinearLayout;
    .locals 5

    .line 555
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 556
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x3f800000    # 1.0f

    .line 557
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v4, 0x40000000    # 2.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v0, v2, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    return-object v0
.end method

.method private pageScroll()Landroid/widget/ScrollView;
    .locals 2

    .line 547
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 548
    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    const/4 v1, 0x0

    .line 549
    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->setClipToPadding(Z)V

    .line 550
    iput-object v0, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    return-object v0
.end method

.method private panelIsDraggable()Z
    .locals 3

    .line 353
    invoke-direct {p0}, Lru/supportagent/OverlayService;->overlayPreferences()Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "panel_draggable"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    return v0
.end method

.method private panelIsFocusable()Z
    .locals 1

    .line 501
    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v0, :cond_0

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    and-int/lit8 v0, v0, 0x8

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private pasteAiKey(Landroid/widget/EditText;)V
    .locals 1

    return-void
.end method

.method private positionModalAtPanelCenter(Landroid/view/WindowManager$LayoutParams;II)V
    .locals 4

    .line 2599
    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v0, :cond_0

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    iget-object v1, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v1, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    .line 2600
    :goto_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v1, :cond_1

    iget v1, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    iget-object v2, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v2, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    div-int/lit8 v2, v2, 0x2

    add-int/2addr v1, v2

    goto :goto_1

    :cond_1
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    :goto_1
    const/high16 v2, 0x40c00000    # 6.0f

    .line 2601
    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    .line 2602
    div-int/lit8 v3, p2, 0x2

    sub-int/2addr v0, v3

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v3

    sub-int/2addr v3, p2

    sub-int/2addr v3, v2

    invoke-static {v0, v3}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-static {v2, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    iput p2, p1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 2603
    div-int/lit8 p2, p3, 0x2

    sub-int/2addr v1, p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result p2

    sub-int/2addr p2, p3

    sub-int/2addr p2, v2

    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-static {v2, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    iput p2, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    return-void
.end method

.method private positionQuickOverflow()V
    .locals 10

    iget-object v0, p0, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    if-eqz v0, :pq_exit

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v1, :pq_exit

    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v2, :pq_exit

    const/4 v3, 0x2

    new-array v3, v3, [I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v4, 0x0

    aget v4, v3, v4

    const/4 v5, 0x1

    aget v5, v3, v5

    const/high16 v6, 0x41000000    # 8.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v8

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v4, v6

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    sub-int/2addr v4, v6

    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    sub-int/2addr v5, v8

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    sub-int/2addr v3, v8

    sub-int/2addr v3, v6

    iget-object v9, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v9, :pq_panel_done

    iget v7, v9, Landroid/view/WindowManager$LayoutParams;->y:I

    iget v9, v9, Landroid/view/WindowManager$LayoutParams;->height:I

    add-int/2addr v7, v9

    sub-int/2addr v7, v8

    sub-int/2addr v7, v6

    if-le v3, v7, :pq_panel_done

    move v3, v7

    :pq_panel_done
    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v7, 0x0

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v5, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :pq_exit

    :pq_exit
    return-void
.end method

.method private removeOldPanel(Landroid/view/View;)V
    .locals 2

    if-eqz p1, :ro_exit

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, p1}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :ro_exit

    :ro_exit
    return-void
.end method

.method public refreshGpsShift()V
    .locals 1

    iget-object v0, p0, Lru/supportagent/OverlayService;->openedTopic:Lru/supportagent/Topic;

    if-eqz v0, :gps_refresh_done

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->showTemplates(Lru/supportagent/Topic;)V

    :gps_refresh_done
    return-void
.end method

.method private preparePage(Ljava/lang/String;)V
    .locals 1

    .line 452
    invoke-direct {p0}, Lru/supportagent/OverlayService;->cancelPendingSearchRender()V

    .line 453
    invoke-direct {p0}, Lru/supportagent/OverlayService;->stopVoiceRecognition()V

    .line 454
    invoke-direct {p0}, Lru/supportagent/OverlayService;->saveScroll()V

    .line 455
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 456
    .line 457
    invoke-direct {p0}, Lru/supportagent/OverlayService;->clearAiViewReferences()V

    const/4 v0, 0x0

    .line 458
    iput-object v0, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    .line 459
    iput-object p1, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    return-void
.end method

.method private quickButton(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 5

    const/high16 v0, 0x41200000    # 10.0f

    .line 806
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    const/16 v1, 0x1f

    const/16 v2, 0x30

    const/16 v3, 0x14

    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    const/4 v2, 0x1

    invoke-static {p0, p1, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 807
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 808
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    const/high16 v0, 0x41f80000    # 31.0f

    .line 809
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/high16 v0, 0x41300000    # 11.0f

    .line 810
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v3, 0x40400000    # 3.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {p1, v1, v4, v0, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 811
    invoke-direct {p0}, Lru/supportagent/OverlayService;->raisedQuickBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v0, 0x40000000    # 2.0f

    .line 812
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setElevation(F)V

    .line 813
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setClickable(Z)V

    return-object p1
.end method

.method private raisedQuickBackground()Landroid/graphics/drawable/Drawable;
    .locals 9

    .line 818
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x40e00000    # 7.0f

    goto :goto_0

    :cond_0
    const/high16 v0, 0x41200000    # 10.0f

    :goto_0
    const/16 v1, 0xc3

    const/16 v2, 0xd4

    const/16 v3, 0xb5

    .line 819
    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-static {v1, v0, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    const/16 v2, 0xfd

    const/16 v3, 0xff

    const/16 v4, 0xfc

    .line 820
    invoke-static {v4, v2, v3}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    const/16 v3, 0xe7

    const/16 v4, 0xef

    const/16 v5, 0xe0

    invoke-static {v5, v3, v4}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-static {v2, v3, v0, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    .line 821
    new-instance v8, Landroid/graphics/drawable/LayerDrawable;

    const/4 v2, 0x2

    new-array v2, v2, [Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    aput-object v1, v2, v3

    const/4 v1, 0x1

    aput-object v0, v2, v1

    invoke-direct {v8, v2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/high16 v0, 0x40000000    # 2.0f

    .line 823
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v7

    move-object v2, v8

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    return-object v8
.end method

.method private recentAiContext()Ljava/util/List;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method private removeBubble()V
    .locals 2

    .line 278
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    if-eqz v0, :cond_0

    .line 279
    :try_start_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v0, 0x0

    .line 280
    iput-object v0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    :cond_0
    return-void
.end method

.method private removePanelOnly()V
    .locals 2

    .line 505
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_0

    .line 506
    :try_start_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v0, 0x0

    .line 507
    iput-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    :cond_0
    return-void
.end method

.method private renderAiMessages()V
    .locals 1

    return-void
.end method

.method private renderSearchResults(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 10

    .line 2125
    invoke-virtual {p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    const/4 v0, 0x0

    if-eqz p2, :cond_4

    .line 2126
    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_2

    .line 2132
    :cond_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    const/16 v2, 0x12

    invoke-virtual {v1, p2, v2}, Lru/supportagent/TemplateRepository;->searchAll(Ljava/lang/String;I)Lru/supportagent/TemplateRepository$SearchResults;

    move-result-object p2

    .line 2133
    iget-object v1, p2, Lru/supportagent/TemplateRepository$SearchResults;->hits:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/TemplateRepository$SearchHit;

    .line 2134
    iget-object v3, v2, Lru/supportagent/TemplateRepository$SearchHit;->answer:Lru/supportagent/AnswerTemplate;

    iget-object v2, v2, Lru/supportagent/TemplateRepository$SearchHit;->topicName:Ljava/lang/String;

    invoke-direct {p0, v3, v2}, Lru/supportagent/OverlayService;->searchResultCard(Lru/supportagent/AnswerTemplate;Ljava/lang/String;)Landroid/view/View;

    move-result-object v2

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    move-object v3, p0

    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {p1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    .line 2136
    :cond_1
    iget v1, p2, Lru/supportagent/TemplateRepository$SearchResults;->total:I

    if-nez v1, :cond_2

    const/high16 p2, 0x41380000    # 11.5f

    .line 2137
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p2

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e."

    invoke-static {p0, v2, p2, v1, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    const/16 v0, 0x11

    .line 2138
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/4 v4, 0x0

    const/16 v5, 0x12

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v1, p0

    .line 2139
    invoke-direct/range {v1 .. v7}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_1

    .line 2140
    :cond_2
    iget v0, p2, Lru/supportagent/TemplateRepository$SearchResults;->total:I

    iget-object v1, p2, Lru/supportagent/TemplateRepository$SearchResults;->hits:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-le v0, v1, :cond_3

    .line 2141
    iget v0, p2, Lru/supportagent/TemplateRepository$SearchResults;->total:I

    iget-object p2, p2, Lru/supportagent/TemplateRepository$SearchResults;->hits:Ljava/util/List;

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p2

    invoke-direct {p0, p1, v0, p2}, Lru/supportagent/OverlayService;->addSearchLimitNote(Landroid/widget/LinearLayout;II)V

    :cond_3
    :goto_1
    return-void

    :cond_4
    :goto_2
    const/high16 p2, 0x41300000    # 11.0f

    .line 2127
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p2

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0418\u0449\u0435\u043c \u043f\u043e \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044e \u0442\u0435\u043c\u044b, \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044e \u043e\u0442\u0432\u0435\u0442\u0430 \u0438 \u0432\u0441\u0435\u043c\u0443 \u0442\u0435\u043a\u0441\u0442\u0443 \u0448\u0430\u0431\u043b\u043e\u043d\u043e\u0432."

    invoke-static {p0, v2, p2, v1, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    const/high16 v0, 0x3f800000    # 1.0f

    .line 2128
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p2, v1, v0}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v3, -0x1

    const/4 v4, -0x2

    const/4 v5, 0x0

    const/16 v6, 0xc

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v2, p0

    .line 2129
    invoke-direct/range {v2 .. v8}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private renderSectionChips(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Lru/supportagent/Topic;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;[",
            "Ljava/lang/String;",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/ScrollView;",
            ")V"
        }
    .end annotation

    move-object/from16 v10, p0

    move-object/from16 v11, p1

    .line 1859
    invoke-virtual/range {p1 .. p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    const/4 v12, 0x0

    .line 1860
    aget-object v0, p5, v12

    const-string v1, "__sections__"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "\u0420\u0430\u0437\u0434\u0435\u043b\u044b"

    invoke-direct {v10, v1, v0}, Lru/supportagent/OverlayService;->selectedSectionChip(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v9

    .line 1861
    new-instance v13, Lru/supportagent/OverlayService$$ExternalSyntheticLambda32;

    move-object v0, v13

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda32;-><init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x2

    const/16 v2, 0x1c

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1863
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1867
    invoke-interface/range {p3 .. p3}, Ljava/util/List;->size()I

    move-result v0

    const/16 v1, 0x30

    if-gt v0, v1, :cond_0

    .line 1868
    aget-object v0, p5, v12

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const-string v1, "\u0412\u0441\u0435"

    invoke-direct {v10, v1, v0}, Lru/supportagent/OverlayService;->selectedSectionChip(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v9

    .line 1869
    new-instance v13, Lru/supportagent/OverlayService$$ExternalSyntheticLambda34;

    move-object v0, v13

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda34;-><init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x2

    const/16 v2, 0x1c

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1871
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1873
    :cond_0
    invoke-interface/range {p4 .. p4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/lang/String;

    .line 1874
    aget-object v0, p5, v12

    invoke-virtual {v9, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-direct {v10, v9, v0}, Lru/supportagent/OverlayService;->selectedSectionChip(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v14

    .line 1875
    new-instance v15, Lru/supportagent/OverlayService$$ExternalSyntheticLambda35;

    move-object v0, v15

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v9}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda35;-><init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x2

    const/16 v2, 0x1c

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1877
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_1
    return-void
.end method

.method private renderSectionOverview(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Lru/supportagent/Topic;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;[",
            "Ljava/lang/String;",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/ScrollView;",
            ")V"
        }
    .end annotation

    move-object/from16 v10, p0

    move-object/from16 v11, p1

    .line 1906
    invoke-virtual/range {p1 .. p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 1907
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u0412\u042b\u0411\u0415\u0420\u0418\u0422\u0415 \u0420\u0410\u0417\u0414\u0415\u041b \u00b7 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-interface/range {p3 .. p3}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u041e\u0422\u0412\u0415\u0422\u041e\u0412"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const v1, 0x4114cccd    # 9.3f

    invoke-direct {v10, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v10, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const/4 v12, 0x1

    invoke-static {v10, v0, v1, v2, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v7

    const v0, 0x3d4ccccd    # 0.05f

    .line 1908
    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 1909
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1910
    invoke-interface/range {p4 .. p4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/lang/String;

    move-object/from16 v14, p3

    .line 1911
    invoke-direct {v10, v14, v9}, Lru/supportagent/OverlayService;->countSection(Ljava/util/List;Ljava/lang/String;)I

    move-result v7

    .line 1912
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v15

    const/high16 v0, 0x42400000    # 48.0f

    .line 1913
    invoke-direct {v10, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 1914
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1915
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1916
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1917
    iget-object v0, v10, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :cond_0

    const/high16 v1, 0x40000000    # 2.0f

    goto :goto_1

    :cond_0
    const/high16 v1, 0x40800000    # 4.0f

    :goto_1
    invoke-static {v0, v1, v10}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x3

    const/16 v2, 0x17

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v5, 0x8

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move-object v12, v6

    move/from16 v6, v16

    .line 1918
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1919
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-direct {v12, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 1920
    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v1, 0x41366666    # 11.4f

    .line 1921
    invoke-direct {v10, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v10, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    invoke-static {v10, v9, v1, v2, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 1922
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1923
    sget-object v0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1924
    invoke-virtual {v12, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1925
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const v1, 0x410ccccd    # 8.8f

    invoke-direct {v10, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v10, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const/4 v7, 0x0

    invoke-static {v10, v0, v1, v2, v7}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v6

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move-object v7, v6

    move/from16 v6, v16

    .line 1926
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    .line 1925
    invoke-virtual {v12, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1927
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41a80000    # 21.0f

    .line 1928
    invoke-direct {v10, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v10, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const-string v2, "\u203a"

    invoke-static {v10, v2, v0, v1, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v7

    const/16 v0, 0x11

    .line 1929
    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x10

    const/16 v2, 0x18

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1930
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1931
    invoke-virtual {v15, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v12, 0x1

    .line 1932
    invoke-virtual {v15, v12}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 1933
    new-instance v8, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;

    move-object v0, v8

    move-object/from16 v1, p0

    move-object/from16 v2, p6

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p1

    move-object v12, v8

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v9}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda37;-><init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V

    invoke-virtual {v15, v12}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 1935
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v12, 0x1

    goto/16 :goto_0

    :cond_1
    return-void
.end method

.method private renderTopicAnswers(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    .line 1941
    invoke-virtual/range {p1 .. p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 1944
    invoke-interface/range {p2 .. p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    const/4 v0, 0x0

    const/4 v11, 0x0

    :goto_0
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v12, v1

    check-cast v12, Lru/supportagent/AnswerTemplate;

    .line 1945
    iget-object v1, v12, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    if-nez v1, :cond_0

    const-string v1, ""

    goto :goto_1

    :cond_0
    iget-object v1, v12, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    :goto_1
    move-object v13, v1

    .line 1946
    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    move-object/from16 v14, p3

    if-nez v1, :cond_1

    invoke-virtual {v14, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_0

    .line 1947
    :cond_1
    invoke-virtual {v13, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    .line 1948
    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    move-object/from16 v15, p2

    if-nez v0, :cond_4

    invoke-direct {v7, v15, v13}, Lru/supportagent/OverlayService;->countSection(Ljava/util/List;Ljava/lang/String;)I

    move-result v0

    invoke-direct {v7, v13, v0}, Lru/supportagent/OverlayService;->sectionHeader(Ljava/lang/String;I)Landroid/view/View;

    move-result-object v6

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    if-nez v11, :cond_2

    const/4 v4, 0x0

    goto :goto_2

    :cond_2
    const/4 v0, 0x5

    move v4, v0

    :goto_2
    const/4 v5, 0x0

    const/16 v16, 0x5

    move-object/from16 v0, p0

    move-object v10, v6

    move/from16 v6, v16

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_3

    :cond_3
    move-object/from16 v15, p2

    move-object v13, v0

    .line 1951
    :cond_4
    :goto_3
    invoke-direct {v7, v12}, Lru/supportagent/OverlayService;->answerCard(Lru/supportagent/AnswerTemplate;)Landroid/view/View;

    move-result-object v10

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v11, v11, 0x1

    move-object v0, v13

    goto :goto_0

    :cond_5
    if-nez v11, :cond_6

    const/high16 v0, 0x41380000    # 11.5f

    .line 1955
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0412 \u044d\u0442\u043e\u0439 \u0442\u0435\u043c\u0435 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442 \u043f\u043e\u0434\u0445\u043e\u0434\u044f\u0449\u0438\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432."

    const/4 v3, 0x0

    invoke-static {v7, v2, v0, v1, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const/16 v0, 0x11

    .line 1956
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v4, 0x12

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1957
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_6
    return-void
.end method

.method private renderTopicContent(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Lru/supportagent/Topic;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;[",
            "Ljava/lang/String;",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/ScrollView;",
            ")V"
        }
    .end annotation

    const/4 v0, 0x0

    .line 1895
    aget-object v1, p5, v0

    const-string v2, "__sections__"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p4}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    .line 1896
    invoke-direct/range {p0 .. p7}, Lru/supportagent/OverlayService;->renderSectionOverview(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    goto :goto_0

    .line 1898
    :cond_0
    aget-object p2, p5, v0

    invoke-direct {p0, p1, p3, p2}, Lru/supportagent/OverlayService;->renderTopicAnswers(Landroid/widget/LinearLayout;Ljava/util/List;Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method private renderTopicSearchResults(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/lang/String;)V
    .locals 17

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-object/from16 v9, p2

    .line 2025
    invoke-virtual/range {p1 .. p1}, Landroid/widget/LinearLayout;->removeAllViews()V

    const-string v10, ""

    if-nez p3, :cond_0

    move-object v11, v10

    goto :goto_0

    .line 2026
    :cond_0
    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    move-object v11, v0

    .line 2027
    :goto_0
    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v12, 0x0

    if-eqz v0, :cond_1

    const/high16 v0, 0x41300000    # 11.0f

    .line 2028
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041f\u043e\u0438\u0441\u043a \u043f\u043e \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044e, \u0440\u0430\u0437\u0434\u0435\u043b\u0443, \u043a\u043e\u043c\u0430\u043d\u0434\u0435 \u0438 \u0442\u0435\u043a\u0441\u0442\u0443 \u043e\u0442\u0432\u0435\u0442\u0430."

    invoke-static {v7, v2, v0, v1, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const/high16 v0, 0x3f800000    # 1.0f

    .line 2029
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v9, v1, v0}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v4, 0xc

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2030
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void

    .line 2035
    :cond_1
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v1, v9, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->getTemplates(Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    move v0, v12

    move v14, v0

    :goto_1
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/supportagent/AnswerTemplate;

    .line 2036
    iget-object v2, v1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    if-nez v2, :cond_2

    move-object v2, v10

    goto :goto_2

    :cond_2
    iget-object v2, v1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    .line 2037
    :goto_2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v9, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v1, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v3}, Lru/supportagent/GpsShift;->apply(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    .line 2038
    invoke-virtual {v2, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3

    goto :goto_1

    :cond_3
    add-int/lit8 v15, v0, 0x1

    const/16 v0, 0x12

    if-lt v14, v0, :cond_4

    move v0, v15

    goto :goto_1

    .line 2041
    :cond_4
    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->answerCard(Lru/supportagent/AnswerTemplate;)Landroid/view/View;

    move-result-object v6

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v16, 0x6

    move-object/from16 v0, p0

    move-object v12, v6

    move/from16 v6, v16

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v14, v14, 0x1

    move v0, v15

    const/4 v12, 0x0

    goto :goto_1

    :cond_5
    if-nez v0, :cond_6

    const/high16 v0, 0x41380000    # 11.5f

    .line 2045
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0412 \u044d\u0442\u043e\u0439 \u0442\u0435\u043c\u0435 \u043d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e."

    const/4 v3, 0x0

    invoke-static {v7, v2, v0, v1, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const/16 v0, 0x11

    .line 2046
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v4, 0x12

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2047
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_3

    :cond_6
    if-le v0, v14, :cond_7

    .line 2049
    invoke-direct {v7, v8, v0, v14}, Lru/supportagent/OverlayService;->addSearchLimitNote(Landroid/widget/LinearLayout;II)V

    :cond_7
    :goto_3
    return-void
.end method

.method private repaintBubble()V
    .locals 1

    .line 265
    iget-object v0, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->repaintBubble(Lru/supportagent/AgentPalette;)V

    return-void
.end method

.method private repaintBubble(Lru/supportagent/AgentPalette;)V
    .locals 3

    .line 270
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    instance-of v1, v0, Landroid/widget/TextView;

    if-eqz v1, :cond_2

    if-nez p1, :cond_0

    goto :goto_1

    .line 271
    :cond_0
    check-cast v0, Landroid/widget/TextView;

    .line 272
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v1, 0x41c80000    # 25.0f

    .line 273
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 274
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    if-eqz v2, :cond_1

    const/high16 v2, 0x41b00000    # 22.0f

    goto :goto_0

    :cond_1
    const/high16 v2, 0x41f00000    # 30.0f

    :goto_0
    invoke-static {v1, p1, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_2
    :goto_1
    return-void
.end method

.method private repositionModalOverPanel()V
    .locals 3

    .line 2608
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->quickModal:Z

    if-eqz v0, :qm_normal

    iget-boolean v1, p0, Lru/supportagent/OverlayService;->shiftModal:Z

    if-eqz v1, :qm_quick

    invoke-direct {p0}, Lru/supportagent/OverlayService;->positionShiftMenu()V

    return-void

    :qm_quick
    invoke-direct {p0}, Lru/supportagent/OverlayService;->positionQuickOverflow()V

    return-void

    :qm_normal
    iget-object v0, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v0, :cond_4

    iget-object v1, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v1, :cond_4

    iget-object v1, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-nez v1, :cond_0

    goto :goto_2

    .line 2609
    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-lez v0, :cond_1

    iget-object v0, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    .line 2610
    :goto_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    if-lez v1, :cond_2

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    goto :goto_1

    :cond_2
    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    :goto_1
    if-lez v0, :cond_4

    if-gtz v1, :cond_3

    goto :goto_2

    .line 2612
    :cond_3
    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    invoke-direct {p0, v2, v0, v1}, Lru/supportagent/OverlayService;->positionModalAtPanelCenter(Landroid/view/WindowManager$LayoutParams;II)V

    .line 2613
    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_4
    :goto_2
    return-void
.end method

.method private requestVoiceInput()V
    .locals 3

    .line 1492
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    if-eqz v0, :cond_0

    return-void

    .line 1493
    :cond_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    const/4 v1, 0x0

    if-nez v0, :cond_1

    const-string v0, "\u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 AGENT AI \u0438 \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435."

    .line 1494
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    .line 1497
    :cond_1
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiListening:Z

    if-eqz v0, :cond_2

    .line 1498
    invoke-direct {p0}, Lru/supportagent/OverlayService;->stopVoiceRecognition()V

    const-string v0, "\u0413\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0439 \u0432\u0432\u043e\u0434 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d."

    .line 1499
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    .line 1502
    :cond_2
    invoke-static {p0}, Landroid/speech/SpeechRecognizer;->isRecognitionAvailable(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x1

    if-nez v0, :cond_3

    const-string v0, "\u041d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0435 \u043d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e\u0433\u043e \u0441\u0435\u0440\u0432\u0438\u0441\u0430 \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u044f \u0440\u0435\u0447\u0438."

    .line 1503
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_3
    const-string v0, "android.permission.RECORD_AUDIO"

    .line 1506
    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_5

    .line 1511
    :try_start_0
    iput-boolean v2, p0, Lru/supportagent/OverlayService;->aiMicPermissionPending:Z

    .line 1512
    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsFocusable()Z

    move-result v0

    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiPanelWasFocusableBeforeMicPermission:Z

    .line 1513
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 1514
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_4

    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1515
    :cond_4
    new-instance v0, Landroid/content/Intent;

    const-class v2, Lru/supportagent/MainActivity;

    invoke-direct {v0, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v2, "ru.supportagent.REQUEST_MICROPHONE"

    .line 1516
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v2, 0x14000000

    .line 1517
    invoke-virtual {v0, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    .line 1518
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1520
    :catch_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->restoreAiAfterMicrophonePermission()V

    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u043f\u0440\u043e\u0441\u0438\u0442\u044c \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u0435 \u043d\u0430 \u043c\u0438\u043a\u0440\u043e\u0444\u043e\u043d."

    .line 1521
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void

    .line 1525
    :cond_5
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 1526
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->clearFocus()V

    .line 1527
    invoke-direct {p0}, Lru/supportagent/OverlayService;->startVoiceRecognition()V

    return-void
.end method

.method private resetAiConversation()V
    .locals 4

    .line 1387
    iget-wide v0, p0, Lru/supportagent/OverlayService;->aiRequestGeneration:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lru/supportagent/OverlayService;->aiRequestGeneration:J

    const/4 v0, 0x0

    .line 1388
    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    .line 1389
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMessages:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const-string v0, ""

    .line 1390
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiLastError:Ljava/lang/String;

    return-void
.end method

.method private resetPanelPlacement()V
    .locals 2

    const/4 v0, -0x1

    .line 528
    iput v0, p0, Lru/supportagent/OverlayService;->panelSessionX:I

    .line 529
    iput v0, p0, Lru/supportagent/OverlayService;->panelSessionY:I

    .line 531
    invoke-direct {p0}, Lru/supportagent/OverlayService;->overlayPreferences()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "panel_x"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "panel_y"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private restoreAiAfterMicrophonePermission()V
    .locals 2

    .line 1546
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiMicPermissionPending:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x0

    .line 1547
    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiMicPermissionPending:Z

    .line 1548
    iget-object v1, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v1, :cond_1

    .line 1549
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 1550
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiPanelWasFocusableBeforeMicPermission:Z

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    :cond_1
    return-void
.end method

.method private restoreScroll()V
    .locals 3

    .line 541
    iget-object v0, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    if-nez v0, :cond_0

    return-void

    .line 542
    :cond_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->scrollPositions:Ljava/util/Map;

    iget-object v1, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lru/supportagent/OverlayService;->scrollPositions:Ljava/util/Map;

    iget-object v1, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    .line 543
    :goto_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    new-instance v2, Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;

    invoke-direct {v2, p0, v0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda60;-><init>(Lru/supportagent/OverlayService;I)V

    invoke-virtual {v1, v2}, Landroid/widget/ScrollView;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private saveScroll()V
    .locals 3

    .line 535
    iget-object v0, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    .line 536
    iget-object v0, p0, Lru/supportagent/OverlayService;->scrollPositions:Ljava/util/Map;

    iget-object v1, p0, Lru/supportagent/OverlayService;->activeScrollKey:Ljava/lang/String;

    iget-object v2, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    invoke-virtual {v2}, Landroid/widget/ScrollView;->getScrollY()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method private scheduleSearchRender(Ljava/lang/String;Lru/supportagent/OverlayService$SearchRenderer;)V
    .locals 3

    .line 2518
    invoke-direct {p0}, Lru/supportagent/OverlayService;->cancelPendingSearchRender()V

    if-nez p1, :cond_0

    const-string p1, ""

    .line 2520
    :cond_0
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;

    invoke-direct {v0, p0, p2, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda29;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$SearchRenderer;Ljava/lang/String;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->pendingSearchRender:Ljava/lang/Runnable;

    .line 2524
    iget-object p1, p0, Lru/supportagent/OverlayService;->searchHandler:Landroid/os/Handler;

    const-wide/16 v1, 0x78

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private screenHeight()I
    .locals 1

    .line 424
    invoke-virtual {p0}, Lru/supportagent/OverlayService;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    return v0
.end method

.method private screenWidth()I
    .locals 1

    .line 423
    invoke-virtual {p0}, Lru/supportagent/OverlayService;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    return v0
.end method

.method private searchResultCard(Lru/supportagent/AnswerTemplate;Ljava/lang/String;)Landroid/view/View;
    .locals 10

    .line 2155
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v0

    .line 2156
    iget-object v1, p1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    if-eqz v1, :cond_1

    iget-object v1, p1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 2157
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v1, " \u00b7 "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    iget-object v1, p1, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 2158
    :cond_1
    :goto_0
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object p2

    const/4 v1, 0x1

    .line 2159
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 2160
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p2, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v4, -0x2

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    move-object v3, p0

    .line 2161
    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, p2, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2162
    iget-object p2, p1, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    const/high16 v2, 0x41400000    # 12.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v3

    invoke-static {p0, p2, v2, v3, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    .line 2163
    invoke-virtual {v0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2164
    iget-object p2, p1, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {p2}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/high16 v2, 0x41200000    # 10.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const/4 v4, 0x0

    invoke-static {p0, p2, v2, v3, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    .line 2165
    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setMaxLines(I)V

    const/4 v3, -0x1

    const/4 v4, -0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v8, 0x6

    move-object v2, p0

    .line 2166
    invoke-direct/range {v2 .. v8}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, p2, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string p2, "\u0414\u0410\u0422\u042c \u041e\u0422\u0412\u0415\u0422 \u0418\u0413\u0420\u041e\u041a\u0423"

    .line 2167
    invoke-direct {p0, p2, v1}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p2

    .line 2168
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda7;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {p2, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v4, 0x1f

    const/4 v6, 0x0

    const/4 v8, 0x0

    move-object v2, p0

    .line 2169
    invoke-direct/range {v2 .. v8}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p1

    invoke-virtual {v0, p2, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private secretInput(Ljava/lang/String;)Landroid/widget/EditText;
    .locals 1

    const/4 v0, 0x0

    .line 1107
    invoke-direct {p0, p1, v0}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object p1

    const v0, 0x80081

    .line 1108
    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setInputType(I)V

    const/4 v0, 0x1

    .line 1110
    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setSingleLine(Z)V

    const v0, 0x10000006

    .line 1111
    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setImeOptions(I)V

    return-object p1
.end method

.method private sectionHeader(Ljava/lang/String;I)Landroid/view/View;
    .locals 10

    .line 1968
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 1969
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v2, 0x41000000    # 8.0f

    .line 1970
    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/high16 v4, 0x40a00000    # 5.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v0, v3, v5, v2, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1971
    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    invoke-static {v2, v1}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    const/high16 v3, 0x40e00000    # 7.0f

    goto :goto_0

    :cond_0
    const/high16 v3, 0x41200000    # 10.0f

    :goto_0
    invoke-static {v1, v2, v3, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1972
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1973
    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_1

    const/high16 v3, 0x40000000    # 2.0f

    goto :goto_1

    :cond_1
    const/high16 v3, 0x40800000    # 4.0f

    :goto_1
    invoke-static {v2, v3, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x3

    const/16 v5, 0x12

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    move-object v3, p0

    .line 1974
    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1975
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const v1, 0x41133333    # 9.2f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    const/4 v3, 0x1

    invoke-static {p0, p1, v1, v2, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1976
    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1977
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1978
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    invoke-direct {v1, v4, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1979
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string p2, " \u0448\u0442."

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object p1

    const/4 v3, -0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    move-object v1, p0

    invoke-direct/range {v1 .. v7}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private selectTopicSection(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Lru/supportagent/Topic;",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;[",
            "Ljava/lang/String;",
            "Landroid/widget/LinearLayout;",
            "Landroid/widget/ScrollView;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    move-object v8, p0

    move-object v2, p2

    move-object/from16 v9, p7

    move-object/from16 v0, p8

    const/4 v1, 0x0

    .line 1884
    aput-object v0, p5, v1

    .line 1885
    invoke-virtual/range {p8 .. p8}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "__sections__"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    .line 1886
    :cond_0
    iget-object v1, v8, Lru/supportagent/OverlayService;->topicSectionFilters:Ljava/util/Map;

    iget-object v3, v2, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-interface {v1, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    .line 1885
    :cond_1
    :goto_0
    iget-object v0, v8, Lru/supportagent/OverlayService;->topicSectionFilters:Ljava/util/Map;

    iget-object v1, v2, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1887
    :goto_1
    invoke-direct/range {p0 .. p7}, Lru/supportagent/OverlayService;->renderSectionChips(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    move-object v0, p0

    move-object/from16 v1, p6

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p1

    move-object/from16 v7, p7

    .line 1888
    invoke-direct/range {v0 .. v7}, Lru/supportagent/OverlayService;->renderTopicContent(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    .line 1889
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda66;

    invoke-direct {v0, v9}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda66;-><init>(Landroid/widget/ScrollView;)V

    invoke-virtual {v9, v0}, Landroid/widget/ScrollView;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private selectedAiFragment(Landroid/widget/TextView;)Ljava/lang/String;
    .locals 5

    const-string v0, ""

    if-eqz p1, :cond_3

    .line 1431
    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    if-nez v1, :cond_0

    goto :goto_0

    .line 1432
    :cond_0
    invoke-virtual {p1}, Landroid/widget/TextView;->getSelectionStart()I

    move-result v1

    .line 1433
    invoke-virtual {p1}, Landroid/widget/TextView;->getSelectionEnd()I

    move-result v2

    if-ltz v1, :cond_3

    if-ltz v2, :cond_3

    if-ne v1, v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    .line 1435
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 1436
    invoke-virtual {p1}, Landroid/widget/TextView;->length()I

    move-result v4

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v4, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    if-lt v3, v1, :cond_2

    goto :goto_0

    .line 1437
    :cond_2
    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-interface {p1, v3, v1}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    :cond_3
    :goto_0
    return-object v0
.end method

.method private selectedSectionChip(Ljava/lang/String;Z)Landroid/widget/TextView;
    .locals 5

    .line 791
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const v0, 0x41033333    # 8.2f

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    if-eqz p2, :cond_0

    const/4 v1, -0x1

    goto :goto_0

    .line 792
    :cond_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    :goto_0
    const/4 v2, 0x1

    .line 791
    invoke-static {p0, p1, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 793
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 794
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 795
    sget-object v0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/high16 v0, 0x41000000    # 8.0f

    .line 796
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v3, 0x40400000    # 3.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {p1, v1, v4, v0, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const/high16 v0, 0x40e00000    # 7.0f

    const/high16 v1, 0x41200000    # 10.0f

    if-eqz p2, :cond_2

    .line 798
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    move v0, v1

    :goto_1
    invoke-static {p2, v0, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    goto :goto_3

    .line 799
    :cond_2
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result p2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v3

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v4

    if-eqz v4, :cond_3

    goto :goto_2

    :cond_3
    move v0, v1

    :goto_2
    invoke-static {p2, v3, v0, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    .line 797
    :goto_3
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 800
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setClickable(Z)V

    return-object p1
.end method

.method private sendAiQuestion()V
    .locals 1

    return-void
.end method

.method private setBubbleVisible(Z)V
    .locals 1

    .line 336
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    if-eqz v0, :cond_1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/4 p1, 0x4

    :goto_0
    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    return-void
.end method

.method private setPanelDraggable(Z)V
    .locals 2

    .line 357
    invoke-direct {p0}, Lru/supportagent/OverlayService;->overlayPreferences()Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "panel_draggable"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method private setPanelFocusable(Z)V
    .locals 2

    .line 494
    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    if-eqz p1, :cond_1

    .line 495
    iget p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    and-int/lit8 p1, p1, -0x9

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    goto :goto_0

    .line 496
    :cond_1
    iget p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    or-int/lit8 p1, p1, 0x8

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    .line 497
    :goto_0
    :try_start_0
    iget-object p1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v0, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    iget-object v1, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {p1, v0, v1}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    :goto_1
    return-void
.end method

.method private shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;
    .locals 18

    move-object/from16 v7, p0

    move-object/from16 v8, p3

    .line 562
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x1

    .line 563
    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v0, 0x41200000    # 10.0f

    .line 564
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x41000000    # 8.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/high16 v4, 0x41100000    # 9.0f

    invoke-direct {v7, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v9, v1, v2, v3, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 565
    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v2

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    const/high16 v3, 0x41400000    # 12.0f

    goto :goto_0

    :cond_0
    const/high16 v3, 0x41800000    # 16.0f

    :goto_0
    invoke-static {v1, v2, v3, v7}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 566
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->setElevation(F)V

    .line 568
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v12, 0x10

    .line 569
    invoke-virtual {v11, v12}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 573
    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 574
    invoke-virtual {v13, v12}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v0, 0x41500000    # 13.0f

    .line 575
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    const-string v3, "SUPPORT"

    invoke-static {v7, v3, v1, v2, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 576
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const-string v4, " | "

    const/4 v14, 0x0

    invoke-static {v7, v4, v2, v3, v14}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v2

    .line 577
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v3, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v3

    const-string v4, "AGENT"

    invoke-static {v7, v4, v0, v3, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 578
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 579
    invoke-virtual {v13, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 580
    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const v0, 0x7f070069

    const-string v1, "\u041e\u0431\u0443\u0447\u0435\u043d\u0438\u0435"

    const/4 v15, -0x1

    const/4 v6, 0x5

    .line 583
    invoke-direct {v7, v0, v1, v15, v6}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v5

    const/4 v0, 0x0

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 584
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda11;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda11;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {v5, v7}, Lru/supportagent/Pulse;->apply(Landroid/view/View;Landroid/content/Context;)V

    const/16 v1, 0x1c

    const/16 v2, 0x1c

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v0, p0

    move-object v12, v5

    move/from16 v5, v16

    move/from16 v6, v17

    .line 585
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v13, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 586
    new-instance v0, Landroid/widget/Space;

    invoke-direct {v0, v7}, Landroid/widget/Space;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v1, v14, v10, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v13, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0412\u0435\u0440\u0445\u043d\u044f\u044f \u0447\u0430\u0441\u0442\u044c \u043f\u0430\u043d\u0435\u043b\u0438: \u043f\u0435\u0440\u0435\u0442\u0430\u0441\u043a\u0438\u0432\u0430\u043d\u0438\u0435 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e \u043f\u043e\u0441\u043b\u0435 \u0440\u0430\u0437\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u043a\u0438"

    .line 587
    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 588
    new-instance v0, Lru/supportagent/OverlayService$PanelDragTouchListener;

    const/4 v1, 0x0

    invoke-direct {v0, v7, v1}, Lru/supportagent/OverlayService$PanelDragTouchListener;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/OverlayService$PanelDragTouchListener-IA;)V

    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 589
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x41e80000    # 29.0f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {v0, v14, v1, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x7f070060

    const-string v1, "\u041f\u0430\u043d\u0435\u043b\u044c \u0437\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u0430: \u043d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0440\u0430\u0437\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    const/16 v13, 0x8

    .line 591
    invoke-direct {v7, v0, v1, v15, v13}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v6

    .line 592
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->panelIsDraggable()Z

    move-result v0

    invoke-direct {v7, v6, v0}, Lru/supportagent/OverlayService;->applyPanelLockVisual(Landroid/widget/ImageView;Z)V

    .line 593
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;

    invoke-direct {v0, v7, v6}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda22;-><init>(Lru/supportagent/OverlayService;Landroid/widget/ImageView;)V

    invoke-virtual {v6, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1d

    const/16 v2, 0x1d

    const/4 v3, 0x7

    const/4 v5, 0x4

    move-object/from16 v0, p0

    move-object v12, v6

    move/from16 v6, v16

    .line 601
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x7f070068

    const-string v1, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0442\u0435\u043c, \u043e\u0442\u0432\u0435\u0442\u043e\u0432 \u0438 \u043e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u044f"

    const/16 v2, 0x9

    .line 602
    invoke-direct {v7, v0, v1, v15, v2}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v12

    .line 603
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda33;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda33;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v12, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1d

    const/16 v2, 0x1d

    const/4 v3, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 604
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x7f07005e

    const-string v1, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c SUPPORT AGENT"

    .line 605
    invoke-direct {v7, v0, v1, v15, v13}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v12

    .line 606
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda44;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda44;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v12, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1d

    const/4 v5, 0x0

    move-object/from16 v0, p0

    .line 607
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v6, 0x5

    move-object/from16 v0, p0

    .line 608
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 609
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-static {v7, v0}, Lru/supportagent/Ui;->line(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/view/View;

    move-result-object v11

    const/4 v2, 0x1

    const/4 v6, 0x6

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 611
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 612
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    if-eqz v8, :cond_1

    const-string v0, "\u2039"

    .line 614
    invoke-direct {v7, v0, v14}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v12

    const/high16 v0, 0x41a00000    # 20.0f

    .line 615
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 v0, 0x40000000    # 2.0f

    .line 616
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {v12, v14, v14, v14, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 617
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda55;

    invoke-direct {v0, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda55;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1c

    const/16 v2, 0x1b

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 618
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 620
    :cond_1
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 621
    invoke-virtual {v8, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v0, 0x41580000    # 13.5f

    .line 622
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    move-object/from16 v2, p1

    invoke-static {v7, v2, v0, v1, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 623
    invoke-virtual {v0, v10}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 624
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/high16 v1, 0x41080000    # 8.5f

    .line 625
    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    move-object/from16 v3, p2

    invoke-static {v7, v3, v1, v2, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v10

    const v1, 0x3d3851ec    # 0.045f

    .line 626
    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 627
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 628
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 629
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v14, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v4, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 630
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v9
.end method

.method private shortenAiResponse(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    .line 1324
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    .line 1325
    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0xc8

    if-gt v0, v1, :cond_1

    return-object p1

    .line 1326
    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    invoke-virtual {p1, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "\u2026"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private showAiChat()V
    .locals 1

    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method private showAiReplyConfirmation(Ljava/lang/String;)V
    .locals 15

    move-object v7, p0

    .line 1441
    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsFocusable()Z

    move-result v8

    .line 1442
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    const/4 v9, 0x0

    .line 1443
    invoke-direct {p0, v9}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    .line 1444
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 1445
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v10

    const/high16 v0, 0x41500000    # 13.0f

    .line 1446
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v11, 0x41300000    # 11.0f

    invoke-direct {p0, v11}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    const/high16 v3, 0x41400000    # 12.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {v10, v1, v2, v0, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1447
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    if-eqz v2, :cond_0

    move v2, v11

    goto :goto_0

    :cond_0
    const/high16 v2, 0x41700000    # 15.0f

    :goto_0
    invoke-static {v0, v1, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v0, "\u0412\u042b\u0414\u0415\u041b\u0415\u041d\u041d\u042b\u0419 \u0424\u0420\u0410\u0413\u041c\u0415\u041d\u0422"

    .line 1448
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v12

    const/4 v1, -0x2

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41600000    # 14.0f

    .line 1449
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const-string v2, "\u0414\u0430\u0442\u044c \u043e\u0442\u0432\u0435\u0442 \u0438\u0433\u0440\u043e\u043a\u0443?"

    const/4 v12, 0x1

    invoke-static {p0, v2, v0, v1, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v6, 0x5

    move-object v0, p0

    .line 1450
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x4121999a    # 10.1f

    .line 1451
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u0438 \u043a\u043e\u043d\u0446\u043e\u0432\u043a\u0430 \u0434\u043e\u0431\u0430\u0432\u044f\u0442\u0441\u044f \u0441\u0430\u043c\u0438. \u0412\u0441\u0442\u0430\u0432\u043a\u0443 \u0438 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0443 \u0432 \u0438\u0433\u0440\u0435 \u043d\u0430\u0436\u043c\u0451\u0442\u0435 \u0432\u044b."

    invoke-static {p0, v2, v0, v1, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    const/high16 v14, 0x3f800000    # 1.0f

    .line 1452
    invoke-direct {p0, v14}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v13, v0, v14}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v6, 0x7

    move-object v0, p0

    .line 1453
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1454
    invoke-static/range {p1 .. p1}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const v1, 0x4129999a    # 10.6f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    invoke-static {p0, v0, v1, v2, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    .line 1455
    invoke-direct {p0, v14}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v13, v0, v14}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/high16 v0, 0x41000000    # 8.0f

    .line 1456
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-virtual {v13, v1, v3, v4, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1457
    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    if-eqz v2, :cond_1

    move v11, v0

    :cond_1
    invoke-static {v1, v11, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v13, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x8

    move-object v0, p0

    .line 1458
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1459
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, "\u041d\u0415\u0422"

    .line 1460
    invoke-direct {p0, v0, v9}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    .line 1461
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda62;

    invoke-direct {v1, p0, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda62;-><init>(Lru/supportagent/OverlayService;Z)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1465
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42000000    # 32.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v1, v9, v2, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041f\u041e\u0414\u0422\u0412\u0415\u0420\u0414\u0418\u0422\u042c"

    .line 1466
    invoke-direct {p0, v0, v12}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v8

    .line 1467
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda63;

    move-object/from16 v1, p1

    invoke-direct {v0, p0, v1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda63;-><init>(Lru/supportagent/OverlayService;Ljava/lang/String;)V

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x73

    const/16 v2, 0x20

    const/4 v3, 0x6

    const/4 v6, 0x0

    move-object v0, p0

    .line 1468
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1469
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1470
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_2

    const/high16 v0, 0x438f0000    # 286.0f

    goto :goto_1

    :cond_2
    const/high16 v0, 0x439b0000    # 310.0f

    :goto_1
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v1

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, -0x2

    invoke-direct {p0, v10, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    return-void
.end method

.method private showAiSetup()V
    .locals 1

    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method private showAnswerConfirmation(Lru/supportagent/AnswerTemplate;)V
    .locals 16

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    .line 2057
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->panelIsFocusable()Z

    move-result v9

    .line 2058
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    const/4 v10, 0x0

    .line 2059
    invoke-direct {v7, v10}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    .line 2060
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 2061
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v11

    const/high16 v0, 0x41500000    # 13.0f

    .line 2062
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v12, 0x41300000    # 11.0f

    invoke-direct {v7, v12}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    const/high16 v3, 0x41400000    # 12.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {v11, v1, v2, v0, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2063
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    const/high16 v13, 0x41700000    # 15.0f

    if-eqz v2, :cond_0

    move v2, v12

    goto :goto_0

    :cond_0
    move v2, v13

    :goto_0
    invoke-static {v0, v1, v2, v7}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v0, "\u041f\u041e\u0414\u0422\u0412\u0415\u0420\u0416\u0414\u0415\u041d\u0418\u0415"

    .line 2064
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v14

    const/4 v1, -0x2

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 2065
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2066
    invoke-direct {v7, v13}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const-string v2, "\u0412\u044b\u0434\u0430\u0442\u044c \u043e\u0442\u0432\u0435\u0442 \u0438\u0433\u0440\u043e\u043a\u0443?"

    const/4 v13, 0x1

    invoke-static {v7, v2, v0, v1, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    const/4 v1, -0x1

    const/4 v2, -0x2

    move-object/from16 v0, p0

    .line 2067
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41280000    # 10.5f

    .line 2068
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0422\u0435\u043a\u0441\u0442 \u043f\u043e\u044f\u0432\u0438\u0442\u0441\u044f \u0432 \u0447\u0430\u0442\u0435. \u041e\u0442\u043f\u0440\u0430\u0432\u043a\u0443 \u043d\u0430\u0436\u043c\u0451\u0442\u0435 \u0432\u044b \u0441\u0430\u043c\u0438."

    invoke-static {v7, v2, v0, v1, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    const/high16 v15, 0x3f800000    # 1.0f

    .line 2069
    invoke-direct {v7, v15}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v14, v0, v15}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v6, 0x7

    move-object/from16 v0, p0

    .line 2070
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2071
    iget-object v0, v8, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->compose(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/high16 v1, 0x41380000    # 11.5f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    invoke-static {v7, v0, v1, v2, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    const/high16 v0, 0x40000000    # 2.0f

    .line 2072
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v14, v0, v15}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 2073
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v0

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :cond_1

    const/high16 v12, 0x41000000    # 8.0f

    :cond_1
    invoke-static {v0, v12, v7}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v0, 0x41100000    # 9.0f

    .line 2074
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x40e00000    # 7.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-virtual {v14, v1, v3, v0, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x9

    move-object/from16 v0, p0

    .line 2075
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2076
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-direct {v12, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, "\u041d\u0415\u0422"

    .line 2077
    invoke-direct {v7, v0, v10}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    .line 2078
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda24;

    invoke-direct {v1, v7, v9}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda24;-><init>(Lru/supportagent/OverlayService;Z)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2082
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42040000    # 33.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v1, v10, v2, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v12, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041f\u041e\u0414\u0422\u0412\u0415\u0420\u0414\u0418\u0422\u042c"

    .line 2083
    invoke-direct {v7, v0, v13}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v9

    .line 2084
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda25;

    invoke-direct {v0, v7, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda25;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x78

    const/16 v2, 0x21

    const/4 v3, 0x6

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2085
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    move-object/from16 v0, p0

    .line 2086
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2087
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_2

    const/high16 v0, 0x438a0000    # 276.0f

    goto :goto_1

    :cond_2
    const/high16 v0, 0x43960000    # 300.0f

    :goto_1
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v1

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, -0x2

    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    return-void
.end method

.method private showAnswerEditor(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V
    .locals 20

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-object/from16 v9, p2

    .line 2417
    new-instance v0, Ljava/lang/StringBuilder;

    if-nez v9, :cond_0

    const-string v1, "new_answer_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v8, Lru/supportagent/Topic;->id:Ljava/lang/String;

    goto :goto_0

    :cond_0
    const-string v1, "edit_answer_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v9, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    if-nez v9, :cond_1

    const-string v0, "\u041d\u041e\u0412\u042b\u0419 \u041e\u0422\u0412\u0415\u0422"

    goto :goto_1

    :cond_1
    const-string v0, "\u0418\u0417\u041c\u0415\u041d\u0418\u0422\u042c \u041e\u0422\u0412\u0415\u0422"

    .line 2418
    :goto_1
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda19;

    invoke-direct {v1, v7, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda19;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    const-string v2, "\u041f\u0420\u0418\u0412\u0415\u0422\u0421\u0422\u0412\u0418\u0415 \u0418 \u041a\u041e\u041d\u0426\u041e\u0412\u041a\u0410 \u0414\u041e\u0411\u0410\u0412\u042f\u0422\u0421\u042f \u0421\u0410\u041c\u0418"

    invoke-direct {v7, v0, v2, v1}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v10

    .line 2419
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v11

    .line 2420
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v12

    .line 2421
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {v0, v8}, Lru/supportagent/TemplateRepository;->isQuickTopic(Lru/supportagent/Topic;)Z

    move-result v13

    .line 2422
    iget-object v0, v8, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-static {v0}, Lru/supportagent/TemplateRepository;->titleLimitForTopic(Ljava/lang/String;)I

    move-result v14

    if-eqz v13, :cond_2

    const-string v0, "\u041d\u0410\u0417\u0412\u0410\u041d\u0418\u0415 \u0411\u042b\u0421\u0422\u0420\u041e\u0419 \u041a\u041d\u041e\u041f\u041a\u0418"

    goto :goto_2

    :cond_2
    const-string v0, "\u041d\u0410\u0417\u0412\u0410\u041d\u0418\u0415 \u041a\u041d\u041e\u041f\u041a\u0418"

    :goto_2
    const/high16 v15, 0x41100000    # 9.0f

    .line 2423
    invoke-direct {v7, v15}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const/4 v6, 0x1

    invoke-static {v7, v0, v1, v2, v6}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v5

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x4

    move-object/from16 v0, p0

    move-object v15, v5

    move/from16 v5, v16

    move-object/from16 v16, v10

    move v10, v6

    move/from16 v6, v17

    .line 2424
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v13, :cond_3

    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u041f\u043e\u043d\u044f\u043b"

    goto :goto_3

    :cond_3
    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u041c\u0427\u0421"

    :goto_3
    const/4 v15, 0x0

    .line 2425
    invoke-direct {v7, v0, v15}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v6

    new-array v0, v10, [Landroid/text/InputFilter;

    .line 2426
    new-instance v1, Landroid/text/InputFilter$LengthFilter;

    invoke-direct {v1, v14}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v1, v0, v15

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    if-eqz v9, :cond_4

    .line 2427
    iget-object v0, v9, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-virtual {v6, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_4
    const/4 v1, -0x1

    const/16 v2, 0x23

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v17, 0x3

    const/16 v18, 0x6

    if-eqz v13, :cond_5

    move/from16 v19, v17

    goto :goto_4

    :cond_5
    move/from16 v19, v18

    :goto_4
    move-object/from16 v0, p0

    move-object v10, v6

    move/from16 v6, v19

    .line 2428
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v6, 0x3f800000    # 1.0f

    if-eqz v13, :cond_6

    .line 2430
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u0414\u043e "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432 \u2014 \u043d\u0430 \u043f\u0430\u043d\u0435\u043b\u0438 \u0432\u0441\u0435\u0433\u0434\u0430 \u0432\u0438\u0434\u043d\u044b \u0442\u043e\u043b\u044c\u043a\u043e 4 \u0431\u044b\u0441\u0442\u0440\u044b\u0435 \u043a\u043d\u043e\u043f\u043a\u0438, \u043e\u0441\u0442\u0430\u043b\u044c\u043d\u044b\u0435 \u2014 \u0432 \u043c\u0435\u043d\u044e \u22ee."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const v1, 0x410b3333    # 8.7f

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    invoke-static {v7, v0, v1, v2, v15}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    .line 2431
    invoke-direct {v7, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v14, v0, v6}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v19, 0x7

    move-object/from16 v0, p0

    move/from16 v6, v19

    .line 2432
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_6
    if-eqz v13, :cond_7

    const/4 v0, 0x0

    move-object v13, v0

    :goto_5
    const/high16 v0, 0x41100000    # 9.0f

    goto :goto_6

    :cond_7
    const/high16 v0, 0x41100000    # 9.0f

    .line 2438
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v2, "\u0420\u0410\u0417\u0414\u0415\u041b \u0412 \u0422\u0415\u041c\u0415 \u00b7 \u041d\u0415\u041e\u0411\u042f\u0417\u0410\u0422\u0415\u041b\u042c\u041d\u041e"

    const/4 v3, 0x1

    invoke-static {v7, v2, v1, v0, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    move-object/from16 v0, p0

    .line 2439
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u0412\u0430\u0436\u043d\u044b\u0435 \u043c\u0435\u0441\u0442\u0430"

    .line 2440
    invoke-direct {v7, v0, v15}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v13

    const/4 v0, 0x1

    new-array v1, v0, [Landroid/text/InputFilter;

    .line 2441
    new-instance v0, Landroid/text/InputFilter$LengthFilter;

    const/16 v2, 0x1e

    invoke-direct {v0, v2}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v0, v1, v15

    invoke-virtual {v13, v1}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    if-eqz v9, :cond_8

    .line 2442
    iget-object v0, v9, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-virtual {v13, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_8
    const/4 v1, -0x1

    const/16 v2, 0x23

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    move-object/from16 v0, p0

    .line 2443
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_5

    .line 2445
    :goto_6
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041e\u0421\u041d\u041e\u0412\u041d\u0410\u042f \u0427\u0410\u0421\u0422\u042c \u041e\u0422\u0412\u0415\u0422\u0410"

    const/4 v3, 0x1

    invoke-static {v7, v2, v0, v1, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    move-object/from16 v0, p0

    .line 2446
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u0434\u043b\u044f \u041c\u0427\u0421 \u043d\u0443\u0436\u0435\u043d 5 \u0443\u0440\u043e\u0432\u0435\u043d\u044c"

    const/4 v1, 0x1

    .line 2447
    invoke-direct {v7, v0, v1}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v14

    .line 2448
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_9

    const/16 v17, 0x2

    :cond_9
    move/from16 v0, v17

    invoke-virtual {v14, v0}, Landroid/widget/EditText;->setMinLines(I)V

    .line 2449
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 v0, 0x4

    goto :goto_7

    :cond_a
    move/from16 v0, v18

    :goto_7
    invoke-virtual {v14, v0}, Landroid/widget/EditText;->setMaxLines(I)V

    const v0, 0x800033

    .line 2450
    invoke-virtual {v14, v0}, Landroid/widget/EditText;->setGravity(I)V

    if-eqz v9, :cond_b

    .line 2451
    iget-object v0, v9, Lru/supportagent/AnswerTemplate;->body:Ljava/lang/String;

    invoke-virtual {v14, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_b
    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    move-object/from16 v0, p0

    .line 2452
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41180000    # 9.5f

    .line 2453
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, ""

    invoke-static {v7, v2, v0, v1, v15}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v6

    const v0, 0x800005

    .line 2454
    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v17, 0x6

    move-object/from16 v0, p0

    move-object v15, v6

    move/from16 v6, v17

    .line 2455
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c"

    const/4 v1, 0x1

    .line 2456
    invoke-direct {v7, v0, v1}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    const/4 v1, -0x1

    const/16 v2, 0x20

    if-nez v9, :cond_c

    const/16 v18, 0x0

    :cond_c
    move-object/from16 v0, p0

    move-object/from16 v17, v11

    move-object v11, v6

    move/from16 v6, v18

    .line 2457
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v9, :cond_d

    const-string v0, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c \u041e\u0422\u0412\u0415\u0422"

    const/4 v1, 0x0

    .line 2459
    invoke-direct {v7, v0, v1}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    .line 2460
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2461
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda20;

    invoke-direct {v0, v7, v8, v9}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda20;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x1e

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v18, 0x0

    move-object/from16 v0, p0

    move-object v8, v6

    move/from16 v6, v18

    .line 2462
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2464
    :cond_d
    new-instance v8, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;

    move-object v0, v8

    move-object/from16 v1, p0

    move-object v2, v14

    move-object v3, v10

    move-object v4, v15

    move-object v5, v11

    invoke-direct/range {v0 .. v5}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda21;-><init>(Lru/supportagent/OverlayService;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/TextView;)V

    .line 2472
    invoke-direct {v7, v8}, Lru/supportagent/OverlayService;->simpleWatcher(Ljava/lang/Runnable;)Landroid/text/TextWatcher;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 2473
    invoke-direct {v7, v8}, Lru/supportagent/OverlayService;->simpleWatcher(Ljava/lang/Runnable;)Landroid/text/TextWatcher;

    move-result-object v0

    invoke-virtual {v14, v0}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 2474
    new-instance v15, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;

    move-object v0, v15

    move-object/from16 v2, p2

    move-object/from16 v3, p1

    move-object v4, v10

    move-object v5, v14

    move-object v6, v13

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda23;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V

    invoke-virtual {v11, v15}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2484
    invoke-interface {v8}, Ljava/lang/Runnable;->run()V

    move-object/from16 v0, v17

    .line 2485
    invoke-virtual {v0, v12}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2486
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    invoke-direct {v1, v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v2, v16

    invoke-virtual {v2, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    .line 2487
    invoke-direct {v7, v2, v0}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    .line 2488
    invoke-direct {v7, v10}, Lru/supportagent/OverlayService;->focusInput(Landroid/widget/EditText;)V

    return-void
.end method

.method private showDecision(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V
    .locals 14

    move-object v7, p0

    .line 2551
    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsFocusable()Z

    move-result v8

    .line 2552
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    const/4 v9, 0x0

    .line 2553
    invoke-direct {p0, v9}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    .line 2554
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 2555
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v10

    const/high16 v0, 0x41500000    # 13.0f

    .line 2556
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x41300000    # 11.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    const/high16 v4, 0x41400000    # 12.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v10, v1, v3, v0, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2557
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_0

    goto :goto_0

    :cond_0
    const/high16 v2, 0x41700000    # 15.0f

    :goto_0
    invoke-static {v0, v1, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v0, 0x41680000    # 14.5f

    .line 2558
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const/4 v11, 0x1

    move-object v2, p1

    invoke-static {p0, p1, v0, v1, v11}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v12

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    move-object v0, p0

    .line 2559
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41280000    # 10.5f

    .line 2560
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    move-object/from16 v2, p2

    invoke-static {p0, v2, v0, v1, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v12

    const/high16 v13, 0x3f800000    # 1.0f

    .line 2561
    invoke-direct {p0, v13}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v12, v0, v13}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v6, 0x9

    move-object v0, p0

    .line 2562
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2563
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-direct {v12, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, "\u041e\u0422\u041c\u0415\u041d\u0410"

    .line 2564
    invoke-direct {p0, v0, v9}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    .line 2565
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda58;

    invoke-direct {v1, p0, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda58;-><init>(Lru/supportagent/OverlayService;Z)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2569
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42000000    # 32.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v1, v9, v2, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v12, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v0, p3

    .line 2570
    invoke-direct {p0, v0, v11}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v8

    .line 2571
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda59;

    move-object/from16 v1, p4

    invoke-direct {v0, p0, v1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda59;-><init>(Lru/supportagent/OverlayService;Ljava/lang/Runnable;)V

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x64

    const/16 v2, 0x20

    const/4 v3, 0x6

    const/4 v6, 0x0

    move-object v0, p0

    .line 2572
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2573
    invoke-virtual {v10, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2574
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_1

    const/high16 v0, 0x43820000    # 260.0f

    goto :goto_1

    :cond_1
    const/high16 v0, 0x43910000    # 290.0f

    :goto_1
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v1

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, -0x2

    invoke-direct {p0, v10, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    return-void
.end method

.method private showDeleteAnswerConfirmation(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V
    .locals 2

    .line 2544
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041e\u0442\u0432\u0435\u0442 \u00ab"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\u00bb \u043d\u0435\u043b\u044c\u0437\u044f \u0431\u0443\u0434\u0435\u0442 \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;

    invoke-direct {v1, p0, p2, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda16;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;)V

    const-string p1, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c \u041e\u0422\u0412\u0415\u0422?"

    const-string p2, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c"

    invoke-direct {p0, p1, v0, p2, v1}, Lru/supportagent/OverlayService;->showDecision(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    return-void
.end method

.method private showDeleteTopicConfirmation(Lru/supportagent/Topic;)V
    .locals 3

    .line 2537
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda3;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    const-string p1, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c \u0422\u0415\u041c\u0423?"

    const-string v1, "\u0412\u043c\u0435\u0441\u0442\u0435 \u0441 \u0442\u0435\u043c\u043e\u0439 \u0443\u0434\u0430\u043b\u044f\u0442\u0441\u044f \u0432\u0441\u0435 \u0435\u0451 \u043e\u0442\u0432\u0435\u0442\u044b."

    const-string v2, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c"

    invoke-direct {p0, p1, v1, v2, v0}, Lru/supportagent/OverlayService;->showDecision(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    return-void
.end method

.method private showHome()V
    .locals 18

    move-object/from16 v7, p0

    const/4 v0, 0x0

    .line 886
    iput-object v0, v7, Lru/supportagent/OverlayService;->openedTopic:Lru/supportagent/Topic;

    const-string v1, "home"

    .line 887
    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    const-string v1, "\u0422\u0415\u041c\u042b, \u041f\u041e\u0418\u0421\u041a \u0418 AGENT AI"

    const-string v8, "\u0411\u042b\u0421\u0422\u0420\u042b\u0415 \u041e\u0422\u0412\u0415\u0422\u042b"

    .line 888
    invoke-direct {v7, v8, v1, v0}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v9

    .line 893
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v0, "\u041f\u041e\u0418\u0421\u041a"

    const v1, 0x7f070066

    const/4 v11, 0x0

    .line 894
    invoke-direct {v7, v0, v1, v11}, Lru/supportagent/OverlayService;->centeredIconButtonBig(Ljava/lang/String;IZ)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0433\u043b\u043e\u0431\u0430\u043b\u044c\u043d\u044b\u0439 \u043f\u043e\u0438\u0441\u043a"

    .line 895
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 896
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda40;

    invoke-direct {v1, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda40;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 897
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42000000    # 32.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v1, v11, v3, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v13, 0x40400000    # 3.0f

    .line 898
    invoke-direct {v7, v13}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {v1, v11, v11, v3, v11}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 899
    invoke-virtual {v10, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "AGENT AI"

    const v1, 0x7f070057

    const/4 v14, 0x1

    .line 900
    invoke-direct {v7, v0, v1, v14}, Lru/supportagent/OverlayService;->centeredIconButtonBig(Ljava/lang/String;IZ)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c AGENT AI"

    .line 901
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 902
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda41;

    invoke-direct {v1, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda41;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 903
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v1, v11, v2, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 904
    invoke-direct {v7, v13}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-virtual {v1, v2, v11, v11, v11}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 905
    invoke-virtual {v10, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/16 v2, 0x20

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 907
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 909
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v10

    .line 910
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v15

    .line 911
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {v0}, Lru/supportagent/TemplateRepository;->getRegularTopics()Ljava/util/List;

    move-result-object v6

    invoke-static {v7, v6}, Lru/supportagent/TopicPin;->sortTopics(Landroid/content/Context;Ljava/util/List;)V

    .line 912
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x41380000    # 11.5f

    .line 913
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0422\u0435\u043c \u043f\u043e\u043a\u0430 \u043d\u0435\u0442. \u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u043f\u0435\u0440\u0432\u0443\u044e \u0447\u0435\u0440\u0435\u0437 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438."

    invoke-static {v7, v2, v0, v1, v11}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v5

    const/16 v0, 0x11

    .line 914
    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v4, 0x12

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v0, p0

    move-object v13, v5

    move/from16 v5, v16

    move-object v14, v6

    move/from16 v6, v17

    .line 915
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v15, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_0
    move-object v14, v6

    .line 917
    :goto_0
    invoke-direct {v7, v15, v14}, Lru/supportagent/OverlayService;->addTopicGrid(Landroid/widget/LinearLayout;Ljava/util/List;)V

    .line 918
    invoke-virtual {v10, v15}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 919
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x1

    invoke-direct {v0, v13, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 921
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {v0}, Lru/supportagent/TemplateRepository;->getQuickTemplates()Ljava/util/List;

    move-result-object v10

    const/4 v0, 0x4

    .line 922
    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v14

    .line 925
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-static {v7, v0}, Lru/supportagent/Ui;->line(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/view/View;

    move-result-object v15

    const/4 v1, -0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 926
    new-instance v15, Landroid/widget/LinearLayout;

    invoke-direct {v15, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x10

    .line 927
    invoke-virtual {v15, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v0, 0x41180000    # 9.5f

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const/4 v2, 0x1

    invoke-static {v7, v8, v0, v1, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const v1, 0x3d23d70a    # 0.04f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setLetterSpacing(F)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {v1, v11, v2, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v15, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " / "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->chip(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v0, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043c\u0435\u043d\u044e \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    const/16 v1, 0x5

    const v2, 0x7f070081

    .line 932
    invoke-direct {v7, v2, v0, v13, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v8

    iput-object v8, v7, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;

    invoke-direct {v0, v7, v10}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda42;-><init>(Lru/supportagent/OverlayService;Ljava/util/List;)V

    invoke-virtual {v8, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1b

    const/16 v2, 0x1b

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    move v11, v6

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 934
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v15, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v6, 0x4

    move-object/from16 v0, p0

    .line 935
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 938
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 939
    invoke-virtual {v8, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v0, 0x0

    :goto_1
    const/high16 v1, 0x41f80000    # 31.0f

    if-ge v0, v14, :cond_3

    .line 941
    invoke-interface {v10, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/AnswerTemplate;

    .line 942
    iget-object v3, v2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->quickButton(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v3

    .line 943
    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 944
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "\u0411\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442: "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, v2, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 945
    new-instance v4, Lru/supportagent/OverlayService$$ExternalSyntheticLambda43;

    invoke-direct {v4, v7, v2}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda43;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 946
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/4 v4, 0x0

    invoke-direct {v2, v4, v1, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-nez v0, :cond_1

    move v1, v4

    const/high16 v5, 0x40400000    # 3.0f

    goto :goto_2

    :cond_1
    const/high16 v5, 0x40400000    # 3.0f

    .line 947
    invoke-direct {v7, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v16

    move/from16 v1, v16

    :goto_2
    add-int/lit8 v6, v14, -0x1

    if-ne v0, v6, :cond_2

    move v6, v4

    goto :goto_3

    :cond_2
    invoke-direct {v7, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v16

    move/from16 v6, v16

    :goto_3
    invoke-virtual {v2, v1, v4, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 948
    invoke-virtual {v8, v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    const/4 v4, 0x0

    if-nez v14, :cond_4

    const v0, 0x41133333    # 9.2f

    .line 951
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const-string v3, "\u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 \u0447\u0435\u0440\u0435\u0437 \u2699"

    invoke-static {v7, v3, v0, v2, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 952
    invoke-virtual {v0, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 953
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {v2, v4, v1, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_4
    const/4 v1, -0x1

    const/16 v2, 0x22

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 955
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x0

    .line 956
    invoke-direct {v7, v9, v0}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    return-void
.end method

.method private showManageTemplates(Lru/supportagent/Topic;)V
    .locals 18

    move-object/from16 v7, p0

    .line 2336
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    move-object/from16 v1, p1

    iget-object v1, v1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->getTopic(Ljava/lang/String;)Lru/supportagent/Topic;

    move-result-object v8

    if-nez v8, :cond_0

    .line 2337
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->showManageTopics()V

    return-void

    .line 2338
    :cond_0
    iput-object v8, v7, Lru/supportagent/OverlayService;->openedTopic:Lru/supportagent/Topic;

    .line 2339
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "manage_templates_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v8, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    .line 2340
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {v0, v8}, Lru/supportagent/TemplateRepository;->isQuickTopic(Lru/supportagent/Topic;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "\u0411\u042b\u0421\u0422\u0420\u042b\u0415 \u041e\u0422\u0412\u0415\u0422\u042b"

    goto :goto_0

    :cond_1
    iget-object v0, v8, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v0

    .line 2341
    :goto_0
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda26;

    invoke-direct {v1, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda26;-><init>(Lru/supportagent/OverlayService;)V

    const-string v2, "\u0420\u0415\u0414\u0410\u041a\u0422\u0418\u0420\u041e\u0412\u0410\u041d\u0418\u0415 \u041e\u0422\u0412\u0415\u0422\u041e\u0412"

    invoke-direct {v7, v0, v2, v1}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v9

    const-string v0, "+ \u041d\u041e\u0412\u042b\u0419 \u041e\u0422\u0412\u0415\u0422"

    const/4 v1, 0x1

    .line 2342
    invoke-direct {v7, v0, v1}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    .line 2343
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda27;

    invoke-direct {v0, v7, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda27;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x20

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 2344
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2345
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v10

    .line 2346
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v11

    .line 2347
    iget-object v0, v7, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v1, v8, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->getTemplates(Ljava/lang/String;)Ljava/util/List;

    move-result-object v12

    .line 2348
    invoke-interface {v12}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v13, 0x0

    if-eqz v0, :cond_2

    const/high16 v0, 0x41300000    # 11.0f

    .line 2349
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041f\u043e\u043a\u0430 \u043d\u0435\u0442 \u043e\u0442\u0432\u0435\u0442\u043e\u0432. \u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u043f\u0435\u0440\u0432\u044b\u0439 \u0432\u044b\u0448\u0435."

    invoke-static {v7, v2, v0, v1, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    const/16 v0, 0x11

    .line 2350
    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v4, 0x10

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2351
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2354
    :cond_2
    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v14

    const/4 v0, 0x0

    :goto_1
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v15, v1

    check-cast v15, Lru/supportagent/AnswerTemplate;

    .line 2355
    iget-object v1, v15, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    if-nez v1, :cond_3

    const-string v1, ""

    goto :goto_2

    :cond_3
    iget-object v1, v15, Lru/supportagent/AnswerTemplate;->section:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    :goto_2
    move-object v6, v1

    .line 2356
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    .line 2357
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4

    invoke-direct {v7, v12, v6}, Lru/supportagent/OverlayService;->countSection(Ljava/util/List;Ljava/lang/String;)I

    move-result v0

    invoke-direct {v7, v6, v0}, Lru/supportagent/OverlayService;->sectionHeader(Ljava/lang/String;I)Landroid/view/View;

    move-result-object v5

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/16 v16, 0x0

    const/16 v17, 0x5

    move-object/from16 v0, p0

    move-object v13, v5

    move/from16 v5, v16

    move-object/from16 v16, v6

    move/from16 v6, v17

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_3

    :cond_4
    move-object/from16 v16, v6

    goto :goto_3

    :cond_5
    move-object/from16 v16, v0

    .line 2360
    :goto_3
    invoke-direct {v7, v8, v15}, Lru/supportagent/OverlayService;->manageAnswerCard(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)Landroid/view/View;

    move-result-object v13

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v0, v16

    const/4 v13, 0x0

    goto :goto_1

    .line 2362
    :cond_6
    invoke-virtual {v10, v11}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2363
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-direct {v0, v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2364
    invoke-direct {v7, v9, v3}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    return-void
.end method

.method private showManageThemes()V
    .locals 23

    move-object/from16 v8, p0

    .line 2225
    new-instance v9, Lru/supportagent/PaletteRepository;

    invoke-direct {v9, v8}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    .line 2226
    invoke-virtual {v9}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object v0

    iput-object v0, v8, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    const-string v0, "manage_themes"

    .line 2227
    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    .line 2228
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda70;

    invoke-direct {v0, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda70;-><init>(Lru/supportagent/OverlayService;)V

    const-string v1, "\u041e\u0424\u041e\u0420\u041c\u041b\u0415\u041d\u0418\u0415"

    const-string v2, "\u0421\u0412\u041e\u0419 \u0426\u0412\u0415\u0422 \u041f\u0410\u041d\u0415\u041b\u0418 \u0418 \u041a\u0420\u0423\u0413\u0410"

    invoke-direct {v8, v1, v2, v0}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v10

    .line 2232
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v11

    .line 2233
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v12

    const/high16 v0, 0x41180000    # 9.5f

    .line 2236
    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v8, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041f\u0440\u043e\u0432\u0435\u0434\u0438\u0442\u0435 \u043f\u043e \u0446\u0432\u0435\u0442\u043d\u043e\u043c\u0443 \u0448\u0430\u0440\u0443: \u043f\u0440\u0435\u0434\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440 \u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f \u0441\u0440\u0430\u0437\u0443. \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u0435 \u0442\u043e\u043b\u044c\u043a\u043e \u0442\u043e\u0442 \u0446\u0432\u0435\u0442, \u043a\u043e\u0442\u043e\u0440\u044b\u0439 \u0432\u0430\u043c \u043f\u043e\u043d\u0440\u0430\u0432\u0438\u043b\u0441\u044f."

    const/4 v13, 0x0

    .line 2234
    invoke-static {v8, v2, v0, v1, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v7

    const/high16 v14, 0x3f800000    # 1.0f

    .line 2237
    invoke-direct {v8, v14}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v7, v0, v14}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x8

    move-object/from16 v0, p0

    .line 2238
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v15, 0x1

    new-array v7, v15, [I

    .line 2240
    iget-object v0, v8, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    aput v0, v7, v13

    .line 2241
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v5, 0x10

    .line 2242
    invoke-virtual {v6, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2243
    new-instance v4, Lru/supportagent/ColorWheelView;

    invoke-direct {v4, v8}, Lru/supportagent/ColorWheelView;-><init>(Landroid/content/Context;)V

    aget v0, v7, v13

    .line 2244
    invoke-virtual {v4, v0}, Lru/supportagent/ColorWheelView;->setColor(I)V

    const/16 v1, 0x80

    const/16 v2, 0x80

    const/16 v16, 0x0

    const/16 v17, 0xa

    const/16 v18, 0x0

    move-object/from16 v0, p0

    move-object v14, v4

    move/from16 v4, v16

    move v15, v5

    move/from16 v5, v17

    move-object v15, v6

    move/from16 v6, v18

    .line 2245
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v15, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2247
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v6

    .line 2248
    invoke-virtual {v6, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x10

    .line 2249
    invoke-virtual {v6, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2250
    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 2251
    invoke-virtual {v5, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v1, 0x4109999a    # 8.6f

    .line 2252
    invoke-direct {v8, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v8, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    const-string v3, "\u0416\u0418\u0412\u041e\u0419 \u041f\u0420\u0415\u0414\u041f\u0420\u041e\u0421\u041c\u041e\u0422\u0420"

    invoke-static {v8, v3, v1, v2, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v4

    const v1, 0x3d4ccccd    # 0.05f

    .line 2253
    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 2254
    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    aget v1, v7, v13

    .line 2255
    invoke-direct {v8, v1}, Lru/supportagent/OverlayService;->colorToHex(I)Ljava/lang/String;

    move-result-object v1

    const/high16 v2, 0x41700000    # 15.0f

    invoke-direct {v8, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, v8, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v3

    invoke-static {v8, v1, v2, v3, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v3

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v17, 0x0

    const/16 v18, 0x3

    const/16 v19, 0x0

    const/16 v20, 0x5

    move-object/from16 v0, p0

    move-object v13, v3

    move/from16 v3, v17

    move-object/from16 v17, v4

    move/from16 v4, v18

    move-object/from16 v21, v5

    move/from16 v5, v19

    move-object/from16 v18, v10

    move-object v10, v6

    move/from16 v6, v20

    .line 2256
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    move-object/from16 v6, v21

    invoke-virtual {v6, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x41166666    # 9.4f

    .line 2257
    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    const-string v1, "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c \u041c\u041e\u0419 \u0426\u0412\u0415\u0422"

    const/4 v5, -0x1

    const/4 v2, 0x1

    invoke-static {v8, v1, v0, v5, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v4

    const/16 v0, 0x11

    .line 2258
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v0, 0x40e00000    # 7.0f

    .line 2259
    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {v4, v1, v2, v3, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v1, -0x1

    const/16 v2, 0x1e

    const/4 v3, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    move-object/from16 v0, p0

    move-object/from16 v22, v4

    move/from16 v4, v19

    move/from16 v5, v20

    move-object/from16 v19, v11

    move-object v11, v6

    move/from16 v6, v21

    .line 2260
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    move-object/from16 v6, v22

    invoke-virtual {v11, v6, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2261
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v5, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2262
    new-instance v11, Landroid/widget/TextView;

    invoke-direct {v11, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v0, "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u0446\u0432\u0435\u0442"

    .line 2263
    invoke-virtual {v11, v0}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/16 v1, 0x1c

    const/16 v2, 0x1c

    const/16 v3, 0x8

    const/4 v4, 0x0

    move-object/from16 v0, p0

    move/from16 v5, v20

    move-object/from16 v20, v6

    move/from16 v6, v21

    .line 2264
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2265
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, -0x2

    invoke-direct {v0, v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v15, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x9

    move-object/from16 v0, p0

    .line 2266
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x0

    aget v1, v7, v0

    .line 2268
    invoke-static {v1}, Lru/supportagent/AgentPalette;->wheel(I)Lru/supportagent/AgentPalette;

    move-result-object v1

    move-object/from16 v0, p0

    move-object v2, v10

    move-object/from16 v3, v17

    move-object v4, v13

    move-object/from16 v5, v20

    move-object v6, v11

    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->applyWheelPreview(Lru/supportagent/AgentPalette;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    .line 2269
    new-instance v15, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;

    move-object v0, v15

    move-object/from16 v1, p0

    move-object v2, v7

    move-object v3, v10

    move-object/from16 v4, v17

    move-object v5, v13

    move-object/from16 v6, v20

    move-object v10, v7

    move-object v7, v11

    invoke-direct/range {v0 .. v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda71;-><init>(Lru/supportagent/OverlayService;[ILandroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    invoke-virtual {v14, v15}, Lru/supportagent/ColorWheelView;->setOnColorChangedListener(Lru/supportagent/ColorWheelView$OnColorChangedListener;)V

    const-string v0, "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c \u0412\u042b\u0411\u0420\u0410\u041d\u041d\u042b\u0419 \u0426\u0412\u0415\u0422"

    const/4 v1, 0x1

    .line 2277
    invoke-direct {v8, v0, v1}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v7

    .line 2278
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;

    invoke-direct {v0, v8, v9, v10}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda72;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/PaletteRepository;[I)V

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x20

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    move-object/from16 v0, p0

    .line 2285
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x410ccccd    # 8.8f

    .line 2288
    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v8, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0414\u0440\u0443\u0433\u0438\u0435 \u0433\u043e\u0442\u043e\u0432\u044b\u0435 \u043f\u0430\u043b\u0438\u0442\u0440\u044b \u0441\u043a\u0440\u044b\u0442\u044b \u0438\u0437 \u044d\u0442\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430. \u0412\u0430\u0448 \u0432\u044b\u0431\u043e\u0440 \u0445\u0440\u0430\u043d\u0438\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043d\u0430 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435 \u0438 \u0435\u0433\u043e \u043c\u043e\u0436\u043d\u043e \u0437\u0430\u043c\u0435\u043d\u0438\u0442\u044c \u0432 \u043b\u044e\u0431\u043e\u0439 \u043c\u043e\u043c\u0435\u043d\u0442."

    const/4 v3, 0x0

    .line 2286
    invoke-static {v8, v2, v0, v1, v3}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v7

    const/high16 v0, 0x3f800000    # 1.0f

    .line 2289
    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v7, v1, v0}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2290
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v0, v19

    .line 2291
    invoke-virtual {v0, v12}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2292
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, -0x1

    invoke-direct {v1, v4, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v3, v18

    invoke-virtual {v3, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2293
    invoke-direct {v8, v3, v2}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    return-void
.end method

.method private showManageTopics()V
    .locals 0

    invoke-static {p0}, Lru/supportagent/TopicsPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method private showModal(Landroid/view/View;II)V
    .locals 4

    .line 2579
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    const/high16 v0, 0x42a00000    # 80.0f

    .line 2580
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    if-lez p2, :cond_0

    goto :goto_0

    :cond_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result p2

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr p2, v2

    :goto_0
    invoke-static {v1, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    const/high16 v1, 0x40000000    # 2.0f

    .line 2581
    invoke-static {p2, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    .line 2582
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v2

    const/high16 v3, 0x41400000    # 12.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/high16 v2, -0x80000000

    invoke-static {v0, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    .line 2583
    invoke-virtual {p1, v1, v0}, Landroid/view/View;->measure(II)V

    if-lez p3, :cond_1

    move v0, p3

    goto :goto_1

    :cond_1
    const/high16 v0, 0x42700000    # 60.0f

    .line 2584
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    :goto_1
    const/4 v1, 0x0

    .line 2586
    invoke-direct {p0, p2, p3, v1}, Lru/supportagent/OverlayService;->overlayParams(IIZ)Landroid/view/WindowManager$LayoutParams;

    move-result-object p3

    const v1, 0x800033

    .line 2587
    iput v1, p3, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 2588
    invoke-direct {p0, p3, p2, v0}, Lru/supportagent/OverlayService;->positionModalAtPanelCenter(Landroid/view/WindowManager$LayoutParams;II)V

    .line 2589
    iput-object p1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    .line 2590
    iput-object p3, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    .line 2591
    :try_start_0
    iget-object p2, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {p2, p1, p3}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    const/4 p1, 0x0

    .line 2593
    iput-object p1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    .line 2594
    iput-object p1, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    :goto_2
    return-void
.end method

.method private showQuickOverflow(Ljava/util/List;)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/AnswerTemplate;",
            ">;)V"
        }
    .end annotation

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    const/4 v9, 0x0

    if-nez v8, :cond_0

    move v10, v9

    goto :goto_0

    .line 1654
    :cond_0
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    move-result v0

    move v10, v0

    .line 1655
    :goto_0
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 1656
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v11

    const/high16 v0, 0x41400000    # 12.0f

    .line 1657
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x41200000    # 10.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    const/high16 v3, 0x41300000    # 11.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v11, v1, v2, v0, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1658
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    const/high16 v3, 0x41700000    # 15.0f

    :goto_1
    invoke-static {v0, v1, v3, v7}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1660
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-direct {v12, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1661
    invoke-virtual {v12, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v13, Landroid/widget/ImageView;

    invoke-direct {v13, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070081

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v0, -0x1

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v13, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v0, 0x41900000    # 18.0f

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40400000    # 3.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v12, v13, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x41480000    # 12.5f

    .line 1662
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const-string v2, "\u0411\u042b\u0421\u0422\u0420\u042b\u0415 \u041e\u0422\u0412\u0415\u0422\u042b"

    const/4 v13, 0x1

    invoke-static {v7, v2, v0, v1, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 1663
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v1, v9, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v12, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    const/16 v1, 0x8

    const v2, 0x7f07005e

    const/4 v6, -0x1

    .line 1664
    invoke-direct {v7, v2, v0, v6, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v5

    .line 1665
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda9;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda9;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v5, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1b

    const/16 v2, 0x1b

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object/from16 v0, p0

    move-object v14, v5

    move/from16 v5, v16

    move/from16 v6, v17

    .line 1666
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v12, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, p0

    .line 1667
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v12, 0x4

    if-nez v10, :cond_2

    const-string v0, "\u041f\u043e\u043a\u0430 \u043d\u0435\u0442 \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432. \u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u0438\u0445 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 \u2014 \u0442\u0440\u0438 \u0442\u043e\u0447\u043a\u0438 \u0432\u0441\u0435\u0433\u0434\u0430 \u043e\u0441\u0442\u0430\u043d\u0443\u0442\u0441\u044f \u0437\u0434\u0435\u0441\u044c."

    goto :goto_2

    :cond_2
    if-gt v10, v12, :cond_3

    .line 1672
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u0412\u0441\u0435 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u0430 \u0443\u0436\u0435 \u0432\u0438\u0434\u043d\u044b \u0432\u043d\u0438\u0437\u0443 \u043f\u0430\u043d\u0435\u043b\u0438. \u0417\u0434\u0435\u0441\u044c \u043f\u043e\u044f\u0432\u044f\u0442\u0441\u044f \u043e\u0442\u0432\u0435\u0442\u044b \u043f\u043e\u0441\u043b\u0435 \u0447\u0435\u0442\u0432\u0451\u0440\u0442\u043e\u0433\u043e."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_2

    .line 1673
    :cond_3
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041e\u0442\u0432\u0435\u0442\u044b \u043f\u043e\u0441\u043b\u0435 \u0447\u0435\u0442\u0432\u0451\u0440\u0442\u043e\u0433\u043e: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ". \u041f\u0435\u0440\u0432\u044b\u0435 \u0447\u0435\u0442\u044b\u0440\u0435 \u043e\u0441\u0442\u0430\u044e\u0442\u0441\u044f \u0432\u043d\u0438\u0437\u0443 \u043f\u0430\u043d\u0435\u043b\u0438."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_2
    const v1, 0x41133333    # 9.2f

    .line 1674
    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v2

    invoke-static {v7, v0, v1, v2, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v14

    .line 1675
    invoke-direct {v7, v15}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v14, v0, v15}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v15, 0x7

    if-le v10, v12, :cond_4

    move v6, v15

    goto :goto_3

    :cond_4
    const/16 v0, 0x9

    move v6, v0

    :goto_3
    move-object/from16 v0, p0

    .line 1676
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-le v10, v12, :cond_7

    .line 1679
    new-instance v14, Landroid/widget/ScrollView;

    invoke-direct {v14, v7}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 1680
    invoke-virtual {v14, v13}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 1681
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v6

    move v5, v12

    :goto_4
    if-ge v5, v10, :cond_5

    .line 1683
    invoke-interface {v8, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/supportagent/AnswerTemplate;

    .line 1684
    iget-object v1, v0, Lru/supportagent/AnswerTemplate;->title:Ljava/lang/String;

    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->quickButton(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    const/high16 v1, 0x41280000    # 10.5f

    .line 1685
    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1686
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1687
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda10;

    invoke-direct {v1, v7, v0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda10;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/AnswerTemplate;)V

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x20

    const/4 v3, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x5

    move-object/from16 v0, p0

    move-object v9, v4

    move/from16 v4, v16

    move/from16 v16, v5

    move/from16 v5, v17

    move-object v13, v6

    move/from16 v6, v18

    .line 1688
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v13, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v5, v16, 0x1

    move-object v6, v13

    const/4 v9, 0x0

    const/4 v13, 0x1

    goto :goto_4

    :cond_5
    move-object v13, v6

    .line 1690
    invoke-virtual {v14, v13}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1691
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_6

    const/high16 v0, 0x43760000    # 246.0f

    goto :goto_5

    :cond_6
    const/high16 v0, 0x439b0000    # 310.0f

    :goto_5
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v1

    const/high16 v2, 0x43200000    # 160.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v1, :qo_sv_done

    iget v1, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    if-lez v1, :qo_sv_done

    const/high16 v2, 0x43200000    # 160.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    :qo_sv_done
    .line 1692
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x428c0000    # 70.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v2, -0x1

    invoke-direct {v1, v2, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v14, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_7
    if-nez v10, :cond_8

    const/4 v13, 0x1

    goto :goto_6

    :cond_8
    const/4 v13, 0x0

    :goto_6
    const-string v0, "\u041d\u0410\u0421\u0422\u0420\u041e\u0418\u0422\u042c \u0411\u042b\u0421\u0422\u0420\u042b\u0415 \u041e\u0422\u0412\u0415\u0422\u042b"

    .line 1695
    invoke-direct {v7, v0, v13}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v8

    .line 1696
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda12;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda12;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x1f

    const/4 v3, 0x0

    if-le v10, v12, :cond_9

    move v4, v15

    goto :goto_7

    :cond_9
    const/4 v4, 0x0

    :goto_7
    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1700
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1701
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_a

    const/high16 v0, 0x435c0000    # 220.0f

    goto :goto_8

    :cond_a
    const/high16 v0, 0x436c0000    # 236.0f

    :goto_8
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v1

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/high16 v1, 0x40000000    # EXACTLY

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    invoke-direct {v7}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v2

    const/high16 v3, 0x43200000    # 160.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    sub-int/2addr v2, v3

    iget-object v3, v7, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v3, :qo_h_done

    iget v4, v3, Landroid/view/WindowManager$LayoutParams;->height:I

    if-lez v4, :qo_h_done

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-direct {v7, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    sub-int/2addr v4, v5

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    :qo_h_done
    const/high16 v3, -0x80000000    # AT_MOST

    invoke-static {v2, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v11, v1, v3}, Landroid/view/View;->measure(II)V

    invoke-virtual {v11}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    const/high16 v3, 0x43480000    # 200.0f

    invoke-direct {v7, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-direct {v7, v11, v0, v1}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    const/4 v0, 0x1

    iput-boolean v0, v7, Lru/supportagent/OverlayService;->quickModal:Z

    invoke-direct {v7}, Lru/supportagent/OverlayService;->positionQuickOverflow()V

    return-void
.end method

.method private showSearch()V
    .locals 10

    const-string v0, "search"

    .line 2110
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    .line 2111
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda14;

    invoke-direct {v0, p0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda14;-><init>(Lru/supportagent/OverlayService;)V

    const-string v1, "\u041f\u041e\u0418\u0421\u041a"

    const-string v2, "\u041f\u041e \u0422\u0415\u041c\u0410\u041c \u0418 \u0422\u0415\u041a\u0421\u0422\u0423 \u041e\u0422\u0412\u0415\u0422\u041e\u0412"

    invoke-direct {p0, v1, v2, v0}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u0435\u043a\u0441\u0442 \u0434\u043b\u044f \u043f\u043e\u0438\u0441\u043a\u0430\u2026"

    const/4 v2, 0x0

    .line 2112
    invoke-direct {p0, v1, v2}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v1

    const/4 v4, -0x1

    const/16 v5, 0x23

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    move-object v3, p0

    .line 2113
    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2114
    invoke-direct {p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v3

    .line 2115
    invoke-direct {p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v4

    .line 2116
    invoke-virtual {v3, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2117
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v5, v6, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2118
    new-instance v2, Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;

    invoke-direct {v2, p0, v4}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda50;-><init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;)V

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->debouncedSearchWatcher(Lru/supportagent/OverlayService$SearchRenderer;)Landroid/text/TextWatcher;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const-string v2, ""

    .line 2119
    invoke-direct {p0, v4, v2}, Lru/supportagent/OverlayService;->renderSearchResults(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    const/4 v2, 0x1

    .line 2120
    invoke-direct {p0, v0, v2}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    .line 2121
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->focusInput(Landroid/widget/EditText;)V

    return-void
.end method

.method private showSelectedAiReply(Landroid/widget/TextView;)V
    .locals 3

    .line 1414
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->selectedAiFragment(Landroid/widget/TextView;)Ljava/lang/String;

    move-result-object p1

    .line 1415
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const-string p1, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u044b\u0434\u0435\u043b\u0438\u0442\u0435 \u043d\u0443\u0436\u043d\u0443\u044e \u0447\u0430\u0441\u0442\u044c \u043e\u0442\u0432\u0435\u0442\u0430 \u0443\u0434\u0435\u0440\u0436\u0430\u043d\u0438\u0435\u043c \u0442\u0435\u043a\u0441\u0442\u0430."

    .line 1416
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 1419
    :cond_0
    invoke-static {p1}, Lru/supportagent/ReplyComposer;->cleanBody(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 1420
    invoke-static {p1}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 1421
    invoke-static {p1}, Lru/supportagent/ReplyComposer;->length(Ljava/lang/String;)I

    move-result p1

    const/16 v0, 0x78

    if-le p1, v0, :cond_1

    .line 1423
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "\u0412\u044b\u0434\u0435\u043b\u0435\u043d\u043d\u044b\u0439 \u0444\u0440\u0430\u0433\u043c\u0435\u043d\u0442: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, " / 120. \u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043a\u043e\u0440\u043e\u0447\u0435."

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_1
    const-string p1, "\u0412\u044b\u0434\u0435\u043b\u0438\u0442\u0435 \u0442\u0435\u043a\u0441\u0442 \u043e\u0442\u0432\u0435\u0442\u0430, \u0430 \u043d\u0435 \u043f\u0443\u0441\u0442\u043e\u0435 \u043c\u0435\u0441\u0442\u043e."

    .line 1422
    :goto_0
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    .line 1424
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 1427
    :cond_2
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showAiReplyConfirmation(Ljava/lang/String;)V

    return-void
.end method

.method private showStatistics()V
    .locals 17

    move-object/from16 v7, p0

    .line 1706
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 1707
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 1708
    iget-object v0, v7, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    if-nez v0, :cond_0

    new-instance v0, Lru/supportagent/StatisticsRepository;

    invoke-direct {v0, v7}, Lru/supportagent/StatisticsRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, v7, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    .line 1709
    :cond_0
    iget-object v0, v7, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    invoke-virtual {v0}, Lru/supportagent/StatisticsRepository;->snapshot()Lru/supportagent/StatisticsRepository$Snapshot;

    move-result-object v8

    .line 1710
    invoke-static/range {p0 .. p0}, Lru/supportagent/SupportAccessibilityService;->isEnabled(Landroid/content/Context;)Z

    move-result v9

    .line 1712
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v10

    const/high16 v0, 0x41500000    # 13.0f

    .line 1713
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v2, 0x41300000    # 11.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    const/high16 v4, 0x41400000    # 12.0f

    invoke-direct {v7, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v10, v1, v3, v0, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1714
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_0

    :cond_1
    const/high16 v2, 0x41700000    # 15.0f

    :goto_0
    invoke-static {v0, v1, v2, v7}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1715
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1716
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v0, 0x41600000    # 14.0f

    .line 1717
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v1

    const-string v2, "\u0421\u0422\u0410\u0422\u0418\u0421\u0422\u0418\u041a\u0410"

    const/4 v12, 0x1

    invoke-static {v7, v2, v0, v1, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 1718
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, 0x0

    const/4 v14, -0x2

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v1, v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, -0x1

    const/16 v1, 0x8

    const v2, 0x7f07005e

    const-string v3, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c \u0441\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043a\u0443"

    .line 1719
    invoke-direct {v7, v2, v3, v0, v1}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v6

    .line 1720
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda30;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda30;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v6, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x1b

    const/16 v2, 0x1b

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move-object v12, v6

    move/from16 v6, v16

    .line 1721
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v6, 0x7

    move-object/from16 v0, p0

    .line 1722
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1724
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x30

    .line 1725
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1726
    iget v0, v8, Lru/supportagent/StatisticsRepository$Snapshot;->totalAnswers:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "\u0421\u0435\u0433\u043e\u0434\u043d\u044f: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, v8, Lru/supportagent/StatisticsRepository$Snapshot;->todayAnswers:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u041e\u0422\u0412\u0415\u0422\u041e\u0412 \u0412\u042b\u0414\u0410\u041d\u041e"

    invoke-direct {v7, v2, v0, v1}, Lru/supportagent/OverlayService;->statisticsCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1728
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v1, 0x40a00000    # 5.0f

    .line 1729
    invoke-direct {v7, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-virtual {v0, v1, v13, v13, v13}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    if-eqz v9, :cond_3

    .line 1731
    iget-boolean v1, v8, Lru/supportagent/StatisticsRepository$Snapshot;->gameActive:Z

    if-eqz v1, :cond_2

    const-string v1, "Black Russia \u0441\u0435\u0439\u0447\u0430\u0441 \u043e\u0442\u043a\u0440\u044b\u0442\u0430"

    goto :goto_1

    :cond_2
    const-string v1, "\u0412 Black Russia \u0441\u0435\u0433\u043e\u0434\u043d\u044f"

    goto :goto_1

    :cond_3
    const-string v1, "\u041d\u0435 \u043d\u0443\u0436\u043d\u043e \u0434\u043b\u044f \u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f"

    .line 1733
    :goto_1
    iget-wide v2, v8, Lru/supportagent/StatisticsRepository$Snapshot;->todayGameMillis:J

    invoke-static {v2, v3}, Lru/supportagent/StatisticsRepository;->formatDuration(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u0412 \u0418\u0413\u0420\u0415 \u0421\u0415\u0413\u041e\u0414\u041d\u042f"

    invoke-direct {v7, v3, v2, v1}, Lru/supportagent/OverlayService;->statisticsCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v11, v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x8

    move-object/from16 v0, p0

    .line 1734
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x4114cccd    # 9.3f

    .line 1738
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041e\u0442\u0432\u0435\u0442\u044b \u0432\u0441\u0435\u0433\u0434\u0430 \u043a\u043e\u043f\u0438\u0440\u0443\u044e\u0442\u0441\u044f \u0432\u0440\u0443\u0447\u043d\u0443\u044e: \u0442\u0435\u043a\u0441\u0442 \u0438\u0433\u0440\u044b \u043d\u0435 \u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044f \u0438 \u043d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442\u0441\u044f."

    .line 1736
    invoke-static {v7, v2, v0, v1, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v8

    .line 1739
    invoke-direct {v7, v15}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v8, v0, v15}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v6, 0x9

    move-object/from16 v0, p0

    .line 1740
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0413\u041e\u0422\u041e\u0412\u041e"

    const/4 v1, 0x1

    .line 1741
    invoke-direct {v7, v0, v1}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v8

    .line 1742
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda31;

    invoke-direct {v0, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda31;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x20

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 1743
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1744
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v0

    if-eqz v0, :cond_4

    const/high16 v0, 0x43ab0000    # 342.0f

    goto :goto_2

    :cond_4
    const/high16 v0, 0x43b90000    # 370.0f

    :goto_2
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v1

    const/high16 v2, 0x41b00000    # 22.0f

    invoke-direct {v7, v2}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-direct {v7, v10, v0, v14}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    return-void
.end method

.method private showTemplates(Lru/supportagent/Topic;)V
    .locals 18

    move-object/from16 v8, p0

    .line 1814
    iget-object v0, v8, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    move-object/from16 v1, p1

    iget-object v1, v1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->getTopic(Ljava/lang/String;)Lru/supportagent/Topic;

    move-result-object v9

    if-nez v9, :cond_0

    .line 1815
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->showHome()V

    return-void

    .line 1816
    :cond_0
    iput-object v9, v8, Lru/supportagent/OverlayService;->openedTopic:Lru/supportagent/Topic;

    .line 1817
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "topic_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v9, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v8, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    .line 1818
    iget-object v0, v9, Lru/supportagent/Topic;->name:Ljava/lang/String;

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda14;

    invoke-direct {v1, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda14;-><init>(Lru/supportagent/OverlayService;)V

    const-string v2, "\u0412\u042b\u0411\u0415\u0420\u0418\u0422\u0415 \u0413\u041e\u0422\u041e\u0412\u042b\u0419 \u041e\u0422\u0412\u0415\u0422"

    invoke-direct {v8, v0, v2, v1}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v10

    const-string v0, "\u041f\u041e\u0418\u0421\u041a \u0412 \u0422\u0415\u041c\u0415"

    const v1, 0x7f070066

    const/4 v11, 0x0

    .line 1820
    invoke-direct {v8, v0, v1, v11}, Lru/supportagent/OverlayService;->centeredIconButton(Ljava/lang/String;IZ)Landroid/widget/LinearLayout;

    move-result-object v7

    const-string v0, "\u0418\u0441\u043a\u0430\u0442\u044c \u0442\u043e\u043b\u044c\u043a\u043e \u0432 \u044d\u0442\u043e\u0439 \u0442\u0435\u043c\u0435"

    .line 1821
    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 1822
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda18;

    invoke-direct {v0, v8, v9}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda18;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x1f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, p0

    .line 1823
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v7, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1825
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v12

    .line 1826
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v13

    .line 1829
    iget-object v0, v8, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v1, v9, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->getTemplates(Ljava/lang/String;)Ljava/util/List;

    move-result-object v14

    .line 1830
    iget-object v0, v8, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v1, v9, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->getSections(Ljava/lang/String;)Ljava/util/List;

    move-result-object v15

    .line 1831
    iget-object v0, v8, Lru/supportagent/OverlayService;->topicSectionFilters:Ljava/util/Map;

    iget-object v1, v9, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 1832
    invoke-interface {v15}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v0, ""

    goto :goto_0

    :cond_1
    const-string v1, "__sections__"

    if-eqz v0, :cond_2

    .line 1834
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    invoke-interface {v15, v0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    :cond_2
    move-object v0, v1

    :cond_3
    :goto_0
    const/4 v1, 0x1

    new-array v7, v1, [Ljava/lang/String;

    aput-object v0, v7, v11

    new-array v6, v1, [Landroid/widget/LinearLayout;

    const/4 v0, 0x0

    aput-object v0, v6, v11

    .line 1840
    invoke-interface {v15}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4

    .line 1841
    new-instance v5, Landroid/widget/HorizontalScrollView;

    invoke-direct {v5, v8}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .line 1842
    invoke-virtual {v5, v11}, Landroid/widget/HorizontalScrollView;->setHorizontalScrollBarEnabled(Z)V

    .line 1843
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1844
    invoke-virtual {v4, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    aput-object v4, v6, v11

    move-object/from16 v0, p0

    move-object v1, v4

    move-object v2, v9

    move-object v3, v14

    move-object v11, v4

    move-object v4, v15

    move-object v8, v5

    move-object v5, v7

    move-object/from16 v16, v6

    move-object v6, v13

    move-object/from16 v17, v7

    move-object v7, v12

    .line 1846
    invoke-direct/range {v0 .. v7}, Lru/supportagent/OverlayService;->renderSectionChips(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    .line 1847
    invoke-virtual {v8, v11}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    const/4 v1, -0x1

    const/16 v2, 0x1f

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    .line 1848
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x0

    goto :goto_1

    :cond_4
    move-object/from16 v16, v6

    move-object/from16 v17, v7

    move v0, v11

    :goto_1
    aget-object v6, v16, v0

    move-object/from16 v0, p0

    move-object v1, v13

    move-object v2, v9

    move-object v3, v14

    move-object v4, v15

    move-object/from16 v5, v17

    move-object v7, v12

    .line 1850
    invoke-direct/range {v0 .. v7}, Lru/supportagent/OverlayService;->renderTopicContent(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;)V

    .line 1851
    invoke-virtual {v12, v13}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1852
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-direct {v0, v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v9, Lru/supportagent/Topic;->id:Ljava/lang/String;

    const-string v1, "gps"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :gps_row_skip

    move-object/from16 v2, p0

    const/4 v0, 0x2

    invoke-virtual {v10, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v5, 0x0

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    invoke-virtual {v1, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Lru/supportagent/GpsShiftOpen;

    invoke-direct {v1, v2}, Lru/supportagent/GpsShiftOpen;-><init>(Lru/supportagent/OverlayService;)V

    invoke-static {v2, v1}, Lru/supportagent/GpsShiftUi;->makeRow(Landroid/content/Context;Ljava/lang/Runnable;)Landroid/view/View;

    move-result-object v1

    iput-object v1, v2, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :gps_row_skip
    move-object/from16 v0, p0

    .line 1853
    invoke-direct {v0, v10, v3}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    return-void
.end method

.method private showTopicEditor(Lru/supportagent/Topic;)V
    .locals 16

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    if-nez v8, :cond_0

    const-string v0, "new_topic"

    goto :goto_0

    .line 2384
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "edit_topic_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v8, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    if-nez v8, :cond_1

    const-string v0, "\u041d\u041e\u0412\u0410\u042f \u0422\u0415\u041c\u0410"

    goto :goto_1

    :cond_1
    const-string v0, "\u0418\u0417\u041c\u0415\u041d\u0418\u0422\u042c \u0422\u0415\u041c\u0423"

    .line 2385
    :goto_1
    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda26;

    invoke-direct {v1, v7}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda26;-><init>(Lru/supportagent/OverlayService;)V

    const-string v2, "\u041d\u0410\u0417\u0412\u0410\u041d\u0418\u0415 \u0411\u0423\u0414\u0415\u0422 \u0412\u0418\u0414\u041d\u041e \u0412 \u041a\u0420\u0423\u0413\u0415"

    invoke-direct {v7, v0, v2, v1}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v9

    .line 2386
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v10

    .line 2387
    invoke-direct/range {p0 .. p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v11

    const/high16 v0, 0x41100000    # 9.0f

    .line 2388
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u041d\u0410\u0417\u0412\u0410\u041d\u0418\u0415 \u0422\u0415\u041c\u042b"

    const/4 v12, 0x1

    invoke-static {v7, v2, v0, v1, v12}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v13

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    move-object/from16 v0, p0

    .line 2389
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, \u0424\u0440\u0430\u043a\u0446\u0438\u0438"

    const/4 v13, 0x0

    .line 2390
    invoke-direct {v7, v0, v13}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v14

    new-array v0, v12, [Landroid/text/InputFilter;

    .line 2391
    new-instance v1, Landroid/text/InputFilter$LengthFilter;

    const/16 v2, 0x1a

    invoke-direct {v1, v2}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    aput-object v1, v0, v13

    invoke-virtual {v14, v0}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    if-eqz v8, :cond_2

    .line 2392
    iget-object v0, v8, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-virtual {v14, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    const/4 v1, -0x1

    const/16 v2, 0x24

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    move-object/from16 v0, p0

    .line 2393
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v14, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x410ccccd    # 8.8f

    .line 2394
    invoke-direct {v7, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    const-string v2, "\u0414\u043e 26 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432 \u2014 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043d\u0435 \u0432\u044b\u0439\u0434\u0435\u0442 \u0437\u0430 \u0433\u0440\u0430\u043d\u0438\u0446\u044b \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438."

    invoke-static {v7, v2, v0, v1, v13}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v15

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x1

    const/16 v6, 0x8

    move-object/from16 v0, p0

    .line 2395
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0421\u041e\u0425\u0420\u0410\u041d\u0418\u0422\u042c"

    .line 2396
    invoke-direct {v7, v0, v12}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v15

    .line 2397
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda64;

    invoke-direct {v0, v7, v14, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda64;-><init>(Lru/supportagent/OverlayService;Landroid/widget/EditText;Lru/supportagent/Topic;)V

    invoke-virtual {v15, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0x20

    const/4 v3, 0x0

    if-nez v8, :cond_3

    move v6, v13

    goto :goto_2

    :cond_3
    const/4 v0, 0x6

    move v6, v0

    :goto_2
    move-object/from16 v0, p0

    .line 2403
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v8, :cond_4

    const-string v0, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c \u0422\u0415\u041c\u0423"

    .line 2405
    invoke-direct {v7, v0, v13}, Lru/supportagent/OverlayService;->compactButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v15

    .line 2406
    iget-object v0, v7, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v15, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2407
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda65;

    invoke-direct {v0, v7, v8}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda65;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {v15, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/16 v2, 0x1e

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v0, p0

    .line 2408
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v15, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2410
    :cond_4
    invoke-virtual {v10, v11}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2411
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v13, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2412
    invoke-direct {v7, v9, v12}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    .line 2413
    invoke-direct {v7, v14}, Lru/supportagent/OverlayService;->focusInput(Landroid/widget/EditText;)V

    return-void
.end method

.method private showTopicSearch(Lru/supportagent/Topic;)V
    .locals 10

    .line 2008
    iget-object v0, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object p1, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, p1}, Lru/supportagent/TemplateRepository;->getTopic(Ljava/lang/String;)Lru/supportagent/Topic;

    move-result-object p1

    if-nez p1, :cond_0

    .line 2009
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showHome()V

    return-void

    .line 2010
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "topic_search_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->preparePage(Ljava/lang/String;)V

    .line 2011
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041f\u041e\u0418\u0421\u041a: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;

    invoke-direct {v1, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda38;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    const-string v2, "\u0422\u041e\u041b\u042c\u041a\u041e \u0412 \u042d\u0422\u041e\u0419 \u0422\u0415\u041c\u0415"

    invoke-direct {p0, v0, v2, v1}, Lru/supportagent/OverlayService;->shell(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435, \u043a\u043e\u043c\u0430\u043d\u0434\u0430 \u0438\u043b\u0438 \u0442\u0435\u043a\u0441\u0442 \u043e\u0442\u0432\u0435\u0442\u0430\u2026"

    const/4 v2, 0x0

    .line 2012
    invoke-direct {p0, v1, v2}, Lru/supportagent/OverlayService;->input(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v1

    const/4 v4, -0x1

    const/16 v5, 0x23

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    move-object v3, p0

    .line 2013
    invoke-direct/range {v3 .. v9}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2014
    invoke-direct {p0}, Lru/supportagent/OverlayService;->pageScroll()Landroid/widget/ScrollView;

    move-result-object v3

    .line 2015
    invoke-direct {p0}, Lru/supportagent/OverlayService;->pageList()Landroid/widget/LinearLayout;

    move-result-object v4

    .line 2016
    invoke-virtual {v3, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2017
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v5, v6, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2018
    new-instance v2, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;

    invoke-direct {v2, p0, v4, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda39;-><init>(Lru/supportagent/OverlayService;Landroid/widget/LinearLayout;Lru/supportagent/Topic;)V

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->debouncedSearchWatcher(Lru/supportagent/OverlayService$SearchRenderer;)Landroid/text/TextWatcher;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const-string v2, ""

    .line 2019
    invoke-direct {p0, v4, p1, v2}, Lru/supportagent/OverlayService;->renderTopicSearchResults(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/lang/String;)V

    const/4 p1, 0x1

    .line 2020
    invoke-direct {p0, v0, p1}, Lru/supportagent/OverlayService;->attachPanel(Landroid/view/View;Z)V

    .line 2021
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->focusInput(Landroid/widget/EditText;)V

    return-void
.end method

.method private simpleWatcher(Ljava/lang/Runnable;)Landroid/text/TextWatcher;
    .locals 1

    .line 2492
    new-instance v0, Lru/supportagent/OverlayService$3;

    invoke-direct {v0, p0, p1}, Lru/supportagent/OverlayService$3;-><init>(Lru/supportagent/OverlayService;Ljava/lang/Runnable;)V

    return-object v0
.end method

.method private speechErrorText(I)Ljava/lang/String;
    .locals 1

    const/4 v0, 0x7

    if-eq p1, v0, :cond_6

    const/4 v0, 0x6

    if-ne p1, v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x2

    if-eq p1, v0, :cond_5

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    goto :goto_0

    :cond_1
    const/16 v0, 0x9

    if-ne p1, v0, :cond_2

    const-string p1, "Android \u043d\u0435 \u0434\u0430\u043b \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u043c\u0438\u043a\u0440\u043e\u0444\u043e\u043d\u0443. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0435\u0433\u043e \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f."

    return-object p1

    :cond_2
    const/16 v0, 0x8

    if-ne p1, v0, :cond_3

    const-string p1, "\u041c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u0437\u0430\u043d\u044f\u0442 \u0434\u0440\u0443\u0433\u0438\u043c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435\u043c. \u0417\u0430\u043a\u0440\u043e\u0439\u0442\u0435 \u0435\u0433\u043e \u0438 \u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437."

    return-object p1

    :cond_3
    const/4 v0, 0x5

    if-ne p1, v0, :cond_4

    const-string p1, "\u0421\u0435\u0440\u0432\u0438\u0441 \u0433\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0433\u043e \u0432\u0432\u043e\u0434\u0430 \u043d\u0435 \u043e\u0442\u0432\u0435\u0442\u0438\u043b. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u043d\u0430\u0436\u0430\u0442\u044c \u043c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u0435\u0449\u0451 \u0440\u0430\u0437."

    return-object p1

    :cond_4
    const-string p1, "\u0420\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u0435 \u0440\u0435\u0447\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u043d\u043e \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e."

    return-object p1

    :cond_5
    :goto_0
    const-string p1, "\u0420\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u044e \u0440\u0435\u0447\u0438 \u043d\u0443\u0436\u0435\u043d \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442."

    return-object p1

    :cond_6
    :goto_1
    const-string p1, "\u0420\u0435\u0447\u044c \u043d\u0435 \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u043d\u0430. \u041f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0441\u043a\u0430\u0437\u0430\u0442\u044c \u0432\u043e\u043f\u0440\u043e\u0441 \u0435\u0449\u0451 \u0440\u0430\u0437."

    return-object p1
.end method

.method private startAiTypingAnimation()V
    .locals 2

    .line 1352
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiTypingAnimation:Ljava/lang/Runnable;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lru/supportagent/OverlayService;->searchHandler:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v0, 0x0

    .line 1353
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiTypingAnimation:Ljava/lang/Runnable;

    .line 1354
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lru/supportagent/OverlayService;->aiTypingIndicator:Landroid/widget/TextView;

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    .line 1355
    iput v0, p0, Lru/supportagent/OverlayService;->aiTypingPhase:I

    .line 1356
    new-instance v0, Lru/supportagent/OverlayService$1;

    invoke-direct {v0, p0}, Lru/supportagent/OverlayService$1;-><init>(Lru/supportagent/OverlayService;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->aiTypingAnimation:Ljava/lang/Runnable;

    .line 1367
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_2
    :goto_0
    return-void
.end method

.method private startVoiceRecognition()V
    .locals 3

    .line 1555
    iget-boolean v0, p0, Lru/supportagent/OverlayService;->aiListening:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lru/supportagent/OverlayService;->aiPromptField:Landroid/widget/EditText;

    if-nez v0, :cond_0

    goto :goto_0

    .line 1557
    :cond_0
    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    if-nez v0, :cond_1

    .line 1558
    invoke-static {p0}, Landroid/speech/SpeechRecognizer;->createSpeechRecognizer(Landroid/content/Context;)Landroid/speech/SpeechRecognizer;

    move-result-object v0

    iput-object v0, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    .line 1559
    new-instance v1, Lru/supportagent/OverlayService$2;

    invoke-direct {v1, p0}, Lru/supportagent/OverlayService$2;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v0, v1}, Landroid/speech/SpeechRecognizer;->setRecognitionListener(Landroid/speech/RecognitionListener;)V

    .line 1602
    :cond_1
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.speech.action.RECOGNIZE_SPEECH"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "android.speech.extra.LANGUAGE_MODEL"

    const-string v2, "free_form"

    .line 1603
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "android.speech.extra.LANGUAGE"

    const-string v2, "ru-RU"

    .line 1604
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "android.speech.extra.PARTIAL_RESULTS"

    const/4 v2, 0x1

    .line 1605
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "android.speech.extra.MAX_RESULTS"

    .line 1606
    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v0

    .line 1607
    iput-boolean v2, p0, Lru/supportagent/OverlayService;->aiListening:Z

    .line 1608
    invoke-direct {p0}, Lru/supportagent/OverlayService;->updateAiControls()V

    .line 1609
    iget-object v1, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    invoke-virtual {v1, v0}, Landroid/speech/SpeechRecognizer;->startListening(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    .line 1611
    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiListening:Z

    .line 1612
    invoke-direct {p0}, Lru/supportagent/OverlayService;->updateAiControls()V

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u044c \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u0435 \u0440\u0435\u0447\u0438."

    .line 1613
    invoke-static {p0, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_0
    return-void
.end method

.method private statisticsCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/view/View;
    .locals 9

    .line 1748
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v0

    const/high16 v1, 0x41000000    # 8.0f

    .line 1749
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    const/high16 v3, 0x40e00000    # 7.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v1, 0x4101999a    # 8.1f

    .line 1750
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const/4 v4, 0x1

    invoke-static {p0, p1, v2, v3, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1751
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1752
    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1753
    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/high16 p1, 0x41880000    # 17.0f

    .line 1754
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    invoke-static {p0, p2, p1, v2, v4}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1755
    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1756
    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v3, -0x1

    const/4 v4, -0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    move-object v2, p0

    .line 1757
    invoke-direct/range {v2 .. v8}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p2

    invoke-virtual {v0, p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1758
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result p1

    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result p2

    const/4 v1, 0x0

    invoke-static {p0, p3, p1, p2, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/4 p2, 0x2

    .line 1759
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1760
    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1761
    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-object v0
.end method

.method private stopAiTypingAnimation()V
    .locals 2

    .line 1371
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiTypingAnimation:Ljava/lang/Runnable;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lru/supportagent/OverlayService;->searchHandler:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v0, 0x0

    .line 1372
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiTypingAnimation:Ljava/lang/Runnable;

    .line 1373
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiTypingIndicator:Landroid/widget/TextView;

    return-void
.end method

.method private stopVoiceRecognition()V
    .locals 2

    .line 1637
    iget-object v0, p0, Lru/supportagent/OverlayService;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    if-eqz v0, :cond_0

    iget-boolean v1, p0, Lru/supportagent/OverlayService;->aiListening:Z

    if-eqz v1, :cond_0

    .line 1638
    :try_start_0
    invoke-virtual {v0}, Landroid/speech/SpeechRecognizer;->cancel()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v0, 0x0

    .line 1640
    iput-boolean v0, p0, Lru/supportagent/OverlayService;->aiListening:Z

    .line 1641
    invoke-direct {p0}, Lru/supportagent/OverlayService;->updateAiControls()V

    return-void
.end method

.method private topicCard(Lru/supportagent/Topic;)Landroid/view/View;
    .locals 12

    .line 1786
    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v7

    const/high16 v0, 0x42900000    # 72.0f

    .line 1787
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setMinimumHeight(I)V

    .line 1788
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1789
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1790
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 1791
    iget-object v0, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :cond_0

    const/high16 v1, 0x40400000    # 3.0f

    goto :goto_0

    :cond_0
    const/high16 v1, 0x40a00000    # 5.0f

    :goto_0
    invoke-static {v0, v1, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    const/16 v2, 0x17

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    move-object v0, p0

    .line 1792
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1793
    iget-object v0, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    const v1, 0x41333333    # 11.2f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v2

    const/4 v9, 0x1

    invoke-static {p0, v0, v1, v2, v9}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    const/4 v1, 0x2

    .line 1794
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1795
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v1, 0x0

    const v2, 0x3f733333    # 0.95f

    .line 1796
    invoke-virtual {v0, v1, v2}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 1797
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v10, 0x0

    invoke-direct {v1, v10, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-static {p0, v0}, Lru/supportagent/TopicPin;->isPinned(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :tc_chevron

    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v0, 0x7f070083

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v0, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v0

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setColorFilter(I)V

    sget-object v0, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    goto :tc_trailing

    :tc_chevron
    const/high16 v0, 0x41a80000    # 21.0f

    .line 1798
    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v0

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const-string v2, "\u203a"

    invoke-static {p0, v2, v0, v1, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v11

    const/16 v0, 0x11

    .line 1799
    invoke-virtual {v11, v0}, Landroid/widget/TextView;->setGravity(I)V

    :tc_trailing
    const/16 v1, 0x10

    const/16 v2, 0x18

    const/4 v3, 0x2

    const/4 v5, 0x0

    move-object v0, p0

    .line 1800
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v8, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v6, 0x3

    move-object v0, p0

    .line 1801
    invoke-direct/range {v0 .. v6}, Lru/supportagent/OverlayService;->olp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1802
    iget-object v0, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object v1, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lru/supportagent/TemplateRepository;->countForTopic(Ljava/lang/String;)I

    move-result v0

    .line 1803
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const v3, 0x410ccccd    # 8.8f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v3

    iget-object v4, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v4

    invoke-static {p0, v1, v3, v4, v10}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 1804
    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 1805
    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 1806
    invoke-virtual {v7, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1807
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "\u0422\u0435\u043c\u0430: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, ", "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 1808
    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setClickable(Z)V

    .line 1809
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda4;

    invoke-direct {v0, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda4;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v0, Lru/supportagent/TopicPinLong;

    invoke-direct {v0, p0, p1}, Lru/supportagent/TopicPinLong;-><init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V

    invoke-virtual {v7, v0}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    return-object v7
.end method

.method private trimAiMessages()V
    .locals 2

    .line 1320
    :goto_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMessages:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/16 v1, 0xa

    if-le v0, v1, :cond_0

    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMessages:Ljava/util/List;

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    return-void
.end method

.method private updateAiControls()V
    .locals 4

    .line 1334
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiStatus:Landroid/widget/TextView;

    if-eqz v0, :cond_3

    .line 1335
    iget-boolean v1, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    if-eqz v1, :cond_0

    const-string v1, "AGENT \u041f\u0415\u0427\u0410\u0422\u0410\u0415\u0422\u2026"

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lru/supportagent/OverlayService;->aiLastError:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v1, "AGENT AI \u00b7 \u0413\u041e\u0422\u041e\u0412"

    goto :goto_0

    :cond_1
    const-string v1, "AGENT AI \u00b7 \u041f\u041e\u0412\u0422\u041e\u0420\u0418\u0422\u042c"

    :goto_0
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1337
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiStatus:Landroid/widget/TextView;

    iget-object v1, p0, Lru/supportagent/OverlayService;->aiLastError:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v1

    goto :goto_1

    :cond_2
    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1339
    :cond_3
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiSendButton:Landroid/widget/ImageView;

    const v1, 0x3ef5c28f    # 0.48f

    const/high16 v2, 0x3f800000    # 1.0f

    if-eqz v0, :cond_5

    .line 1340
    iget-boolean v3, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    xor-int/lit8 v3, v3, 0x1

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setEnabled(Z)V

    .line 1341
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiSendButton:Landroid/widget/ImageView;

    iget-boolean v3, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    if-eqz v3, :cond_4

    move v3, v1

    goto :goto_2

    :cond_4
    move v3, v2

    :goto_2
    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setAlpha(F)V

    .line 1343
    :cond_5
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMicButton:Landroid/widget/ImageView;

    if-eqz v0, :cond_8

    .line 1344
    iget-boolean v3, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    xor-int/lit8 v3, v3, 0x1

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setEnabled(Z)V

    .line 1345
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMicButton:Landroid/widget/ImageView;

    iget-boolean v3, p0, Lru/supportagent/OverlayService;->aiRequestInFlight:Z

    if-eqz v3, :cond_6

    goto :goto_3

    :cond_6
    move v1, v2

    :goto_3
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setAlpha(F)V

    .line 1346
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMicButton:Landroid/widget/ImageView;

    iget-boolean v1, p0, Lru/supportagent/OverlayService;->aiListening:Z

    if-eqz v1, :cond_7

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    goto :goto_4

    :cond_7
    const/4 v1, -0x1

    :goto_4
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setColorFilter(I)V

    :cond_8
    return-void
.end method


# virtual methods
.method synthetic lambda$aiMessageCard$24$ru-supportagent-OverlayService(Landroid/widget/TextView;Landroid/view/View;)V
    .locals 0

    .line 1246
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->copySelectedAiText(Landroid/widget/TextView;)V

    return-void
.end method

.method synthetic lambda$aiMessageCard$25$ru-supportagent-OverlayService(Landroid/widget/TextView;Landroid/view/View;)V
    .locals 0

    .line 1250
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showSelectedAiReply(Landroid/widget/TextView;)V

    return-void
.end method

.method synthetic lambda$aiSetupInputRow$22$ru-supportagent-OverlayService(Landroid/widget/EditText;Landroid/view/View;)V
    .locals 1

    return-void
.end method

.method synthetic lambda$answerCard$42$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 2001
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showAnswerConfirmation(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$appearanceCard$50$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 2218
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageThemes()V

    return-void
.end method

.method synthetic lambda$appearanceCard$51$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 2219
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageThemes()V

    return-void
.end method

.method synthetic lambda$focusInput$7$ru-supportagent-OverlayService(Landroid/widget/EditText;)V
    .locals 2

    .line 868
    invoke-virtual {p1}, Landroid/widget/EditText;->requestFocus()Z

    const-string v0, "input_method"

    .line 869
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    const/4 v1, 0x1

    .line 870
    invoke-virtual {v0, p1, v1}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    return-void
.end method

.method synthetic lambda$input$6$ru-supportagent-OverlayService(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p3, 0x6

    if-eq p2, p3, :cond_0

    const/4 p1, 0x0

    return p1

    .line 855
    :cond_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->hideKeyboard()V

    .line 856
    invoke-virtual {p1}, Landroid/widget/TextView;->clearFocus()V

    const/4 p1, 0x1

    return p1
.end method

.method synthetic lambda$manageAnswerCard$58$ru-supportagent-OverlayService(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 2378
    invoke-direct {p0, p1, p2}, Lru/supportagent/OverlayService;->showAnswerEditor(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$manageTopicCard$55$ru-supportagent-OverlayService(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    .line 2324
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showManageTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$manageTopicCard$56$ru-supportagent-OverlayService(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    .line 2328
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showTopicEditor(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$renderAiMessages$23$ru-supportagent-OverlayService()V
    .locals 2

    .line 1206
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiMessageScroll:Landroid/widget/ScrollView;

    const/16 v1, 0x82

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->fullScroll(I)Z

    return-void
.end method

.method synthetic lambda$renderSectionChips$37$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Landroid/view/View;)V
    .locals 9

    const-string v8, "__sections__"

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    move-object/from16 v7, p7

    .line 1861
    invoke-direct/range {v0 .. v8}, Lru/supportagent/OverlayService;->selectTopicSection(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$renderSectionChips$38$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Landroid/view/View;)V
    .locals 9

    const-string v8, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    move-object/from16 v7, p7

    .line 1869
    invoke-direct/range {v0 .. v8}, Lru/supportagent/OverlayService;->selectTopicSection(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$renderSectionChips$39$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1875
    invoke-direct/range {p0 .. p8}, Lru/supportagent/OverlayService;->selectTopicSection(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$renderSectionOverview$41$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1933
    invoke-direct/range {p0 .. p8}, Lru/supportagent/OverlayService;->selectTopicSection(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/util/List;Ljava/util/List;[Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/ScrollView;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$restoreScroll$0$ru-supportagent-OverlayService(I)V
    .locals 2

    .line 543
    iget-object v0, p0, Lru/supportagent/OverlayService;->activeScroll:Landroid/widget/ScrollView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/widget/ScrollView;->scrollTo(II)V

    return-void
.end method

.method synthetic lambda$scheduleSearchRender$65$ru-supportagent-OverlayService(Lru/supportagent/OverlayService$SearchRenderer;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x0

    .line 2521
    iput-object v0, p0, Lru/supportagent/OverlayService;->pendingSearchRender:Ljava/lang/Runnable;

    .line 2522
    invoke-interface {p1, p2}, Lru/supportagent/OverlayService$SearchRenderer;->render(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$searchResultCard$48$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 2168
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showAnswerConfirmation(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$sendAiQuestion$26$ru-supportagent-OverlayService(JLjava/lang/Object;Ljava/lang/String;)V
    .locals 1

    return-void
.end method

.method synthetic lambda$sendAiQuestion$27$ru-supportagent-OverlayService(Ljava/lang/Object;Ljava/util/List;J)V
    .locals 1

    return-void
.end method

.method synthetic lambda$shell$1$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 584
    invoke-static {p0}, Lru/supportagent/Tutorial;->open(Landroid/content/Context;)V

    return-void
.end method

.method synthetic lambda$shell$2$ru-supportagent-OverlayService(Landroid/widget/ImageView;Landroid/view/View;)V
    .locals 0

    .line 594
    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsDraggable()Z

    move-result p2

    xor-int/lit8 p2, p2, 0x1

    .line 595
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->setPanelDraggable(Z)V

    .line 596
    invoke-direct {p0, p1, p2}, Lru/supportagent/OverlayService;->applyPanelLockVisual(Landroid/widget/ImageView;Z)V

    if-eqz p2, :cond_0

    const-string p1, "\u041f\u0430\u043d\u0435\u043b\u044c \u0440\u0430\u0437\u0431\u043b\u043e\u043a\u0438\u0440\u043e\u0432\u0430\u043d\u0430 \u2014 \u0442\u044f\u043d\u0438\u0442\u0435 \u0437\u0430 \u0432\u0435\u0440\u0445\u043d\u044e\u044e \u0447\u0430\u0441\u0442\u044c \u0434\u043e \u0437\u0430\u043c\u043a\u0430"

    goto :goto_0

    :cond_0
    const-string p1, "\u041f\u0430\u043d\u0435\u043b\u044c \u0437\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u0430"

    :goto_0
    const/4 p2, 0x0

    .line 597
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method synthetic lambda$shell$3$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 603
    invoke-static {p0}, Lru/supportagent/SettingsMenu;->show(Landroid/content/Context;)V

    return-void
.end method

.method synthetic lambda$shell$4$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 606
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closePanel()V

    return-void
.end method

.method synthetic lambda$showAiChat$12$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 993
    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method synthetic lambda$showAiChat$13$ru-supportagent-OverlayService(Z)V
    .locals 0

    .line 1010
    invoke-direct {p0}, Lru/supportagent/OverlayService;->clearAiConversation()V

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    .line 1011
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    :cond_0
    return-void
.end method

.method synthetic lambda$showAiChat$14$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 3

    .line 1008
    invoke-direct {p0}, Lru/supportagent/OverlayService;->panelIsFocusable()Z

    move-result p1

    .line 1009
    new-instance v0, Lru/supportagent/OverlayService$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0, p1}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda6;-><init>(Lru/supportagent/OverlayService;Z)V

    const-string p1, "\u041e\u0427\u0418\u0421\u0422\u0418\u0422\u042c \u0427\u0410\u0422?"

    const-string v1, "\u0418\u0441\u0442\u043e\u0440\u0438\u044f \u044d\u0442\u043e\u0433\u043e AGENT AI \u0431\u0443\u0434\u0435\u0442 \u0443\u0434\u0430\u043b\u0435\u043d\u0430 \u0442\u043e\u043b\u044c\u043a\u043e \u0441 \u044d\u043a\u0440\u0430\u043d\u0430."

    const-string v2, "\u041e\u0427\u0418\u0421\u0422\u0418\u0422\u042c"

    invoke-direct {p0, p1, v1, v2, v0}, Lru/supportagent/OverlayService;->showDecision(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    return-void
.end method

.method synthetic lambda$showAiChat$15$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1016
    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method synthetic lambda$showAiChat$16$ru-supportagent-OverlayService(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p1, 0x6

    if-eq p2, p1, :cond_0

    const/4 p1, 0x0

    return p1

    .line 1032
    :cond_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->sendAiQuestion()V

    const/4 p1, 0x1

    return p1
.end method

.method synthetic lambda$showAiChat$17$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1037
    invoke-direct {p0}, Lru/supportagent/OverlayService;->requestVoiceInput()V

    return-void
.end method

.method synthetic lambda$showAiChat$18$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1040
    invoke-direct {p0}, Lru/supportagent/OverlayService;->sendAiQuestion()V

    return-void
.end method

.method synthetic lambda$showAiReplyConfirmation$28$ru-supportagent-OverlayService(ZLandroid/view/View;)V
    .locals 0

    .line 1462
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    .line 1463
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    :cond_0
    return-void
.end method

.method synthetic lambda$showAiReplyConfirmation$29$ru-supportagent-OverlayService(Ljava/lang/String;Landroid/view/View;)V
    .locals 0

    .line 1467
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->deliverAiReply(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$showAiSetup$19$ru-supportagent-OverlayService(Landroid/widget/EditText;Landroid/view/View;)V
    .locals 1

    return-void
.end method

.method synthetic lambda$showAiSetup$20$ru-supportagent-OverlayService()V
    .locals 1

    return-void
.end method

.method synthetic lambda$showAiSetup$21$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 3

    .line 1092
    new-instance p1, Lru/supportagent/OverlayService$$ExternalSyntheticLambda8;

    invoke-direct {p1, p0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda8;-><init>(Lru/supportagent/OverlayService;)V

    const-string v0, "\u0421\u0411\u0420\u041e\u0421\u0418\u0422\u042c \u041a\u041b\u042e\u0427 GEMINI?"

    const-string v1, "\u0412\u0430\u0448 \u043b\u0438\u0447\u043d\u044b\u0439 \u043a\u043b\u044e\u0447 \u0431\u0443\u0434\u0435\u0442 \u0443\u0434\u0430\u043b\u0451\u043d. AGENT AI \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442 \u0440\u0430\u0431\u043e\u0442\u0430\u0442\u044c \u043d\u0430 \u0441\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u043e\u043c \u043a\u043b\u044e\u0447\u0435."

    const-string v2, "\u0421\u0411\u0420\u041e\u0421\u0418\u0422\u042c"

    invoke-direct {p0, v0, v1, v2, p1}, Lru/supportagent/OverlayService;->showDecision(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    return-void
.end method

.method synthetic lambda$showAnswerConfirmation$45$ru-supportagent-OverlayService(ZLandroid/view/View;)V
    .locals 0

    .line 2079
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    .line 2080
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    :cond_0
    return-void
.end method

.method synthetic lambda$showAnswerConfirmation$46$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 2084
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->deliverAnswer(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$showAnswerEditor$61$ru-supportagent-OverlayService(Lru/supportagent/Topic;)V
    .locals 0

    .line 2418
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showManageTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showAnswerEditor$62$ru-supportagent-OverlayService(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 2461
    invoke-direct {p0, p1, p2}, Lru/supportagent/OverlayService;->showDeleteAnswerConfirmation(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$showAnswerEditor$63$ru-supportagent-OverlayService(Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .locals 1

    .line 2465
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lru/supportagent/ReplyComposer;->length(Ljava/lang/String;)I

    move-result v0

    .line 2466
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lru/supportagent/ReplyComposer;->isValid(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    .line 2467
    :goto_0
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p2

    const-string v0, " / 120"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    if-eqz p1, :cond_1

    const-string v0, ""

    goto :goto_1

    :cond_1
    const-string v0, " \u2014 \u043f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0442\u0435\u043a\u0441\u0442"

    :goto_1
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2468
    iget-object p2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    if-eqz p1, :cond_2

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result p2

    goto :goto_2

    :cond_2
    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    :goto_2
    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2469
    invoke-virtual {p4, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    if-eqz p1, :cond_3

    const/high16 p1, 0x3f800000    # 1.0f

    goto :goto_3

    :cond_3
    const p1, 0x3ee66666    # 0.45f

    .line 2470
    :goto_3
    invoke-virtual {p4, p1}, Landroid/widget/TextView;->setAlpha(F)V

    return-void
.end method

.method synthetic lambda$showAnswerEditor$64$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/view/View;)V
    .locals 6

    .line 2475
    iget-object v0, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    const-string p6, ""

    if-nez p1, :cond_0

    move-object v1, p6

    goto :goto_0

    :cond_0
    iget-object p1, p1, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    move-object v1, p1

    :goto_0
    iget-object v2, p2, Lru/supportagent/Topic;->id:Ljava/lang/String;

    .line 2476
    invoke-virtual {p3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    if-nez p5, :cond_1

    move-object v5, p6

    goto :goto_1

    .line 2477
    :cond_1
    invoke-virtual {p5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    move-object v5, p1

    .line 2475
    :goto_1
    invoke-virtual/range {v0 .. v5}, Lru/supportagent/TemplateRepository;->saveTemplate(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lru/supportagent/AnswerTemplate;

    move-result-object p1

    if-nez p1, :cond_2

    const-string p1, "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0438 \u0434\u043b\u0438\u043d\u0443 \u043e\u0442\u0432\u0435\u0442\u0430"

    const/4 p2, 0x0

    .line 2479
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void

    .line 2482
    :cond_2
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->showManageTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showDecision$68$ru-supportagent-OverlayService(ZLandroid/view/View;)V
    .locals 0

    .line 2566
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    .line 2567
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->setPanelFocusable(Z)V

    :cond_0
    return-void
.end method

.method synthetic lambda$showDecision$69$ru-supportagent-OverlayService(Ljava/lang/Runnable;Landroid/view/View;)V
    .locals 0

    .line 2571
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method synthetic lambda$showDeleteAnswerConfirmation$67$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Lru/supportagent/Topic;)V
    .locals 1

    .line 2545
    iget-object v0, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    iget-object p1, p1, Lru/supportagent/AnswerTemplate;->id:Ljava/lang/String;

    invoke-virtual {v0, p1}, Lru/supportagent/TemplateRepository;->deleteTemplate(Ljava/lang/String;)V

    .line 2546
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->showManageTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showDeleteTopicConfirmation$66$ru-supportagent-OverlayService(Lru/supportagent/Topic;)V
    .locals 1

    .line 2538
    iget-object v0, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {v0, p1}, Lru/supportagent/TemplateRepository;->deleteTopic(Lru/supportagent/Topic;)V

    .line 2539
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageTopics()V

    return-void
.end method

.method synthetic lambda$showHome$10$ru-supportagent-OverlayService(Ljava/util/List;Landroid/view/View;)V
    .locals 0

    .line 933
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showQuickOverflow(Ljava/util/List;)V

    return-void
.end method

.method synthetic lambda$showHome$11$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 945
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showAnswerConfirmation(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$showHome$8$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 896
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showSearch()V

    return-void
.end method

.method synthetic lambda$showHome$9$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 902
    invoke-static {p0}, Lru/supportagent/AgentAiPage;->show(Landroid/content/Context;)V

    return-void
.end method

.method synthetic lambda$showManageTemplates$57$ru-supportagent-OverlayService(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    const/4 p2, 0x0

    .line 2343
    invoke-direct {p0, p1, p2}, Lru/supportagent/OverlayService;->showAnswerEditor(Lru/supportagent/Topic;Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$showManageThemes$52$ru-supportagent-OverlayService()V
    .locals 0

    .line 2229
    invoke-direct {p0}, Lru/supportagent/OverlayService;->repaintBubble()V

    .line 2230
    invoke-static {p0}, Lru/supportagent/SettingsMenu;->show(Landroid/content/Context;)V

    return-void
.end method

.method synthetic lambda$showManageThemes$53$ru-supportagent-OverlayService([ILandroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;I)V
    .locals 8

    const/4 v0, 0x0

    .line 2270
    aput p7, p1, v0

    .line 2271
    invoke-static {p7}, Lru/supportagent/AgentPalette;->wheel(I)Lru/supportagent/AgentPalette;

    move-result-object p1

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move-object v7, p6

    .line 2272
    invoke-direct/range {v1 .. v7}, Lru/supportagent/OverlayService;->applyWheelPreview(Lru/supportagent/AgentPalette;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;)V

    .line 2274
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->repaintBubble(Lru/supportagent/AgentPalette;)V

    return-void
.end method

.method synthetic lambda$showManageThemes$54$ru-supportagent-OverlayService(Lru/supportagent/PaletteRepository;[ILandroid/view/View;)V
    .locals 0

    const/4 p3, 0x0

    .line 2279
    aget p2, p2, p3

    invoke-virtual {p1, p2}, Lru/supportagent/PaletteRepository;->saveWheelColor(I)V

    .line 2280
    invoke-virtual {p1}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    .line 2281
    invoke-direct {p0}, Lru/supportagent/OverlayService;->repaintBubble()V

    const-string p1, "\u041e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e"

    .line 2282
    invoke-static {p0, p1, p3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 2283
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageThemes()V

    return-void
.end method

.method synthetic lambda$showManageTopics$49$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    const/4 p1, 0x0

    .line 2181
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showTopicEditor(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showQuickOverflow$30$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1665
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    return-void
.end method

.method synthetic lambda$showQuickOverflow$31$ru-supportagent-OverlayService(Lru/supportagent/AnswerTemplate;Landroid/view/View;)V
    .locals 0

    .line 1687
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showAnswerConfirmation(Lru/supportagent/AnswerTemplate;)V

    return-void
.end method

.method synthetic lambda$showQuickOverflow$32$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1697
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 1698
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageTopics()V

    return-void
.end method

.method synthetic lambda$showSearch$47$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 0

    .line 2118
    invoke-direct {p0, p1, p2}, Lru/supportagent/OverlayService;->renderSearchResults(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$showStatistics$33$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1720
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    return-void
.end method

.method synthetic lambda$showStatistics$34$ru-supportagent-OverlayService(Landroid/view/View;)V
    .locals 0

    .line 1742
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    return-void
.end method

.method synthetic lambda$showTemplates$36$ru-supportagent-OverlayService(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    .line 1822
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showTopicSearch(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showTopicEditor$59$ru-supportagent-OverlayService(Landroid/widget/EditText;Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 1

    .line 2398
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p3

    .line 2399
    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p2, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435"

    invoke-virtual {p1, p2}, Landroid/widget/EditText;->setError(Ljava/lang/CharSequence;)V

    return-void

    .line 2400
    :cond_0
    iget-object p1, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    if-nez p2, :cond_1

    invoke-virtual {p1, p3}, Lru/supportagent/TemplateRepository;->addTopic(Ljava/lang/String;)Lru/supportagent/Topic;

    goto :goto_0

    :cond_1
    invoke-virtual {p1, p2, p3}, Lru/supportagent/TemplateRepository;->updateTopic(Lru/supportagent/Topic;Ljava/lang/String;)V

    .line 2401
    :goto_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->showManageTopics()V

    return-void
.end method

.method synthetic lambda$showTopicEditor$60$ru-supportagent-OverlayService(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    .line 2407
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showDeleteTopicConfirmation(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showTopicSearch$43$ru-supportagent-OverlayService(Lru/supportagent/Topic;)V
    .locals 0

    .line 2011
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method synthetic lambda$showTopicSearch$44$ru-supportagent-OverlayService(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/lang/String;)V
    .locals 0

    .line 2018
    invoke-direct {p0, p1, p2, p3}, Lru/supportagent/OverlayService;->renderTopicSearchResults(Landroid/widget/LinearLayout;Lru/supportagent/Topic;Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$topicCard$35$ru-supportagent-OverlayService(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 0

    .line 1809
    invoke-direct {p0, p1}, Lru/supportagent/OverlayService;->showTemplates(Lru/supportagent/Topic;)V

    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    .line 179
    invoke-super {p0, p1}, Landroid/app/Service;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 180
    iget-object p1, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    if-eqz p1, :cond_0

    iget-object p1, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz p1, :cond_0

    .line 181
    invoke-direct {p0}, Lru/supportagent/OverlayService;->bubbleSize()I

    move-result p1

    .line 182
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 183
    iget-object v0, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 184
    invoke-direct {p0}, Lru/supportagent/OverlayService;->clampBubble()V

    .line 185
    :try_start_0
    iget-object p1, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    iget-object v0, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    iget-object v1, p0, Lru/supportagent/OverlayService;->bubbleParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {p1, v0, v1}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 187
    :catch_0
    :cond_0
    iget-object p1, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz p1, :cond_1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showHome()V

    :cond_1
    return-void
.end method

.method public onCreate()V
    .locals 2

    invoke-static {p0}, Lru/supportagent/GpsShift;->init(Landroid/content/Context;)V

    .line 135
    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const-string v0, "window"

    .line 136
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    iput-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    .line 137
    invoke-direct {p0}, Lru/supportagent/OverlayService;->ensureClosedLockDefault()V

    .line 138
    new-instance v0, Lru/supportagent/TemplateRepository;

    invoke-direct {v0, p0}, Lru/supportagent/TemplateRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    .line 139
    new-instance v0, Lru/supportagent/StatisticsRepository;

    invoke-direct {v0, p0}, Lru/supportagent/StatisticsRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lru/supportagent/OverlayService;->statistics:Lru/supportagent/StatisticsRepository;

    .line 140
    new-instance v0, Lru/supportagent/PaletteRepository;

    invoke-direct {v0, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object v0

    iput-object v0, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    .line 142
    :try_start_0
    const/4 v0, 0x0

    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSettings:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    .line 146
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSettings:Ljava/lang/Object;

    const-string v0, ""

    .line 147
    iput-object v0, p0, Lru/supportagent/OverlayService;->aiSecureStorageError:Ljava/lang/String;

    .line 149
    :goto_0
    invoke-direct {p0}, Lru/supportagent/OverlayService;->createChannel()V

    const/16 v0, 0x264

    .line 150
    invoke-direct {p0}, Lru/supportagent/OverlayService;->notification()Landroid/app/Notification;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lru/supportagent/OverlayService;->startForeground(ILandroid/app/Notification;)V

    const/4 v0, 0x1

    .line 151
    sput-boolean v0, Lru/supportagent/OverlayService;->running:Z

    return-void
.end method

.method public onDestroy()V
    .locals 4

    .line 195
    invoke-direct {p0}, Lru/supportagent/OverlayService;->cancelPendingSearchRender()V

    .line 196
    iget-wide v0, p0, Lru/supportagent/OverlayService;->aiRequestGeneration:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lru/supportagent/OverlayService;->aiRequestGeneration:J

    .line 197
    iget-object v0, p0, Lru/supportagent/OverlayService;->aiExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 198
    invoke-direct {p0}, Lru/supportagent/OverlayService;->destroySpeechRecognizer()V

    .line 199
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 200
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closePanel()V

    .line 201
    invoke-direct {p0}, Lru/supportagent/OverlayService;->removeBubble()V

    const/4 v0, 0x0

    .line 202
    sput-boolean v0, Lru/supportagent/OverlayService;->running:Z

    .line 203
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1

    if-nez p1, :cond_0

    const-string p2, "ru.supportagent.SHOW"

    goto :goto_0

    .line 156
    :cond_0
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    :goto_0
    const-string p3, "ru.supportagent.MICROPHONE_PERMISSION_RESULT"

    .line 157
    invoke-virtual {p3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v0, 0x1

    if-eqz p3, :cond_2

    const/4 p2, 0x0

    if-eqz p1, :cond_1

    const-string p3, "microphone_granted"

    .line 158
    invoke-virtual {p1, p3, p2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_1

    move p2, v0

    .line 159
    :cond_1
    invoke-direct {p0, p2}, Lru/supportagent/OverlayService;->onMicrophonePermissionResult(Z)V

    return v0

    :cond_2
    const-string p1, "ru.supportagent.STOP"

    .line 162
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    .line 163
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    .line 164
    invoke-direct {p0}, Lru/supportagent/OverlayService;->closePanel()V

    .line 165
    invoke-direct {p0}, Lru/supportagent/OverlayService;->removeBubble()V

    .line 166
    invoke-virtual {p0, v0}, Lru/supportagent/OverlayService;->stopForeground(Z)V

    .line 167
    invoke-virtual {p0}, Lru/supportagent/OverlayService;->stopSelf()V

    const/4 p1, 0x2

    return p1

    .line 170
    :cond_3
    new-instance p1, Lru/supportagent/PaletteRepository;

    invoke-direct {p1, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    const-string p1, "ru.supportagent.REFRESH"

    .line 171
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_4

    iget-object p3, p0, Lru/supportagent/OverlayService;->repository:Lru/supportagent/TemplateRepository;

    invoke-virtual {p3}, Lru/supportagent/TemplateRepository;->reload()V

    .line 172
    :cond_4
    iget-object p3, p0, Lru/supportagent/OverlayService;->bubble:Landroid/view/View;

    if-nez p3, :cond_5

    invoke-direct {p0}, Lru/supportagent/OverlayService;->addBubble()V

    goto :goto_1

    :cond_5
    invoke-direct {p0}, Lru/supportagent/OverlayService;->repaintBubble()V

    .line 173
    :goto_1
    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_6

    iget-object p1, p0, Lru/supportagent/OverlayService;->panel:Landroid/view/View;

    if-eqz p1, :cond_6

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showHome()V

    :cond_6
    return v0
.end method

.method public openGpsShiftMenu()V
    .locals 0

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showGpsShiftMenu()V

    return-void
.end method

.method public pickGpsShift(I)V
    .locals 1

    invoke-static {p0, p1}, Lru/supportagent/GpsShift;->set(Landroid/content/Context;I)V

    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    invoke-virtual {p0}, Lru/supportagent/OverlayService;->refreshGpsShift()V

    return-void
.end method

.method private showGpsShiftMenu()V
    .locals 10

    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compactCard()Landroid/widget/LinearLayout;

    move-result-object v0

    const/high16 v1, 0x41400000    # 12.0f

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v2

    const/high16 v3, 0x41200000    # 10.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    const/high16 v4, 0x41300000    # 11.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    invoke-virtual {v0, v2, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    iget-object v1, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    iget-object v2, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v2

    const/high16 v3, 0x41300000    # 11.0f

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v4

    if-eqz v4, :gsm_radius

    goto :gsm_bg

    :gsm_radius
    const/high16 v3, 0x41700000    # 15.0f

    :gsm_bg
    invoke-static {v1, v2, v3, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v3, 0x7f070082

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setColorFilter(I)V

    sget-object v3, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v3, 0x41800000    # 16.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v2, 0x41480000    # 12.5f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v3

    const-string v4, "\u0421\u0414\u0412\u0418\u0413 GPS"

    const/4 v5, 0x1

    invoke-static {p0, v4, v2, v3, v5}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x0

    const/4 v5, -0x2

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v3, v5, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v5, 0x40a00000    # 5.0f

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    const/4 v6, 0x0

    invoke-virtual {v3, v5, v6, v6, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const v3, 0x7f07005e

    const/4 v4, -0x1

    const/16 v5, 0x8

    invoke-direct {p0, v3, v2, v4, v5}, Lru/supportagent/OverlayService;->iconButton(ILjava/lang/String;II)Landroid/widget/ImageView;

    move-result-object v2

    new-instance v3, Lru/supportagent/OverlayService$$ExternalSyntheticLambda9;

    invoke-direct {v3, p0}, Lru/supportagent/OverlayService$$ExternalSyntheticLambda9;-><init>(Lru/supportagent/OverlayService;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/high16 v3, 0x41d80000    # 27.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40800000    # 4.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v4, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v2, 0x41133333    # 9.2f

    invoke-direct {p0, v2}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v2

    iget-object v3, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v3

    const-string v4, "\u0421\u043a\u043e\u043b\u044c\u043a\u043e \u0441\u043e\u0431\u044b\u0442\u0438\u0439 \u0434\u043e\u0431\u0430\u0432\u0438\u043b\u0438 \u0432 GPS? \u041f\u0435\u0440\u0432\u0430\u044f \u0446\u0438\u0444\u0440\u0430 \u0432\u043e \u0432\u0441\u0435\u0445 \u043e\u0442\u0432\u0435\u0442\u0430\u0445 \u0441\u0434\u0432\u0438\u043d\u0435\u0442\u0441\u044f."

    const/4 v5, 0x0

    invoke-static {p0, v4, v2, v3, v5}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v4, 0x40e00000    # 7.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v5, v5, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-static {p0}, Lru/supportagent/GpsShift;->get(Landroid/content/Context;)I

    move-result v2

    const/4 v3, 0x0

    :gsm_loop
    const/4 v4, 0x6

    if-ge v3, v4, :gsm_loop_end

    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v5, 0x41400000    # 12.0f

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->compactText(F)F

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v5, 0x40800000    # 4.0f

    invoke-direct {p0, v5}, Lru/supportagent/OverlayService;->od(F)I

    move-result v5

    invoke-virtual {v4, v5, v5, v5, v5}, Landroid/widget/TextView;->setPadding(IIII)V

    if-ne v3, v2, :gsm_off

    iget-object v5, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v5}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v5

    iget-object v6, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v6}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v6

    goto :gsm_colors

    :gsm_off
    iget-object v5, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v5}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v5

    iget-object v6, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v6}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v6

    :gsm_colors
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v6, p0, Lru/supportagent/OverlayService;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v6}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v6

    const/high16 v7, 0x41100000    # 9.0f

    invoke-static {v5, v6, v7, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v5, Lru/supportagent/GpsShiftPick;

    invoke-direct {v5, p0, v3}, Lru/supportagent/GpsShiftPick;-><init>(Lru/supportagent/OverlayService;I)V

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x0

    const/4 v7, -0x2

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v5, v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v6, 0x40400000    # 3.0f

    invoke-direct {p0, v6}, Lru/supportagent/OverlayService;->od(F)I

    move-result v6

    const/4 v7, 0x0

    invoke-virtual {v5, v6, v7, v6, v7}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v1, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v3, v3, 0x1

    goto :gsm_loop

    :gsm_loop_end
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x41100000    # 9.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v4, v4, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-direct {p0}, Lru/supportagent/OverlayService;->compact()Z

    move-result v1

    if-eqz v1, :gsm_wide

    const/high16 v1, 0x43480000    # 200.0f

    goto :gsm_w

    :gsm_wide
    const/high16 v1, 0x43580000    # 216.0f

    :gsm_w
    invoke-direct {p0, v1}, Lru/supportagent/OverlayService;->od(F)I

    move-result v1

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenWidth()I

    move-result v2

    const/high16 v3, 0x41b00000    # 22.0f

    invoke-direct {p0, v3}, Lru/supportagent/OverlayService;->od(F)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/high16 v2, 0x40000000    # EXACTLY

    invoke-static {v1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v3

    const/high16 v4, 0x41400000    # 12.0f

    invoke-direct {p0, v4}, Lru/supportagent/OverlayService;->od(F)I

    move-result v4

    sub-int/2addr v3, v4

    const/high16 v4, -0x80000000    # AT_MOST

    invoke-static {v3, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/view/View;->measure(II)V

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v2

    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/OverlayService;->showModal(Landroid/view/View;II)V

    const/4 v1, 0x1

    iput-boolean v1, p0, Lru/supportagent/OverlayService;->quickModal:Z

    iput-boolean v1, p0, Lru/supportagent/OverlayService;->shiftModal:Z

    invoke-direct {p0}, Lru/supportagent/OverlayService;->positionShiftMenu()V

    return-void
.end method

.method private positionShiftMenu()V
    .locals 10

    iget-object v0, p0, Lru/supportagent/OverlayService;->quickAnchor:Landroid/view/View;

    if-eqz v0, :ps_exit

    iget-object v1, p0, Lru/supportagent/OverlayService;->modal:Landroid/view/View;

    if-eqz v1, :ps_exit

    iget-object v2, p0, Lru/supportagent/OverlayService;->modalParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v2, :ps_exit

    const/4 v3, 0x2

    new-array v3, v3, [I

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v4, 0x0

    aget v4, v3, v4

    const/4 v5, 0x1

    aget v5, v3, v5

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    add-int/2addr v5, v0

    const/high16 v0, 0x40c00000    # 6.0f

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v0

    add-int/2addr v5, v0

    sub-int/2addr v4, v0

    iget v6, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    iget v7, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    const/high16 v0, 0x41000000    # 8.0f

    invoke-direct {p0, v0}, Lru/supportagent/OverlayService;->od(F)I

    move-result v8

    iget-object v9, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    if-eqz v9, :ps_screen

    iget v0, v9, Landroid/view/WindowManager$LayoutParams;->x:I

    iget v3, v9, Landroid/view/WindowManager$LayoutParams;->y:I

    iget v9, v9, Landroid/view/WindowManager$LayoutParams;->width:I

    add-int v9, v0, v9

    sub-int/2addr v9, v6

    sub-int/2addr v9, v8

    add-int/2addr v0, v8

    if-ge v4, v0, :ps_x_left_ok

    move v4, v0

    :ps_x_left_ok
    if-le v4, v9, :ps_x_right_ok

    move v4, v9

    :ps_x_right_ok
    iget-object v9, p0, Lru/supportagent/OverlayService;->panelParams:Landroid/view/WindowManager$LayoutParams;

    iget v9, v9, Landroid/view/WindowManager$LayoutParams;->height:I

    add-int v9, v3, v9

    sub-int/2addr v9, v7

    sub-int/2addr v9, v8

    add-int/2addr v3, v8

    if-ge v5, v3, :ps_y_top_ok

    move v5, v3

    :ps_y_top_ok
    if-le v5, v9, :ps_y_bottom_ok

    move v5, v9

    :ps_y_bottom_ok
    goto :ps_apply

    :ps_screen
    if-ge v4, v8, :ps_screen_x_ok

    move v4, v8

    :ps_screen_x_ok
    invoke-direct {p0}, Lru/supportagent/OverlayService;->screenHeight()I

    move-result v0

    sub-int/2addr v0, v7

    sub-int/2addr v0, v8

    if-le v5, v0, :ps_screen_y_ok

    move v5, v0

    :ps_screen_y_ok
    if-gez v5, :ps_apply

    const/4 v5, 0x0

    :ps_apply
    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v5, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    :try_start_0
    iget-object v0, p0, Lru/supportagent/OverlayService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v0, v1, v2}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :ps_exit

    :ps_exit
    return-void
.end method

.method public openTopicPinMenu(Lru/supportagent/Topic;Landroid/view/View;)V
    .locals 5

    if-eqz p1, :otpm_ret

    iput-object p1, p0, Lru/supportagent/OverlayService;->pinTopic:Lru/supportagent/Topic;

    iget-object v0, p1, Lru/supportagent/Topic;->id:Ljava/lang/String;

    iget-object v1, p1, Lru/supportagent/Topic;->name:Ljava/lang/String;

    invoke-static {p0, v0}, Lru/supportagent/TopicPin;->isPinned(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    new-instance v2, Lru/supportagent/TopicPinConfirm;

    invoke-direct {v2, p0}, Lru/supportagent/TopicPinConfirm;-><init>(Lru/supportagent/OverlayService;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u00ab"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v0, :otpm_msg_off

    const-string v4, "\u00bb \u0432\u0435\u0440\u043d\u0451\u0442\u0441\u044f \u043d\u0430 \u043e\u0431\u044b\u0447\u043d\u043e\u0435 \u043c\u0435\u0441\u0442\u043e \u0432 \u0441\u043f\u0438\u0441\u043a\u0435."

    goto :otpm_msg_cat

    :otpm_msg_off
    const-string v4, "\u00bb \u0432\u0441\u0442\u0430\u043d\u0435\u0442 \u043f\u0435\u0440\u0432\u043e\u0439 \u0432\u0432\u0435\u0440\u0445\u0443 \u0441\u043f\u0438\u0441\u043a\u0430. \u0415\u0441\u043b\u0438 \u0437\u0430\u043a\u0440\u0435\u043f\u043b\u0451\u043d\u043d\u044b\u0445 \u0443\u0436\u0435 4 \u2014 \u043f\u043e\u0441\u043b\u0435\u0434\u043d\u044f\u044f \u043e\u0442\u043a\u0440\u0435\u043f\u0438\u0442\u0441\u044f."

    :otpm_msg_cat
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    if-eqz v0, :otpm_title_off

    const-string p1, "\u041e\u0422\u041a\u0420\u0415\u041f\u0418\u0422\u042c \u0422\u0415\u041c\u0423?"

    const-string p2, "\u041e\u0442\u043a\u0440\u0435\u043f\u0438\u0442\u044c"

    goto :otpm_show

    :otpm_title_off
    const-string p1, "\u0417\u0410\u041a\u0420\u0415\u041f\u0418\u0422\u042c \u0422\u0415\u041c\u0423?"

    const-string p2, "\u0417\u0430\u043a\u0440\u0435\u043f\u0438\u0442\u044c"

    :otpm_show
    invoke-direct {p0, p1, v3, p2, v2}, Lru/supportagent/OverlayService;->showDecision(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    :otpm_ret
    return-void
.end method

.method public toggleTopicPin()V
    .locals 2

    iget-object v0, p0, Lru/supportagent/OverlayService;->pinTopic:Lru/supportagent/Topic;

    if-eqz v0, :ttp_ret

    iget-object v1, v0, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-static {p0, v1}, Lru/supportagent/TopicPin;->togglePin(Landroid/content/Context;Ljava/lang/String;)I

    invoke-direct {p0}, Lru/supportagent/OverlayService;->closeModal()V

    invoke-direct {p0}, Lru/supportagent/OverlayService;->showHome()V

    :ttp_ret
    return-void
.end method
