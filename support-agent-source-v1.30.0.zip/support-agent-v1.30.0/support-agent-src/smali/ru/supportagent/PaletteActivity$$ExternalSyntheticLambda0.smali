.class public final synthetic Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/PaletteActivity;

.field public final synthetic f$1:Lru/supportagent/AgentPalette;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/PaletteActivity;Lru/supportagent/AgentPalette;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;->f$0:Lru/supportagent/PaletteActivity;

    iput-object p2, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;->f$1:Lru/supportagent/AgentPalette;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    iget-object v0, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;->f$0:Lru/supportagent/PaletteActivity;

    iget-object v1, p0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;->f$1:Lru/supportagent/AgentPalette;

    invoke-virtual {v0, v1, p1, p2}, Lru/supportagent/PaletteActivity;->lambda$deleteCustomConfirm$6$ru-supportagent-PaletteActivity(Lru/supportagent/AgentPalette;Landroid/content/DialogInterface;I)V

    return-void
.end method
