.class public final Lru/supportagent/PaletteActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "PaletteActivity.java"


# instance fields
.field private palette:Lru/supportagent/AgentPalette;

.field private repository:Lru/supportagent/PaletteRepository;

.field private root:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 20
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method

.method private addSwatch(Landroid/widget/LinearLayout;ILjava/lang/String;)V
    .locals 10

    .line 108
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 109
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 110
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 111
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/high16 v3, 0x40e00000    # 7.0f

    .line 112
    invoke-static {p2, v3, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {v2, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v4, 0x26

    const/16 v5, 0x17

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    move-object v3, p0

    .line 113
    invoke-static/range {v3 .. v9}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p2

    invoke-virtual {v0, v2, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 114
    iget-object p2, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result p2

    const/high16 v2, 0x41080000    # 8.5f

    invoke-static {p0, p3, v2, p2, v1}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    const/16 p3, 0x11

    .line 115
    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setGravity(I)V

    .line 116
    invoke-virtual {v0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v2, 0x2b

    const/4 v3, -0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x9

    move-object v1, p0

    .line 117
    invoke-static/range {v1 .. v7}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p2

    invoke-virtual {p1, v0, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private customPaletteDialog()V
    .locals 11

    .line 121
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 122
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x40800000    # 4.0f

    .line 123
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x40e00000    # 7.0f

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const-string v1, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435"

    const-string v2, "\u041c\u043e\u044f \u043f\u0430\u043b\u0438\u0442\u0440\u0430"

    .line 124
    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/PaletteActivity;->field(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v6

    const-string v1, "\u0424\u043e\u043d #RRGGBB"

    const-string v2, "#0C1220"

    .line 125
    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/PaletteActivity;->field(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v7

    const-string v1, "\u041f\u0430\u043d\u0435\u043b\u044c #RRGGBB"

    const-string v2, "#121A2A"

    .line 126
    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/PaletteActivity;->field(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v8

    const-string v1, "\u041a\u043e\u043d\u0442\u0443\u0440 #RRGGBB"

    const-string v2, "#344361"

    .line 127
    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/PaletteActivity;->field(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v9

    const-string v1, "\u0410\u043a\u0446\u0435\u043d\u0442 #RRGGBB"

    const-string v2, "#FF583E"

    .line 128
    invoke-direct {p0, v0, v1, v2}, Lru/supportagent/PaletteActivity;->field(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v10

    .line 129
    new-instance v1, Landroidx/appcompat/app/AlertDialog$Builder;

    const v2, 0x7f0e00a2

    invoke-direct {v1, p0, v2}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const-string v2, "\u0421\u0432\u043e\u044f \u043f\u0430\u043b\u0438\u0442\u0440\u0430"

    .line 130
    invoke-virtual {v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v1

    .line 131
    invoke-virtual {v1, v0}, Landroidx/appcompat/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v2, 0x0

    .line 132
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u0421\u041e\u0417\u0414\u0410\u0422\u042c"

    .line 133
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 134
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object v0

    .line 135
    new-instance v1, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;

    move-object v3, v1

    move-object v4, p0

    move-object v5, v0

    invoke-direct/range {v3 .. v10}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda5;-><init>(Lru/supportagent/PaletteActivity;Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V

    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 148
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private deleteCustomConfirm(Lru/supportagent/AgentPalette;)V
    .locals 3

    .line 172
    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    const v1, 0x7f0e00a2

    invoke-direct {v0, p0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043f\u0430\u043b\u0438\u0442\u0440\u0443?"

    .line 173
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "\u041f\u0430\u043b\u0438\u0442\u0440\u0430 \u00ab"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p1, Lru/supportagent/AgentPalette;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\u00bb \u0431\u0443\u0434\u0435\u0442 \u0443\u0434\u0430\u043b\u0435\u043d\u0430."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 174
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u041e\u0422\u041c\u0415\u041d\u0410"

    const/4 v2, 0x0

    .line 175
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda0;-><init>(Lru/supportagent/PaletteActivity;Lru/supportagent/AgentPalette;)V

    const-string p1, "\u0423\u0414\u0410\u041b\u0418\u0422\u042c"

    .line 176
    invoke-virtual {v0, p1, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object p1

    .line 181
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog$Builder;->create()Landroidx/appcompat/app/AlertDialog;

    move-result-object p1

    .line 182
    new-instance v0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p1}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda1;-><init>(Lru/supportagent/PaletteActivity;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {p1, v0}, Landroidx/appcompat/app/AlertDialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    .line 183
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->show()V

    return-void
.end method

.method private field(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/EditText;
    .locals 10

    .line 152
    invoke-virtual {p2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const/high16 v1, 0x41280000    # 10.5f

    const/4 v2, 0x1

    invoke-static {p0, p2, v1, v0, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p2

    const v0, 0x3d4ccccd    # 0.05f

    .line 153
    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    move-object v3, p0

    .line 154
    invoke-static/range {v3 .. v9}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 155
    new-instance p2, Landroid/widget/EditText;

    invoke-direct {p2, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 156
    invoke-virtual {p2, v2}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 157
    invoke-virtual {p2, p3}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const/high16 p3, 0x41600000    # 14.0f

    .line 158
    invoke-virtual {p2, p3}, Landroid/widget/EditText;->setTextSize(F)V

    .line 159
    iget-object p3, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p3}, Lru/supportagent/AgentPalette;->textColor()I

    move-result p3

    invoke-virtual {p2, p3}, Landroid/widget/EditText;->setTextColor(I)V

    const/high16 p3, 0x41400000    # 12.0f

    .line 160
    invoke-static {p0, p3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, p3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p3

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {p2, v0, v2, p3, v1}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 161
    iget-object p3, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p3}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result p3

    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v0

    const/high16 v1, 0x41100000    # 9.0f

    invoke-static {p3, v0, v1, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/widget/EditText;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0xb

    move-object v0, p0

    .line 162
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p3

    invoke-virtual {p1, p2, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object p2
.end method

.method private isColor(Landroid/widget/EditText;)Z
    .locals 0

    .line 167
    :try_start_0
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    const/4 p1, 0x0

    return p1
.end method

.method private paletteCard(Lru/supportagent/AgentPalette;Z)Landroid/widget/LinearLayout;
    .locals 10

    .line 84
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 85
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    .line 86
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 87
    iget-object v3, p1, Lru/supportagent/AgentPalette;->name:Ljava/lang/String;

    iget-object v4, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v4}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v4

    const/4 v5, 0x1

    const/high16 v6, 0x41800000    # 16.0f

    invoke-static {p0, v3, v6, v4, v5}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v3

    .line 88
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, 0x0

    invoke-direct {v4, v7, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz p2, :cond_0

    .line 89
    iget-object p2, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->goldColor()I

    move-result p2

    const/16 v3, 0x1f

    invoke-static {p2, v3}, Lru/supportagent/Ui;->withAlpha(II)I

    move-result p2

    iget-object v3, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v3}, Lru/supportagent/AgentPalette;->goldColor()I

    move-result v3

    iget-object v4, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    const-string v5, "\u0410\u041a\u0422\u0418\u0412\u041d\u0410\u042f"

    invoke-static {p0, v5, p2, v3, v4}, Lru/supportagent/Ui;->chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;

    move-result-object p2

    invoke-virtual {v1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 90
    :cond_0
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 91
    new-instance p2, Landroid/widget/LinearLayout;

    invoke-direct {p2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 92
    invoke-virtual {p2, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 93
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    const-string v2, "\u0424\u041e\u041d"

    invoke-direct {p0, p2, v1, v2}, Lru/supportagent/PaletteActivity;->addSwatch(Landroid/widget/LinearLayout;ILjava/lang/String;)V

    .line 94
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    const-string v2, "\u041f\u0410\u041d\u0415\u041b\u042c"

    invoke-direct {p0, p2, v1, v2}, Lru/supportagent/PaletteActivity;->addSwatch(Landroid/widget/LinearLayout;ILjava/lang/String;)V

    .line 95
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result v1

    const-string v2, "\u041a\u041e\u041d\u0422\u0423\u0420"

    invoke-direct {p0, p2, v1, v2}, Lru/supportagent/PaletteActivity;->addSwatch(Landroid/widget/LinearLayout;ILjava/lang/String;)V

    .line 96
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result v1

    const-string v2, "\u0410\u041a\u0426\u0415\u041d\u0422"

    invoke-direct {p0, p2, v1, v2}, Lru/supportagent/PaletteActivity;->addSwatch(Landroid/widget/LinearLayout;ILjava/lang/String;)V

    const/4 v4, -0x1

    const/4 v5, -0x2

    const/4 v6, 0x0

    const/16 v7, 0xc

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v3, p0

    .line 97
    invoke-static/range {v3 .. v9}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 98
    new-instance p2, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda6;

    invoke-direct {p2, p0, p1}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda6;-><init>(Lru/supportagent/PaletteActivity;Lru/supportagent/AgentPalette;)V

    invoke-virtual {v0, p2}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 103
    iget-boolean p2, p1, Lru/supportagent/AgentPalette;->builtIn:Z

    if-nez p2, :cond_1

    new-instance p2, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda7;

    invoke-direct {p2, p0, p1}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda7;-><init>(Lru/supportagent/PaletteActivity;Lru/supportagent/AgentPalette;)V

    invoke-virtual {v0, p2}, Landroid/widget/LinearLayout;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    :cond_1
    return-object v0
.end method

.method private refreshOverlay()V
    .locals 2

    .line 195
    invoke-static {}, Lru/supportagent/OverlayService;->isRunning()Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/supportagent/OverlayService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "ru.supportagent.REFRESH"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lru/supportagent/PaletteActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_0
    return-void
.end method

.method private render()V
    .locals 14

    .line 42
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    invoke-virtual {v0}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object v0

    iput-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    .line 43
    invoke-virtual {p0}, Lru/supportagent/PaletteActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    iget-object v1, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 44
    invoke-virtual {p0}, Lru/supportagent/PaletteActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    iget-object v1, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 45
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 46
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->root:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->backgroundColor()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 47
    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, p0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 48
    new-instance v7, Landroid/widget/LinearLayout;

    invoke-direct {v7, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x1

    .line 49
    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x41a00000    # 20.0f

    .line 50
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x41b00000    # 22.0f

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/high16 v4, 0x41f00000    # 30.0f

    invoke-static {p0, v4}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v7, v2, v3, v1, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 51
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v9, -0x2

    invoke-direct {v1, v2, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v7, v1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 52
    iget-object v1, p0, Lru/supportagent/PaletteActivity;->root:Landroid/widget/LinearLayout;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 54
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 55
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 56
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    const-string v1, "\u2039"

    const/4 v11, 0x0

    invoke-static {p0, v1, v0, v11}, Lru/supportagent/Ui;->button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;

    move-result-object v12

    const/high16 v0, 0x41c80000    # 25.0f

    .line 57
    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/high16 v13, 0x40000000    # 2.0f

    .line 58
    invoke-static {p0, v13}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {v12, v11, v11, v11, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 59
    new-instance v0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda2;-><init>(Lru/supportagent/PaletteActivity;)V

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v1, 0x2d

    const/16 v2, 0x2a

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v5, 0xc

    const/4 v6, 0x0

    move-object v0, p0

    .line 60
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v10, v12, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 61
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const-string v1, "\u041f\u0410\u041b\u0418\u0422\u0420\u0410"

    const/high16 v2, 0x41a80000    # 21.0f

    invoke-static {p0, v1, v2, v0, v8}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 62
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v1, v11, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    move-object v0, p0

    .line 63
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 64
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v1, "\u041e\u0424\u041e\u0420\u041c\u041b\u0415\u041d\u0418\u0415 \u041a\u0420\u0423\u0413\u0410 \u0418 \u041f\u0410\u041d\u0415\u041b\u0418"

    const/high16 v2, 0x41300000    # 11.0f

    invoke-static {p0, v1, v2, v0, v8}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v9

    const v0, 0x3da3d70a    # 0.08f

    .line 65
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/16 v3, 0x39

    const/16 v6, 0x14

    move-object v0, p0

    .line 66
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 68
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0}, Lru/supportagent/Ui;->card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;

    move-result-object v9

    .line 69
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const-string v1, "\u0421\u0442\u0438\u043b\u044c \u043a\u0430\u043a \u0432 Black Russia"

    const/high16 v2, 0x41800000    # 16.0f

    invoke-static {p0, v1, v2, v0, v8}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 70
    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 71
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v0}, Lru/supportagent/AgentPalette;->mutedColor()I

    move-result v0

    const-string v1, "\u041d\u043e\u0447\u043d\u0430\u044f BR \u2014 \u0431\u0430\u0437\u043e\u0432\u0430\u044f \u043f\u0430\u043b\u0438\u0442\u0440\u0430: \u0442\u0451\u043c\u043d\u044b\u0439 \u0444\u043e\u043d, \u0441\u0438\u043d\u0438\u0435 \u043a\u043e\u043d\u0442\u0443\u0440\u044b \u0438 \u043a\u0440\u0430\u0441\u043d\u044b\u0439 \u0430\u043a\u0446\u0435\u043d\u0442. \u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u043d\u0430 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0443, \u0447\u0442\u043e\u0431\u044b \u043f\u0440\u0438\u043c\u0435\u043d\u0438\u0442\u044c \u0446\u0432\u0435\u0442\u043e\u0432\u0443\u044e \u0441\u0445\u0435\u043c\u0443."

    const/high16 v2, 0x41500000    # 13.0f

    invoke-static {p0, v1, v2, v0, v11}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object v10

    .line 72
    invoke-static {p0, v13}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v10, v0, v12}, Landroid/widget/TextView;->setLineSpacing(FF)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v6, 0x0

    move-object v0, p0

    .line 73
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v9, v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x0

    const/16 v6, 0xe

    move-object v0, p0

    .line 74
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v9, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 76
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    invoke-virtual {v0}, Lru/supportagent/PaletteRepository;->getActive()Lru/supportagent/AgentPalette;

    move-result-object v0

    iget-object v9, v0, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    .line 77
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    invoke-virtual {v0}, Lru/supportagent/PaletteRepository;->getAll()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :goto_0
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/supportagent/AgentPalette;

    iget-object v1, v0, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    invoke-direct {p0, v0, v1}, Lru/supportagent/PaletteActivity;->paletteCard(Lru/supportagent/AgentPalette;Z)Landroid/widget/LinearLayout;

    move-result-object v11

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x9

    move-object v0, p0

    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_0
    const-string v0, "+ \u0421\u041e\u0417\u0414\u0410\u0422\u042c \u0421\u0412\u041e\u042e \u041f\u0410\u041b\u0418\u0422\u0420\u0423"

    .line 78
    iget-object v1, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-static {p0, v0, v1, v8}, Lru/supportagent/Ui;->button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;

    move-result-object v8

    .line 79
    new-instance v0, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda3;-><init>(Lru/supportagent/PaletteActivity;)V

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    const/4 v3, 0x0

    const/16 v4, 0x8

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p0

    .line 80
    invoke-static/range {v0 .. v6}, Lru/supportagent/Ui;->lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v7, v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private styleDialog(Landroidx/appcompat/app/AlertDialog;)V
    .locals 2

    .line 187
    invoke-virtual {p1}, Landroidx/appcompat/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 189
    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    iget-object v1, p0, Lru/supportagent/PaletteActivity;->palette:Lru/supportagent/AgentPalette;

    invoke-virtual {v1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 190
    invoke-virtual {p0}, Lru/supportagent/PaletteActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v0, v0

    const v1, 0x3f6b851f    # 0.92f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    const/4 v1, -0x2

    invoke-virtual {p1, v0, v1}, Landroid/view/Window;->setLayout(II)V

    :cond_0
    return-void
.end method


# virtual methods
.method synthetic lambda$customPaletteDialog$4$ru-supportagent-PaletteActivity(Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;Landroid/view/View;)V
    .locals 6

    .line 138
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p7

    invoke-virtual {p7}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p7

    invoke-virtual {p7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p7

    invoke-virtual {p7}, Ljava/lang/String;->isEmpty()Z

    move-result p7

    if-nez p7, :cond_1

    invoke-direct {p0, p2}, Lru/supportagent/PaletteActivity;->isColor(Landroid/widget/EditText;)Z

    move-result p7

    if-eqz p7, :cond_1

    invoke-direct {p0, p3}, Lru/supportagent/PaletteActivity;->isColor(Landroid/widget/EditText;)Z

    move-result p7

    if-eqz p7, :cond_1

    invoke-direct {p0, p4}, Lru/supportagent/PaletteActivity;->isColor(Landroid/widget/EditText;)Z

    move-result p7

    if-eqz p7, :cond_1

    invoke-direct {p0, p5}, Lru/supportagent/PaletteActivity;->isColor(Landroid/widget/EditText;)Z

    move-result p7

    if-nez p7, :cond_0

    goto :goto_0

    .line 142
    :cond_0
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {v0 .. v5}, Lru/supportagent/PaletteRepository;->saveCustom(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 143
    invoke-virtual {p6}, Landroidx/appcompat/app/AlertDialog;->dismiss()V

    .line 144
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->refreshOverlay()V

    .line 145
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->render()V

    return-void

    :cond_1
    :goto_0
    const-string p1, "\u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0438 \u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u044b\u0435 HEX-\u0446\u0432\u0435\u0442\u0430"

    const/4 p2, 0x0

    .line 139
    invoke-static {p0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method synthetic lambda$customPaletteDialog$5$ru-supportagent-PaletteActivity(Landroidx/appcompat/app/AlertDialog;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/content/DialogInterface;)V
    .locals 10

    .line 136
    invoke-direct {p0, p1}, Lru/supportagent/PaletteActivity;->styleDialog(Landroidx/appcompat/app/AlertDialog;)V

    const/4 v0, -0x1

    move-object v8, p1

    .line 137
    invoke-virtual {p1, v0}, Landroidx/appcompat/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v0

    new-instance v9, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;

    move-object v1, v9

    move-object v2, p0

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move-object/from16 v7, p6

    invoke-direct/range {v1 .. v8}, Lru/supportagent/PaletteActivity$$ExternalSyntheticLambda4;-><init>(Lru/supportagent/PaletteActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroidx/appcompat/app/AlertDialog;)V

    invoke-virtual {v0, v9}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method synthetic lambda$deleteCustomConfirm$6$ru-supportagent-PaletteActivity(Lru/supportagent/AgentPalette;Landroid/content/DialogInterface;I)V
    .locals 0

    .line 177
    iget-object p2, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    iget-object p1, p1, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {p2, p1}, Lru/supportagent/PaletteRepository;->delete(Ljava/lang/String;)V

    .line 178
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->refreshOverlay()V

    .line 179
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->render()V

    return-void
.end method

.method synthetic lambda$deleteCustomConfirm$7$ru-supportagent-PaletteActivity(Landroidx/appcompat/app/AlertDialog;Landroid/content/DialogInterface;)V
    .locals 0

    .line 182
    invoke-direct {p0, p1}, Lru/supportagent/PaletteActivity;->styleDialog(Landroidx/appcompat/app/AlertDialog;)V

    return-void
.end method

.method synthetic lambda$paletteCard$2$ru-supportagent-PaletteActivity(Lru/supportagent/AgentPalette;Landroid/view/View;)V
    .locals 0

    .line 99
    iget-object p2, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    iget-object p1, p1, Lru/supportagent/AgentPalette;->id:Ljava/lang/String;

    invoke-virtual {p2, p1}, Lru/supportagent/PaletteRepository;->setActive(Ljava/lang/String;)V

    .line 100
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->refreshOverlay()V

    .line 101
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->render()V

    return-void
.end method

.method synthetic lambda$paletteCard$3$ru-supportagent-PaletteActivity(Lru/supportagent/AgentPalette;Landroid/view/View;)Z
    .locals 0

    .line 103
    invoke-direct {p0, p1}, Lru/supportagent/PaletteActivity;->deleteCustomConfirm(Lru/supportagent/AgentPalette;)V

    const/4 p1, 0x1

    return p1
.end method

.method synthetic lambda$render$0$ru-supportagent-PaletteActivity(Landroid/view/View;)V
    .locals 0

    .line 59
    invoke-virtual {p0}, Lru/supportagent/PaletteActivity;->finish()V

    return-void
.end method

.method synthetic lambda$render$1$ru-supportagent-PaletteActivity(Landroid/view/View;)V
    .locals 0

    .line 79
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->customPaletteDialog()V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 27
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 28
    new-instance p1, Lru/supportagent/PaletteRepository;

    invoke-direct {p1, p0}, Lru/supportagent/PaletteRepository;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lru/supportagent/PaletteActivity;->repository:Lru/supportagent/PaletteRepository;

    .line 29
    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lru/supportagent/PaletteActivity;->root:Landroid/widget/LinearLayout;

    const/4 v0, 0x1

    .line 30
    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 31
    iget-object p1, p0, Lru/supportagent/PaletteActivity;->root:Landroid/widget/LinearLayout;

    invoke-virtual {p0, p1}, Lru/supportagent/PaletteActivity;->setContentView(Landroid/view/View;)V

    .line 32
    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->render()V

    return-void
.end method

.method protected onResume()V
    .locals 1

    .line 37
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onResume()V

    .line 38
    iget-object v0, p0, Lru/supportagent/PaletteActivity;->root:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lru/supportagent/PaletteActivity;->render()V

    :cond_0
    return-void
.end method
