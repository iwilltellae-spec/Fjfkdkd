.class public final Lru/supportagent/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lru/supportagent/R$anim;,
        Lru/supportagent/R$animator;,
        Lru/supportagent/R$attr;,
        Lru/supportagent/R$bool;,
        Lru/supportagent/R$color;,
        Lru/supportagent/R$dimen;,
        Lru/supportagent/R$drawable;,
        Lru/supportagent/R$id;,
        Lru/supportagent/R$integer;,
        Lru/supportagent/R$interpolator;,
        Lru/supportagent/R$layout;,
        Lru/supportagent/R$mipmap;,
        Lru/supportagent/R$string;,
        Lru/supportagent/R$style;,
        Lru/supportagent/R$styleable;,
        Lru/supportagent/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
