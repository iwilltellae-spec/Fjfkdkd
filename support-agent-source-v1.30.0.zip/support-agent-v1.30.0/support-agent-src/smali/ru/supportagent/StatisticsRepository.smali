.class public final Lru/supportagent/StatisticsRepository;
.super Ljava/lang/Object;
.source "StatisticsRepository.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lru/supportagent/StatisticsRepository$Snapshot;
    }
.end annotation


# static fields
.field private static final KEY_DAY:Ljava/lang/String; = "local_day"

.field private static final KEY_GAME_STARTED:Ljava/lang/String; = "game_started"

.field private static final KEY_TODAY_ANSWERS:Ljava/lang/String; = "today_answers"

.field private static final KEY_TODAY_GAME_MILLIS:Ljava/lang/String; = "today_game_millis"

.field private static final KEY_TOTAL_ANSWERS:Ljava/lang/String; = "total_answers"

.field private static final LOCK:Ljava/lang/Object;

.field private static final PREFS:Ljava/lang/String; = "support_agent_statistics"


# instance fields
.field private final preferences:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 23
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lru/supportagent/StatisticsRepository;->LOCK:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v0, "support_agent_statistics"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    .line 28
    sget-object p1, Lru/supportagent/StatisticsRepository;->LOCK:Ljava/lang/Object;

    monitor-enter p1

    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-direct {p0, v0, v1}, Lru/supportagent/StatisticsRepository;->normalizeDay(J)V

    monitor-exit p1

    return-void

    :catchall_0
    move-exception v0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method private addElapsed(JJ)V
    .locals 6

    .line 83
    iget-object v0, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v1, "today_game_millis"

    const-wide/16 v2, 0x0

    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v4

    .line 84
    iget-object v0, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {p1, p2, p3, p4}, Lru/supportagent/StatisticsRepository;->safeElapsed(JJ)J

    move-result-wide p1

    add-long/2addr v4, p1

    invoke-interface {v0, v1, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string p2, "game_started"

    .line 85
    invoke-interface {p1, p2, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method private static dateKey(J)Ljava/lang/String;
    .locals 3

    .line 103
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyy-MM-dd"

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1, p0, p1}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static formatDuration(J)Ljava/lang/String;
    .locals 6

    const-wide/32 v0, 0xea60

    .line 123
    div-long/2addr p0, v0

    const-wide/16 v0, 0x0

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p0

    const-wide/16 v2, 0x3c

    .line 124
    div-long v4, p0, v2

    .line 125
    rem-long/2addr p0, v2

    cmp-long v0, v4, v0

    const-string v1, " \u043c\u0438\u043d"

    if-lez v0, :cond_0

    .line 126
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u0447 "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v4, 0x0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    aput-object p0, v3, v4

    const-string p0, "%02d"

    invoke-static {v2, p0, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p0

    :goto_0
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private normalizeDay(J)V
    .locals 8

    .line 90
    invoke-static {p1, p2}, Lru/supportagent/StatisticsRepository;->dateKey(J)Ljava/lang/String;

    move-result-object v0

    .line 91
    iget-object v1, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v2, ""

    const-string v3, "local_day"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 92
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    .line 93
    :cond_0
    iget-object v1, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v2, "game_started"

    const-wide/16 v4, 0x0

    invoke-interface {v1, v2, v4, v5}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v6

    .line 94
    iget-object v1, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 95
    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "today_answers"

    const/4 v3, 0x0

    .line 96
    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "today_game_millis"

    .line 97
    invoke-interface {v0, v1, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    cmp-long v1, v6, v4

    if-lez v1, :cond_1

    .line 99
    invoke-static {p1, p2}, Lru/supportagent/StatisticsRepository;->startOfToday(J)J

    move-result-wide v4

    :cond_1
    invoke-interface {v0, v2, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method private static safeElapsed(JJ)J
    .locals 3

    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-lez v2, :cond_1

    cmp-long v2, p0, p2

    if-gtz v2, :cond_0

    goto :goto_0

    :cond_0
    sub-long/2addr p0, p2

    const-wide/32 p2, 0x5265c00

    .line 119
    invoke-static {p0, p1, p2, p3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p0

    return-wide p0

    :cond_1
    :goto_0
    return-wide v0
.end method

.method private static startOfToday(J)J
    .locals 1

    .line 107
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    .line 108
    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/16 p0, 0xb

    const/4 p1, 0x0

    .line 109
    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->set(II)V

    const/16 p0, 0xc

    .line 110
    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->set(II)V

    const/16 p0, 0xd

    .line 111
    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->set(II)V

    const/16 p0, 0xe

    .line 112
    invoke-virtual {v0, p0, p1}, Ljava/util/Calendar;->set(II)V

    .line 113
    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide p0

    return-wide p0
.end method


# virtual methods
.method public recordConfirmedAnswer()V
    .locals 5

    .line 33
    sget-object v0, Lru/supportagent/StatisticsRepository;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 34
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 35
    invoke-direct {p0, v1, v2}, Lru/supportagent/StatisticsRepository;->normalizeDay(J)V

    .line 36
    iget-object v1, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v2, "total_answers"

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    .line 37
    iget-object v2, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v4, "today_answers"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    add-int/lit8 v2, v2, 0x1

    .line 38
    iget-object v3, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "total_answers"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "today_answers"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 39
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public setGameForeground(Z)V
    .locals 8

    .line 44
    sget-object v0, Lru/supportagent/StatisticsRepository;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 45
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 46
    invoke-direct {p0, v1, v2}, Lru/supportagent/StatisticsRepository;->normalizeDay(J)V

    .line 47
    iget-object v3, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v4, "game_started"

    const-wide/16 v5, 0x0

    invoke-interface {v3, v4, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    if-eqz p1, :cond_0

    cmp-long v7, v3, v5

    if-nez v7, :cond_0

    .line 49
    iget-object p1, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v3, "game_started"

    invoke-interface {p1, v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_0

    :cond_0
    if-nez p1, :cond_1

    cmp-long p1, v3, v5

    if-lez p1, :cond_1

    .line 51
    invoke-direct {p0, v1, v2, v3, v4}, Lru/supportagent/StatisticsRepository;->addElapsed(JJ)V

    .line 53
    :cond_1
    :goto_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public snapshot()Lru/supportagent/StatisticsRepository$Snapshot;
    .locals 11

    .line 67
    sget-object v0, Lru/supportagent/StatisticsRepository;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 68
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 69
    invoke-direct {p0, v1, v2}, Lru/supportagent/StatisticsRepository;->normalizeDay(J)V

    .line 70
    iget-object v3, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v4, "today_game_millis"

    const-wide/16 v5, 0x0

    invoke-interface {v3, v4, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    .line 71
    iget-object v7, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v8, "game_started"

    invoke-interface {v7, v8, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    cmp-long v5, v7, v5

    if-lez v5, :cond_0

    .line 72
    invoke-static {v1, v2, v7, v8}, Lru/supportagent/StatisticsRepository;->safeElapsed(JJ)J

    move-result-wide v1

    add-long/2addr v3, v1

    :cond_0
    move-wide v6, v3

    .line 73
    new-instance v1, Lru/supportagent/StatisticsRepository$Snapshot;

    iget-object v2, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v3, "total_answers"

    const/4 v4, 0x0

    .line 74
    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iget-object v2, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v8, "today_answers"

    .line 75
    invoke-interface {v2, v8, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    if-lez v5, :cond_1

    const/4 v2, 0x1

    move v9, v2

    goto :goto_0

    :cond_1
    move v9, v4

    :goto_0
    const/4 v10, 0x0

    move-object v2, v1

    move v4, v8

    move-wide v5, v6

    move v7, v9

    move-object v8, v10

    invoke-direct/range {v2 .. v8}, Lru/supportagent/StatisticsRepository$Snapshot;-><init>(IIJZLru/supportagent/StatisticsRepository$Snapshot-IA;)V

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception v1

    .line 79
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public stopGameTimer()V
    .locals 7

    .line 58
    sget-object v0, Lru/supportagent/StatisticsRepository;->LOCK:Ljava/lang/Object;

    monitor-enter v0

    .line 59
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    .line 60
    invoke-direct {p0, v1, v2}, Lru/supportagent/StatisticsRepository;->normalizeDay(J)V

    .line 61
    iget-object v3, p0, Lru/supportagent/StatisticsRepository;->preferences:Landroid/content/SharedPreferences;

    const-string v4, "game_started"

    const-wide/16 v5, 0x0

    invoke-interface {v3, v4, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    cmp-long v5, v3, v5

    if-lez v5, :cond_0

    .line 62
    invoke-direct {p0, v1, v2, v3, v4}, Lru/supportagent/StatisticsRepository;->addElapsed(JJ)V

    .line 63
    :cond_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method
