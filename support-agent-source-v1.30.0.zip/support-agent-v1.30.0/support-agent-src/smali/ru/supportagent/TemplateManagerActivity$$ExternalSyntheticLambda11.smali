.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Lru/supportagent/Topic;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Lru/supportagent/Topic;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;->f$1:Lru/supportagent/Topic;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda11;->f$1:Lru/supportagent/Topic;

    invoke-virtual {v0, v1, p1, p2}, Lru/supportagent/TemplateManagerActivity;->lambda$deleteTopicConfirm$17$ru-supportagent-TemplateManagerActivity(Lru/supportagent/Topic;Landroid/content/DialogInterface;I)V

    return-void
.end method
