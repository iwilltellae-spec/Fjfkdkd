.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda15;->f$0:Lru/supportagent/TemplateManagerActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda15;->f$0:Lru/supportagent/TemplateManagerActivity;

    invoke-virtual {v0, p1}, Lru/supportagent/TemplateManagerActivity;->lambda$showTemplates$4$ru-supportagent-TemplateManagerActivity(Landroid/view/View;)V

    return-void
.end method
