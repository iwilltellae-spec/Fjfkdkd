.class public final synthetic Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lru/supportagent/TemplateManagerActivity;

.field public final synthetic f$1:Landroid/widget/EditText;

.field public final synthetic f$2:Lru/supportagent/Topic;

.field public final synthetic f$3:Landroidx/appcompat/app/AlertDialog;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/TemplateManagerActivity;Landroid/widget/EditText;Lru/supportagent/Topic;Landroidx/appcompat/app/AlertDialog;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$0:Lru/supportagent/TemplateManagerActivity;

    iput-object p2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$1:Landroid/widget/EditText;

    iput-object p3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$2:Lru/supportagent/Topic;

    iput-object p4, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$3:Landroidx/appcompat/app/AlertDialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget-object v0, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$0:Lru/supportagent/TemplateManagerActivity;

    iget-object v1, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$1:Landroid/widget/EditText;

    iget-object v2, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$2:Lru/supportagent/Topic;

    iget-object v3, p0, Lru/supportagent/TemplateManagerActivity$$ExternalSyntheticLambda7;->f$3:Landroidx/appcompat/app/AlertDialog;

    invoke-virtual {v0, v1, v2, v3, p1}, Lru/supportagent/TemplateManagerActivity;->lambda$topicDialog$9$ru-supportagent-TemplateManagerActivity(Landroid/widget/EditText;Lru/supportagent/Topic;Landroidx/appcompat/app/AlertDialog;Landroid/view/View;)V

    return-void
.end method
