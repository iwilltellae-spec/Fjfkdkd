.class public final Lru/supportagent/TemplateRepository$SearchResults;
.super Ljava/lang/Object;
.source "TemplateRepository.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lru/supportagent/TemplateRepository;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "SearchResults"
.end annotation


# instance fields
.field public final hits:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lru/supportagent/TemplateRepository$SearchHit;",
            ">;"
        }
    .end annotation
.end field

.field public final total:I


# direct methods
.method private constructor <init>(Ljava/util/List;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lru/supportagent/TemplateRepository$SearchHit;",
            ">;I)V"
        }
    .end annotation

    .line 58
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 59
    iput-object p1, p0, Lru/supportagent/TemplateRepository$SearchResults;->hits:Ljava/util/List;

    .line 60
    iput p2, p0, Lru/supportagent/TemplateRepository$SearchResults;->total:I

    return-void
.end method

.method synthetic constructor <init>(Ljava/util/List;ILru/supportagent/TemplateRepository$SearchResults-IA;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lru/supportagent/TemplateRepository$SearchResults;-><init>(Ljava/util/List;I)V

    return-void
.end method
