.class public final Lru/supportagent/TopicPin;
.super Ljava/lang/Object;
.source "TopicPin.java"


# static fields
.field private static final KEY:Ljava/lang/String; = "pinned_topics"

.field private static final MAX:I = 0x4

.field private static final PREFS:Ljava/lang/String; = "support_agent_overlay"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    return-void
.end method

.method public static getPinned(Landroid/content/Context;)Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 17
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 18
    if-nez p0, :cond_8

    .line 19
    return-object v0

    .line 21
    :cond_8
    const-string v1, "support_agent_overlay"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v1, "pinned_topics"

    const-string v3, ""

    invoke-interface {p0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 22
    if-nez p0, :cond_1a

    .line 23
    return-object v0

    .line 25
    :cond_1a
    const-string v1, ","

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    .line 26
    nop

    :goto_21
    array-length v1, p0

    if-ge v2, v1, :cond_3c

    .line 27
    aget-object v1, p0, v2

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 28
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_39

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_39

    .line 29
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 26
    :cond_39
    add-int/lit8 v2, v2, 0x1

    goto :goto_21

    .line 32
    :cond_3c
    return-object v0
.end method

.method public static isPinned(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 2

    .line 47
    if-nez p1, :cond_4

    .line 48
    const/4 p0, 0x0

    return p0

    .line 50
    :cond_4
    invoke-static {p0}, Lru/supportagent/TopicPin;->getPinned(Landroid/content/Context;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method private static save(Landroid/content/Context;Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 36
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 37
    const/4 v1, 0x0

    move v2, v1

    :goto_7
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_24

    .line 38
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-lez v3, :cond_18

    .line 39
    const/16 v3, 0x2c

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 41
    :cond_18
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    .line 43
    :cond_24
    const-string p1, "support_agent_overlay"

    invoke-virtual {p0, p1, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "pinned_topics"

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 44
    return-void
.end method

.method public static sortTopics(Landroid/content/Context;Ljava/util/List;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lru/supportagent/Topic;",
            ">;)V"
        }
    .end annotation

    .line 77
    if-eqz p0, :cond_76

    if-nez p1, :cond_6

    goto/16 :goto_76

    .line 80
    :cond_6
    invoke-static {p0}, Lru/supportagent/TopicPin;->getPinned(Landroid/content/Context;)Ljava/util/List;

    move-result-object p0

    .line 81
    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_11

    .line 82
    return-void

    .line 84
    :cond_11
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 85
    const/4 v1, 0x0

    move v2, v1

    :goto_18
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_45

    .line 86
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 87
    move v4, v1

    :goto_25
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_42

    .line 88
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lru/supportagent/Topic;

    .line 89
    if-eqz v5, :cond_3f

    iget-object v6, v5, Lru/supportagent/Topic;->id:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3f

    .line 90
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 91
    goto :goto_42

    .line 87
    :cond_3f
    add-int/lit8 v4, v4, 0x1

    goto :goto_25

    .line 85
    :cond_42
    :goto_42
    add-int/lit8 v2, v2, 0x1

    goto :goto_18

    .line 95
    :cond_45
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_4c

    .line 96
    return-void

    .line 98
    :cond_4c
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    .line 99
    nop

    :goto_52
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_6c

    .line 100
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/supportagent/Topic;

    .line 101
    if-eqz v2, :cond_69

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_69

    .line 102
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 99
    :cond_69
    add-int/lit8 v1, v1, 0x1

    goto :goto_52

    .line 105
    :cond_6c
    invoke-interface {p1}, Ljava/util/List;->clear()V

    .line 106
    invoke-interface {p1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 107
    invoke-interface {p1, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 108
    return-void

    .line 78
    :cond_76
    :goto_76
    return-void
.end method

.method public static togglePin(Landroid/content/Context;Ljava/lang/String;)I
    .registers 5

    .line 59
    const/4 v0, 0x0

    if-eqz p0, :cond_32

    if-eqz p1, :cond_32

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-nez v1, :cond_c

    goto :goto_32

    .line 62
    :cond_c
    invoke-static {p0}, Lru/supportagent/TopicPin;->getPinned(Landroid/content/Context;)Ljava/util/List;

    move-result-object v1

    .line 63
    invoke-interface {v1, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1a

    .line 64
    invoke-static {p0, v1}, Lru/supportagent/TopicPin;->save(Landroid/content/Context;Ljava/util/List;)V

    .line 65
    return v0

    .line 67
    :cond_1a
    invoke-interface {v1, v0, p1}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 68
    :goto_1d
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v0, 0x4

    const/4 v2, 0x1

    if-le p1, v0, :cond_2e

    .line 69
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result p1

    sub-int/2addr p1, v2

    invoke-interface {v1, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    goto :goto_1d

    .line 71
    :cond_2e
    invoke-static {p0, v1}, Lru/supportagent/TopicPin;->save(Landroid/content/Context;Ljava/util/List;)V

    .line 72
    return v2

    .line 60
    :cond_32
    :goto_32
    return v0
.end method
