.class public final synthetic Lru/supportagent/TopicPinConfirm;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lru/supportagent/OverlayService;


# direct methods
.method public synthetic constructor <init>(Lru/supportagent/OverlayService;)V
    .locals 0

    iput-object p1, p0, Lru/supportagent/TopicPinConfirm;->f$0:Lru/supportagent/OverlayService;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lru/supportagent/TopicPinConfirm;->f$0:Lru/supportagent/OverlayService;

    invoke-virtual {v0}, Lru/supportagent/OverlayService;->toggleTopicPin()V

    return-void
.end method
