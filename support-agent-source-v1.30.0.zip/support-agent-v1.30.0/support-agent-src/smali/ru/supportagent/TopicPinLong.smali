.class public final synthetic Lru/supportagent/TopicPinLong;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnLongClickListener;

.field public final synthetic f$0:Lru/supportagent/OverlayService;

.field public final synthetic f$1:Lru/supportagent/Topic;

.method public synthetic constructor <init>(Lru/supportagent/OverlayService;Lru/supportagent/Topic;)V
    .locals 0

    iput-object p1, p0, Lru/supportagent/TopicPinLong;->f$0:Lru/supportagent/OverlayService;

    iput-object p2, p0, Lru/supportagent/TopicPinLong;->f$1:Lru/supportagent/Topic;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public final onLongClick(Landroid/view/View;)Z
    .locals 2

    iget-object v0, p0, Lru/supportagent/TopicPinLong;->f$0:Lru/supportagent/OverlayService;

    iget-object v1, p0, Lru/supportagent/TopicPinLong;->f$1:Lru/supportagent/Topic;

    invoke-virtual {v0, v1, p1}, Lru/supportagent/OverlayService;->openTopicPinMenu(Lru/supportagent/Topic;Landroid/view/View;)V

    const/4 v0, 0x1

    return v0
.end method
