.class public final Lru/supportagent/Ui;
.super Ljava/lang/Object;
.source "Ui.java"


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static button(Landroid/content/Context;Ljava/lang/String;Lru/supportagent/AgentPalette;Z)Landroid/widget/TextView;
    .locals 5

    .line 47
    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->textColor()I

    move-result v0

    const/high16 v1, 0x41480000    # 12.5f

    const/4 v2, 0x1

    invoke-static {p0, p1, v1, v0, v2}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 48
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 49
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setAllCaps(Z)V

    const/high16 v0, 0x42380000    # 46.0f

    .line 50
    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/high16 v0, 0x41400000    # 12.0f

    .line 51
    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    const/high16 v3, 0x41000000    # 8.0f

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {p1, v1, v4, v0, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const/high16 v0, 0x41200000    # 10.0f

    if-eqz p3, :cond_0

    .line 53
    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->accentColor()I

    move-result p2

    invoke-static {p2, v0, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    goto :goto_0

    .line 54
    :cond_0
    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result p3

    invoke-virtual {p2}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result p2

    invoke-static {p3, p2, v0, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    .line 52
    :goto_0
    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 55
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setClickable(Z)V

    .line 56
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setFocusable(Z)V

    return-object p1
.end method

.method public static card(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/widget/LinearLayout;
    .locals 5

    .line 69
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 70
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x41800000    # 16.0f

    .line 71
    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x41700000    # 15.0f

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    invoke-static {p0, v3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 72
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->panelColor()I

    move-result v1

    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result p1

    const/high16 v2, 0x41600000    # 14.0f

    invoke-static {v1, p1, v2, p0}, Lru/supportagent/Ui;->outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method public static chip(Landroid/content/Context;Ljava/lang/String;IILru/supportagent/AgentPalette;)Landroid/widget/TextView;
    .locals 2

    .line 61
    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const/high16 p4, 0x41280000    # 10.5f

    const/4 v0, 0x1

    invoke-static {p0, p1, p4, p3, v0}, Lru/supportagent/Ui;->text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 p3, 0x11

    .line 62
    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 p3, 0x41400000    # 12.0f

    .line 63
    invoke-static {p0, p3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p4

    const/high16 v0, 0x40e00000    # 7.0f

    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v1

    invoke-static {p0, p3}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p3

    invoke-static {p0, v0}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {p1, p4, v1, p3, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    const/high16 p3, 0x41900000    # 18.0f

    .line 64
    invoke-static {p2, p3, p0}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object p1
.end method

.method public static click(Landroid/view/View;Landroid/view/View$OnClickListener;)V
    .locals 0

    .line 95
    invoke-virtual {p0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 p1, 0x1

    .line 96
    invoke-virtual {p0, p1}, Landroid/view/View;->setClickable(Z)V

    return-void
.end method

.method public static dp(Landroid/content/Context;F)I
    .locals 0

    .line 18
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static line(Landroid/content/Context;Lru/supportagent/AgentPalette;)Landroid/view/View;
    .locals 1

    .line 77
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 78
    invoke-virtual {p1}, Lru/supportagent/AgentPalette;->outlineColor()I

    move-result p0

    invoke-virtual {v0, p0}, Landroid/view/View;->setBackgroundColor(I)V

    return-object v0
.end method

.method public static lp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;
    .locals 1

    .line 83
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, p0, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 84
    invoke-virtual {v0, p2, p3, p4, p5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    return-object v0
.end method

.method public static lpDp(Landroid/content/Context;IIIIII)Landroid/widget/LinearLayout$LayoutParams;
    .locals 6

    if-gez p1, :cond_0

    goto :goto_0

    :cond_0
    int-to-float p1, p1

    .line 90
    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p1

    :goto_0
    move v0, p1

    if-gez p2, :cond_1

    goto :goto_1

    :cond_1
    int-to-float p1, p2

    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p2

    :goto_1
    move v1, p2

    int-to-float p1, p3

    .line 91
    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v2

    int-to-float p1, p4

    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v3

    int-to-float p1, p5

    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v4

    int-to-float p1, p6

    invoke-static {p0, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result v5

    .line 90
    invoke-static/range {v0 .. v5}, Lru/supportagent/Ui;->lp(IIIIII)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object p0

    return-object p0
.end method

.method public static outlined(IIFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;
    .locals 0

    .line 29
    invoke-static {p0, p2, p3}, Lru/supportagent/Ui;->rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    const p2, 0x3fa66666    # 1.3f

    .line 30
    invoke-static {p3, p2}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p2

    invoke-virtual {p0, p2, p1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    return-object p0
.end method

.method public static rounded(IFLandroid/content/Context;)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    .line 22
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 23
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 24
    invoke-static {p2, p1}, Lru/supportagent/Ui;->dp(Landroid/content/Context;F)I

    move-result p0

    int-to-float p0, p0

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public static text(Landroid/content/Context;Ljava/lang/String;FIZ)Landroid/widget/TextView;
    .locals 1

    .line 35
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 36
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 38
    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setTextColor(I)V

    const-string p0, "kern"

    .line 39
    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setFontFeatureSettings(Ljava/lang/String;)V

    const-string p0, "sans-serif"

    .line 40
    invoke-static {p0, p4}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 p0, 0x0

    .line 41
    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    .line 42
    sget-object p0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    return-object v0
.end method

.method public static withAlpha(II)I
    .locals 2

    .line 100
    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result p0

    invoke-static {p1, v0, v1, p0}, Landroid/graphics/Color;->argb(IIII)I

    move-result p0

    return p0
.end method
